/*
> why do we need hooks?
    class components have state, life cycle and pure component. to implement this in functional component we use hooks

    NOTE:
    'use' is a reserved word.
> what are hooks?
> how to use them
> Example with useState

> sari life cycle methods useEffect me hoti hai 

*/

import React, {useState, u} from "react";

export default function Hooks() {
    const [data, setData]=useState("khush");
  return (
    <div>
      <center>
        <h1>Hooks</h1>
        <h2>{data}</h2>
        <button onClick={()=>setData('pupu')}>Update</button>
      </center>
    </div>
  );
}
