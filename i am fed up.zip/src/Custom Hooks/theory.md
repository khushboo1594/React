# Definition
A custom hook is basically a js function whose name starts with "use". 
It can also call other hooks if required.

# Why?
Alternative to HOC's and render props

# How to create custom hook?
Make sure to start it with the word - "use"
Whatever logic was there with the pre-defined hook copy and paste it in the custom hook.

###  QUESTIONS ###
1. What is the difference between components and custom hook?
We should use custom hook when we want to return anything other than JSX. If you want to return JSX then go for component.

### READ ###
1. HOC's and render props
2. See this video -> it's remaining (https://www.youtube.com/watch?v=6am-yn3ZLEw&list=PLC3y8-rFHvwisvxhZ135pogtX7_Oe3Q3A&index=33)