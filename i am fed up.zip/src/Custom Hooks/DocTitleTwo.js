import React, { useState, useEffect } from "react";

function DocTitleTwo() {
  const [count, setCount] = useState(0);
  useEffect(() => {
    document.title = count;
  }, [count]);
  return (
    <div>
      <center>
        Count - {count}
        <br />
        <button onClick={() => setCount(count + 1)}> Increment</button>
      </center>
    </div>
  );
}

export default DocTitleTwo;
