import React, { useState } from "react";
import useDocumentTitle from "./useDocumentTitle";

function DocTitleOne() {
  const [count, setCount] = useState(0);
 useDocumentTitle(count);
  return (
    <div>
      <center>
        Count - {count}
        <button onClick={() => setCount(count + 1)}>Increment</button>
      </center>
    </div>
  );
}

export default DocTitleOne;
