// Redo this program. Its behaving strangly.

import React, { useState, useEffect, useRef } from "react";

function HookTimer() {
  const [timer, setTimer] = useState(0);
  const timerRef = useRef(0);
  useEffect(() => {
    timerRef.current = setInterval(() => {
      setTimer((prevTimer) => {
        prevTimer = prevTimer + 1;
      });
    }, 1000);
    return () => {
      clearInterval(timerRef.current);
    };
  }, []);
  return (
    <div>
      Timer - {timer}
      <button onClick={()=>clearInterval(timerRef.current)}>Clear Timer</button>
    </div>
  );
}

export default HookTimer;
