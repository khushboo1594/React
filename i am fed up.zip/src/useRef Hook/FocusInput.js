import React, { useEffect, useRef } from 'react'

function FocusInput() {
  // Step 1: 
  const inputRef = useRef(null);
  useEffect(() => {
    // focus on the input element when the page loads
    // Step 3:
    inputRef.current.focus();
  }, [])
  return (
    <div>
      {/* Step 2: */}
      <input ref={inputRef} type="text" />
    </div>
  )
}

export default FocusInput