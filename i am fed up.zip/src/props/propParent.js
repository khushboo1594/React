/* 
> React Props are read-only! You will get an error if you try to change their value. ////////////////////////////
    Whether you declare a component as a function or a class, it must never modify its own props. Consider this sum function:

    function sum(a, b) {
        return a + b;
    }
    Such functions are called “pure” because they do not attempt to change their inputs, and always return the same result for the same inputs.

    In contrast, this function is impure because it changes its own input:

    function withdraw(account, amount) {
        account.total -= amount;
    }
    React is pretty flexible but it has a single strict rule:

    All React components must act like pure functions with respect to their props.

    Of course, application UIs are dynamic and change over time. In the next section, we will introduce a new concept of “state”. State allows React components to change their output over time in response to user actions, network responses, and anything else, without violating this rule.

> Props vs State ///////////////////////////////////////////
    Props are arguments passed into React components.
    Props are passed to components via HTML attributes.
    Props are also how you pass data from one component to another, as parameters.

    React Props are like function arguments in JavaScript and attributes in HTML.

    To send props into a component, use the same syntax as HTML attributes:
    Example
    Add a "brand" attribute to the Car element:
    const myelement = <Car brand="Ford" />;

    The component receives the argument as a props object:
    Example
    Use the brand attribute in the component:
    function Car(props) {
        return <h2>I am a { props.brand }!</h2>;
    }

    React components has a built-in state object.
    The state object is where you store property values that belongs to the component.
    When the state object changes, the component re-renders.

    Always use the setState() method to change the state object, it will ensure that the component knows its been updated and calls the render() method (and all the other lifecycle methods).
*/

import React from "react";
import PropChild from "./propChild";

export default function PropParent() {
  return (
    <div>
      <center>
        <h1>This is Parent Component</h1>
        <PropChild name="khushboo"/>
      </center>
    </div>
  );
} 
