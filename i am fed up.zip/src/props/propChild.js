/* 

*/

import React from "react";

export default function PropChild(props) {
  return (
    <div>
      <center>
        <h1>This is Child Component</h1>
        <h2>This is what I got from my Parent Component {props.name}</h2>
      </center>
    </div>
  );
}

/* 
QUESTIONS
*/