import React from "react";

export default class StudentClass extends React.Component {
  constructor() {
    super();
    this.state = {
      x: 0,
      y: 0,
    };
  }
  componentWillUnmount() {
    console.log("inside componentWillUnmount");
  }
  componentDidMount() {
    console.log("inside componentDidMount");
    window.addEventListener("mousemove", (e) => {
      //   even on unmounting this listener is being called
      console.log("inside listener");
      this.setState({ x: e.clientX, y: e.clientY });
    });
  }

  render() {
    return (
      <div>
        {/* <h1>Hello {this.props.name}</h1> */}
        <h2>
          x:{this.state.x}, y:{this.state.y}
        </h2>
        {/* <h2>Email : {this.props.email}</h2> */}
      </div>
    );
  }
}
 