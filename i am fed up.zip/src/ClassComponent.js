import React, { Component } from "react";

class ClassComponent extends Component {
    constructor(){
        super();
        this.state={
            data:0,
        }
    }
  render() {
    return (
      <div className="App">
        <h1>Hello {this.state.data}</h1>
        <button onClick={()=> this.setState({data:this.state.data+1})}>Click Me!!</button>
      </div>
    ); 
  }
}

export default ClassComponent;
