import React, { useContext } from "react";
import { UserContext } from "./AppCopy";

function ComponentF() {
  const user = useContext(UserContext);
  return (
    <div>
      <h4>ComponentF - {user}</h4>
      {/* <UserContext.Consumer>
        {(user) => {
          return <div>User context value {user}</div>;
        }}
      </UserContext.Consumer> */}
    </div>
  );
}

export default ComponentF; 