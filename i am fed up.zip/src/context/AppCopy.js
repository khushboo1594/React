import React from "react";
import ComponentC from "./ComponentC";
import ComponentF from "./ComponentF";

export const UserContext = React.createContext();

function AppCopy() {
  return (
    <div>
      <h1>AppCopy</h1>
      <UserContext.Provider value="khushboo">
        <ComponentF />
        {/* Since we haven't wrapped Component F in Provider user will not be accessible in Component C and E. But if I had wrapped Component C it would have been available to all child Components i.e Component E and F */}
      </UserContext.Provider>
    </div>
  );
}

export default AppCopy;
    