# Hum context waha create karte hai jaha se hame value pass karni hoti hai.

# Wrap the component in the provider jisme value pass karni hai

# steps 
1. create the context (jaha se value send karni hai)(don't forget to export it)
2. wrap the component where you want the context to be used and provide the value which you want to send
3. in the component where you want to use it, import useContext and the context. extract the value from the context
