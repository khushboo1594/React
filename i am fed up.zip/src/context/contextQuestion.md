# What is context API?

