/*
    componentWillUnmount ko waha call karna hai jaha component banaya hai na ki jaha component use kiya hai
*/
import React, { Component } from "react";

export default class RemoveComponent extends Component {
    componentWillUnmount(){
        console.log("component is removed");
    }
  render() {
    return (
      <div>
        <center>
          <h1>Hello!! I am the component to be removed</h1>
        </center>
      </div>
    );
  }
}
