import React from "react";
import Color from "./Color";
function List() {
    // Here also same warning comes that every child in a list should have a unique key prop. But what you will pass here as we do not have any id here to pass.
    const names = ["Ritu", "Khushboo", "Shweta","Ritu"];
    const nameList = names.map((name, index) => <h6 key={index}>{index}-{name}</h6>);

//   const colorNames = [
//     {
//       id: 1,
//       color: "red",
//       value: "#f00",
//     },
//     { id: 2, color: "green", value: "#0f0" },
//     { id: 3, color: "blue", value: "#00f" },
//     { id: 4, color: "cyan", value: "#0ff" },
//     { id: 5, color: "magenta", value: "#f0f" },
//     { id: 6, color: "yellow", value: "#ff0" },
//     { id: 7, color: "black", value: "#000" },
//   ];
  //   const colorList = colorNames.map((colorName) => (
  //     <h1>
  //       Color name is: {colorName.color}, value is {colorName.value}
  //     </h1>
  //   ));

  //   For color component
  //   It is recommended that you always keep the JSX of list in a seperate file.
  //   const colorList = colorNames.map((colorName) => (
  //     <Color colorName={colorName} />
  //   ));

  //    We have an warning -> Each child in a list should have a unique "key" prop. For solving this do this. id is a great choice in this case as it is unique. We can set the key to anything as long as its unique. The key prop is not accessible in child component. It will give you a warning.
  //   Key help react identify that which item has been added or removed or changed.

//   const colorList = colorNames.map((colorName) => (
//     <Color key={colorName.id} colorName={colorName} />
//   ));
  return (
    <div>
      {
        // Using Map | Way 2
        // names.map((name) => (
        //   <h1>{name}</h1>
        // ))

        // Assigning it to a variable | Way 3
        nameList

        // Displaying color names with map method
        // colorList

        // Displaying color list from a component
        // colorList

        //   {/* Basic | Way 1*/}
        //   {/* <h1>{names[0]}</h1>
        //   <h1>{names[1]}</h1>
        //   <h1>{names[2]}</h1> */}
      }
    </div>
  );
}

export default List;
