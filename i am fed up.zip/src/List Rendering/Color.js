import React from "react";

function Color({ colorName, key }) {
  return (
    <div>
      <h1>
        Color name is: {colorName.color}, value is {colorName.value}
      </h1>
    </div>
  );
}

export default Color;
