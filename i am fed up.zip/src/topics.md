1. what is state, use of states in react. A counter program on click of a button using states.
2. prop drilling
3. state manipulation
4. useContext useReducer
