# useState Hook
useState is used to transfer values between 2 components. It lets us use state variables in functional component. 

It takes a initial value as argument and returns a array of 2 entries.

SYNTAX:
const[state, setState]=useState(initialState);
> state: contains the initial state being passed as argument.
> setState: is used for updating the state.

We can also pass a function as an argument to the useState hook. Example:
const [sum, setsum] = useState(function generateRandomInteger(){5+7);})
Here the answer of the generateRandomInteger function will be used as initial value. 