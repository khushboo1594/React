import React, { Component } from "react";

export default class RenderExample extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "khushboo",
    };
    console.log(this.props.name);
  }
  render() {
    // console.log(this.props.name);

    // console.log("Inside render method "+this.props.name);
    console.log("Inside render method ");
    return (
      <div>
        {/* <h1>Render Example, {this.props.name}</h1> */}
        <h1>Render Example, {this.state.name}</h1>
        <button
          onClick={() => {
            this.setState({ name: "patel" });
          }}
        >
          Click
        </button>
      </div>
    );
  }
  render() {
    // console.log(this.props.name);

    // console.log("Inside render method "+this.props.name);
    console.log("Inside render method ");
    return (
      <div>
        {/* <h1>Render Example, {this.props.name}</h1> */}
        <h1>Render Example 2, {this.state.name}</h1>
        <button
          onClick={() => {
            this.setState({ name: "patel" });
          }}
        >
          Click
        </button>
      </div>
    );
  }
}
/*
When render is called?
    1. when component is loaded
    2. when state is updated
    3. when prop is updated

> 2 tarah se we can update the page
    1. by passing props from parent to child component
    2. by using state (same class me use karte hai state)

> how to access props in constructor?
    pass "props" to both constructor and super. then only you can access props in constructor. you need to call super(props) method before any other statement. If you do not call super(props) method, this.props will be undefined

**QUESTIONS**
    > difference kya hai props aur state use karne me?? 
*/
 