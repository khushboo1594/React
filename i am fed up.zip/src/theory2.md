# What is React?
It is a Javascript library. It is used for making UI. It is used for making single page application.

# Why React is fast?
Because it uses virtual DOM. For example you have a list of colddrinks. When you want to update the list in real DOM it updates the whole list while in virtual DOM it only updates the item being updated to the list.

# Notes
1. React is developed by Facebook/Meta
2. It was released in 29 May 2019
3. Current version - 17.0.2
4. Applications that used Reactjs - netflix, whatsapp web, instagram, airbnb

# index.js vs app.js
sabse pehli file index.js hi run hoti hai. app.js index me imported hai

# what is in package.json?
name, version and list of all the dependencies

# what is the most imp file and why don't we push the node_modules folder in git. how to get information about all the dependencies then?
most important file - package.json.  we don't push the node_modules folder because it contains all the dependencies so it becomes a very large file. all the dependencies are listed in package.json

# how to add new npm package?
npm install <package name>.if you want a particular version of a package package.json me jake package ka version likh do jo chahie and then do npm install <package name>. 

# how to add delete npm package?
npm uninstall <package name>.

# how to make custom commands?
package.json me jake scripts key me jake naam change kardo and then npm run <script name>

# what is component?
component is the basic or smallest resuable unit of react.

# types of component
1. functional
2. class
3. pure
4. higher order 
5. controlled
6. uncontrolled

# how to make class component?

# what is jsx?

# State in functional component
## what is state?
state is a object. just like we store data in variable, we can aslo store data in object.
## what is the use of state?
because when the variable is updated the component is not updated, but when we use state the component is updated and our purpose is fulfilled.
## define state
## how to update state with a button click?
## how state works?

# functional component me render ki zarurt nahi hoti. class component me must hai

# what is useState hook?
usestate is function that allows you to pass information between components. it allows us to have state variables in functional component. 
* SYNTAX:
the hook takes initial value as argument and returns an array of 2 entries.
const [state, setState]=useState(initialState);
> state is the initial state 
> setState is used for updating the state

We can also pass a function as an argument if the initial state has to be computed. And the value returned by the function will be used as the initial state.

const [sum, setsum] = useState(function generateRandomInteger(){5+7);})
The above function is oneline function which computes the sum of two numbers and will be set as the initial state.

# component ko import karte time kuch bhi naam de skte hai

# it is not necessary to keep the file name and component name same.

# difference between props and state? agar dono hi hum use karte hai for passing data between components then difference kya hai dono me?
props mutable nahi hai. states mutable hoti hai. 

# hum bina form k bhi data submit kar sakte hai react me.

# always remember if you are making a functional component then start naming it with a capital letter. otherwise it will give error

# componentWillUnmount ke case me child component should be a class component, parent component can be either functional or class  

# How to create a project in React?
npx create-react-app <projectName>
    Cannot create a project named "to-do List"/ "to-do list" because of npm naming restrictions:

    * name can only contain URL-friendly characters
    * name can no longer contain capital letters
