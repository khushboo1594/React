# Stateful and stateless components
If a component mantains state then it will be called as *stateful component*.
And if a component renders only UI that will be called as *statelss component*

# Lifting up the state

