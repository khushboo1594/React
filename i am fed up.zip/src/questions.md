# Questions

1. What is angular used for? Is it also used for making single page application?
2. Aur kaun si language se single page application bante hai?
3. npx create-react-app vs npm install
4. package.json vs package_lock.json
5. variables q use nahi karte? q states aur props use karte hai?
6. are props object?
7. difference between props and component? agar dono hi hum use karte hai for passing data between components then difference kya hai dono me?
8. how to apply vaildation in react using libraries?
9. difference between props and state? 
