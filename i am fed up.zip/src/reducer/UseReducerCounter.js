import React, { useReducer } from "react";
const intitialState = 0;
const reducer = (currentState, action) => {
  switch (action) {
    case 'increment':
      return currentState + 1;
    case 'decrement':
      return currentState - 1;
    case 'reset':
      return intitialState;
    default:
      return currentState;
  }
};
function UseReducerCounter() {
  const [count, dispatch] = useReducer(reducer, intitialState);

  return (
    <div>
      <center>
        Example of useReducer
        <h1>{count}</h1>
        <button onClick={()=>{dispatch('increment')}}>Press to Increment</button>
        {/* Yaha hum arrow function use kar rahe hai. Kahi kahi nahi bhi karte hai. To kaha arrow function use karna hai kaha nahi? */}
        <button onClick={()=>{dispatch('decrement')}}>Press to Decrement</button>
        <button onClick={()=>{dispatch('reset')}}>Press to Reset</button>
      </center>
    </div>
  ); 
}

export default UseReducerCounter;
