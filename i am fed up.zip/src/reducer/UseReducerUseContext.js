import React from "react";
import ComponentC from "./ComponentC";

export const UserContext = React.createContext();

function UseReducerUseContext() {
  return (
    <div>
      <h1>UseReducerUseContext</h1>
      <UserContext.Provider value="khushboo">
        <ComponentC />
      </UserContext.Provider>
    </div>
  );
}

export default UseReducerUseContext;

