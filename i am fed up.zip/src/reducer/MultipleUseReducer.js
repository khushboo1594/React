import React, { useReducer } from "react";
const intitialState = 0;
const reducer = (currentState, action) => {
  switch (action) {
    case 'increment':
      return currentState + 1;
    case 'decrement':
      return currentState - 1;
    case 'reset':
      return intitialState;
    default:
      return currentState;
  }
};
function MultipleUseReducer() {
  const [count, dispatch] = useReducer(reducer, intitialState);
  const [count2, dispatch2] = useReducer(reducer, intitialState);

  return (
    <div>
      <center>
        Example of Multiple useReducer
        <h1>Count - {count}</h1>
        <button onClick={()=>{dispatch('increment')}}>Press to Increment</button>
        <button onClick={()=>{dispatch('decrement')}}>Press to Decrement</button>
        <button onClick={()=>{dispatch('reset')}}>Press to Reset</button>
        <h1>Count2 - {count2}</h1>
       <button onClick={()=>{dispatch2('increment')}}>Press to Increment</button>
        <button onClick={()=>{dispatch2('decrement')}}>Press to Decrement</button>
        <button onClick={()=>{dispatch2('reset')}}>Press to Reset</button>
      </center>
    </div>
  );
}

export default MultipleUseReducer;

