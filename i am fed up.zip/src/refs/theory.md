# what it does?

- it lets us access DOM node directly in react
- it lets you access input data

# Steps for creating ref using using react.createRef

- Step 1: create a ref in constructor-> React.createRef() method
- Step 2: attach this ref to input in render method -> for this we use reserved keyword - ref
- Step 3: to access the focus method of current property in componentDidMount **_this.inputRef.current.focus()_**

**_NOTE_**
**_Accessing Refs_**
\*Accessing Refs
When a ref is passed to an element in render, a reference to the node becomes accessible at the current attribute of the ref.

const node = this.myRef.current;
The value of the ref differs depending on the type of the node:

When the ref attribute is used on an HTML element, the ref created in the constructor with React.createRef() receives the underlying DOM element as its current property.
When the ref attribute is used on a custom class component, the ref object receives the mounted instance of the component as its current.
You may not use the ref attribute on function components because they don’t have instances\*

# can make refs in 2 ways

- createRef()
- callback ref

# Steps for creating ref using callback ref (it is a older approach)

- Step 1: create a property in constructor. Assign a value null to it **_this.cbRef = null_**
- Step 2: make a method to that accepts a DOM element as its parameter and assigns it to the property we just created (in constructor). **_this.setcbRef_**
- Step 3: attach the reference variable to input in render method -> for this we use reserved keyword - ref
- Step 4: to access the focus method of current property in componentDidMount like this -> **_this.cbRef.focus()_**

# ways to create ref

- React.createRef()
- call back ref
- string ref

**_If there are trying to focus on 2 input boxes only the last one will be focused _**

**_It is also possible to add refs to class components_**

# Forwarding ref

It is used when we want to pass down the ref from the parent to the child component.

# Steps for Forwarding ref

1. create a ref in parent component
2. attach the ref to the child component using the ref attribute
3. forward this ref to the input element to the child component
   It can be achieved by using forwardRef method React Library
   **STEPS**
   1. replace the traditional function with the arrow function
   2. for forwarding the ref we will be using React.forwardRef(). It will be assigned to the arrow function. It takes a component as its parameter.

**_Hame refs jyada use nahi karni chahiye. If we can acheive something declaratively then do not do it with ref_**
