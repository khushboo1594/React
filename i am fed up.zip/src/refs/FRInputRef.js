import React from 'react'

// function FRInputRef() {
//   return (
//     <div><input type="text" /></div>
//   )
// }



export default FRInputRef