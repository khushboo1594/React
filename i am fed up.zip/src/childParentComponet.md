> parent component wo hota hai jisme hum prop pass karte hai

> child component wo hota hai jisme hum prop access karte hai by writing "this.props" 
