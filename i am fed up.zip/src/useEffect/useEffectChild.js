import React, { useEffect, useState } from "react";

export default function UseEffectChild(props) { 
  return (
    <div>
      <center>
        <h1>Hi!! I am useEffect Child. Props in useEffect example</h1>
        <h2>{props.name}</h2>
      </center>
    </div>
  );
}

/*
QUESTIONS
 1. 
*/

