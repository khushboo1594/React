/* 
    > For calling useEffect only once - we need to pass an empty array as second argument to useEffect. It tells   React that this useEffect hook is not dependent on any prop/ state, so do not call it on re-rendering. 
*/

import React, { useState, useEffect } from "react";
import StudentClass from "./StudentClass";

export default function UseEffect() {
  const [x, setX] = useState(0);
  const [y, setY] = useState(0);
  const [show, setShow] = useState(true);
  function updateMouse(e) {
    console.log("inside updateMouse function");
    setX(e.ClientX);
    setY(e.ClientY);
  }
  useEffect(() => {
    console.log("inside useEffect Hook");
    // window.addEventListener("mousemove", updateMouse);

  });

  return (
    <div>
      <center>
        <h1>useEffect Hook Implementing Different life cycle Methods</h1>
        {/* <h2>
          x:{x}, y:{y}
        </h2> */}
        {show?<StudentClass/>:null}
        <button onClick={()=>{setShow(!show)}}>Click me! to hide the coordinates</button>
      </center>
    </div>
  );
}

/* 
QUESTIONS
    > why it is not working?
*/
 
