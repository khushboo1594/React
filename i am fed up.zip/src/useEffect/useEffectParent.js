/*
TOPICS COVERED:
    > what is useEffect hook?
        jaise class component me life cycle methods hoti thi, un life cycle methods ko functional component me useEffect hook se use kar sakte hai. 
        useEffect is a method, which is called(implicitly) when component is mounted, state/ prop is updated, however hum control kar sakte hai k kis state/ prop k update hone par call kare use
        we can do conditional programming in this k when to call it
            jab component mount ho tab
            ya jab koi state/ prop update ho tab
        useEffect = componentWillMount + componentDidUpdate + componentWillUnmount
        it is a function and it takes function as a argument  
        it is called when component is mounted, updated
    > how to use it?
    > example of useEffect
    > useEffect with specific states and props
    > conditional useEffect is same as - useEffect with specific states and props
*/

import React, { useEffect, useState } from "react";
import UseEffectChild from "./useEffectChild";

export default function UseEffect() {
    const [count, setCount]=useState(0);
    const [name, setName]=useState('khush');
    // useEffect(()=>{
    //     console.log("use effect hook", name);
    // },[name]);
    useEffect(()=>{
        console.log("use effect hook");
        document.title=`Clicked ${count} times`;
    })
    //  hum jitne chahe utne useEffects define kar sakte hai based on different props and states
    // useEffect(()=>{
    //     console.log("use effect hook", count);
    // },[count]); 
    // as second argument we can pass an array of arguments for whom we want the useEffect to be called.
  return (
    <div>
      <center>
        <h1>useEffect Parent</h1>
        <h2>{count}</h2>
        <h2>{name}</h2>
        <UseEffectChild name="I am a prop being passed from parent to child"/>
        <UseEffectChild>this is children component</UseEffectChild>
        <button onClick={()=>setCount(count+1)}>Update Count</button>
        <button onClick={()=>setName("pupu")}>Update name</button>
      </center>
    </div>
  );
}

/*
QUESTIONS
 1. kya props functional component me bhi use kar sakte hai?
 2. what are side effects in react? codevolution
*/
