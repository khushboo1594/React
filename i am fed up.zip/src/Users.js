import React from "react";

export function Users() {
    return (
        <div className="App">
         <h1>Hello Users!!</h1>
        </div>
      );
}

// export default Users; 