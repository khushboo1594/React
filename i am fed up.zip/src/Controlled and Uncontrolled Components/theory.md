# Controlled Component
An input form element whose value is controlled by react is called a contolled component.
 