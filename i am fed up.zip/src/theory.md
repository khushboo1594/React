# TOPICS TO STUDY
1. uselayouteffect
2. memo
3. useMemo (useMemo and memo are different)

# what is virtual DOM?
DOM stands for Document Object Model. The DOM represents an HTML document with a logical tree structure. Each branch of the tree ends in a node, and each node contains objects.
Virtual DOM: React keeps a lightweight representation of the real DOM in the memory, and that is known as the virtual DOM. When the state of an object changes, virtual DOM changes only that object in the real DOM, rather than updating all the objects.

# What is the virtual DOM? How does react use the virtual DOM to render the UI?
As stated by the react team, virtual DOM is a concept where a virtual representation of the real DOM is kept inside the memory and is synced with the real DOM by a library such as ReactDOM.

> Why was virtual DOM introduced? 

DOM manipulation is an integral part of any web application, but DOM manipulation is quite slow when compared to other operations in JavaScript. The efficiency of the application gets affected when several DOM manipulations are being done. Most JavaScript frameworks update the entire DOM even when a small part of the DOM changes.

For example, consider a list that is being rendered inside the DOM. If one of the items in the list changes, the entire list gets rendered again instead of just rendering the item that was changed/updated. This is called inefficient updating.

To address the problem of inefficient updating, the react team introduced the concept of virtual DOM.

> How does it work?

For every DOM object, there is a corresponding virtual DOM object(copy), which has the same properties. The main difference between the real DOM object and the virtual DOM object is that any changes in the virtual DOM object will not reflect on the screen directly. Consider a virtual DOM object as a blueprint of the real DOM object. Whenever a JSX element gets rendered, every virtual DOM object gets updated.

**Note- One may think updating every virtual DOM object might be inefficient, but that’s not the case. Updating the virtual DOM is much faster than updating the real DOM since we are just updating the blueprint of the real DOM.

React uses two virtual DOMs to render the user interface. One of them is used to store the current state of the objects and the other to store the previous state of the objects. Whenever the virtual DOM gets updated, react compares the two virtual DOMs and gets to know about which virtual DOM objects were updated. After knowing which objects were updated, react renders only those objects inside the real DOM instead of rendering the complete real DOM. This way, with the use of virtual DOM, react solves the problem of inefficient updating.

# React Class features vs. Hooks equivalents
https://medium.com/soluto-engineering/react-class-features-vs-hooks-equivalents-745368dafdb3

# miscellaneous
1. it was developed by facebook
5. npm - node package manager
6. npm init -> creates package.json(manifest file), list all the dependencies
7. npm install <package name> --save -> it saves the dependency locally i.e. in the project and add to package.json
8. npm install <package name> -g -> it saves the dependency globally. which means you not only can use the package in the folder but is accessible in your whole machine.
9. npm install <package name> --save -dev -> use it only in development.
10. when uploading n github you do not upload node_modules as it contains all the installed dependency so it is a huge file. 
11. create-react-app <app name> app name can't be capital.
13. agr hum node_modules folder delete kar denge to hum dependecies ko waps install kar skte hai by npm install
14. in functional component function name always start with a capital letter. you can make it as arrow function also.
15. whitespaces are not counted
16. if you want to render a function always start it with a capital letter
17. for setting values in the JSX tag use {}. always pass something that returns some value. expression pass kar skte hai, statement nahi
18. inline css is stronger than file


1. cd.. -> to move back
2. clear -> to clear console
3. to stop the dev server -> ctrl+c

*************************************************QUESTIONS******************************************************************
1. object destructuring
2. hot reloading 