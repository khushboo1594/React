import React, { PureComponent } from "react";

class PureComponentExample extends PureComponent {
  render() {
    console.log("Pure Component Render");
    return <div>PureComponent - {this.props.name}</div>;
  }
}

export default PureComponentExample;

// isme to kuch constructor hai hi nahi. to fir kaise we are able to use this.props.name?
