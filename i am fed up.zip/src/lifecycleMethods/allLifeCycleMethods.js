import React from "react";

export default class LifeCycleMethods {
    constructor(){
        super();
        console.log("constructor");
    }
    componentWillMount(){
        console.log("componentWillMount");
    }
    componentDidMount(){
        
    }
  render() {
    return (
      <div>
        <h1>We are going to learn about different life cycle methods</h1>
      </div>
    );
  }
}
