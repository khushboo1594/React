/* 

*/

import React, { Component } from "react";
import StudentClass from "./StudentClass";

export default class LifeCycle extends Component {
  constructor() {
    super();
    this.state = {
      x: 0,
      y: 0,
      show: true,
    };
  }
  //   componentDidMount() {
  //     window.addEventListener("mousemove", (e) => {
  //       this.setState({ x: e.clientX, y: e.clientY });
  //     });
  //   }
  
  render() {
    return (
      <div>
        <center>
          <h1>Different Life Cycle Methods</h1>
          {/* <h2>x:{this.state.x}, y:{this.state.y}</h2> */}
          {this.state.show ? <StudentClass name="Khushboo" /> : null}
          <button onClick={()=>{this.setState({ show: !this.state.show })}}>
            Click me! to hide Student Name
          </button>
        </center>
      </div>
    );
  }
}

/* 
QUESTIONS
    > this.setState hota hai? k only setState?
*/

/* 
NOTES
    > sari lifecycle methods class k andar hi likhi jati hai  
    > onClick par hamesha arrow function lagta hai
    > It is this.setState 
    > componentWillUnmount jis component ko remove kar rahe hai wahan lagate hai
    > In function it is props           In class it is this.props
*/