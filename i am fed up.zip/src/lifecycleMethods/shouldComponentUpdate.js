/*
    shouldComponentUpdate stops rendering
    we can decide when to re-render and when to not
    by default it stops rendering
    by returning true you can continue rendering the changes
*/

import React, { Component } from "react";

export default class ShouldComponentUpdate extends Component {
  constructor() {
    super();
    // console.log("constructor");
    this.state = {
      counter: 0,
    };
  }

  //   componentDidMount() {
  //     console.log("componentDidMount");
  //   }

  componentDidUpdate() {
    console.log("componentDidUpdate");
  }
  shouldComponentUpdate() {
    console.log("shouldComponentUpdate", this.state.counter);
    // ye counter ko update to hone de raha hai, but by default ye render nahi hone deta hai update. on returning true it allows to render.
    if (this.state.counter > 5 && this.state.counter < 10) {
      return true;
    }
  }
  render() {
    console.log("render");
    return (
      <div>
        <center>
          <h1>Should Component Update</h1>
          <h1>{this.state.counter}</h1>
          <button
            onClick={() => {
              this.setState({ counter: this.state.counter + 1 });
            }}
          >
            Click
          </button>
        </center>
      </div>
    );
  }
}

/*

*/
