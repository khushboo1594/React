> life cycle methods keval class components me hoti hai.

> life cycle methods functional component me use karne k liye we have to use hooks

> constructor gets called as soon as the component is made

> is constructor a part of life cycle? YES

> the constructor gets called before render

> super in constructor is not a part of life cycle methods

> constructor me hum state define karte hai taki wo render k pehle hi ready rahe

