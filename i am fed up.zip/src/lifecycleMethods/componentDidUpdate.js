/*
TOPICS COVERED
1. previous state/ prop 
*/

import React, { Component } from "react";

export default class ComponentUpdate extends Component {
  constructor() {
    super();
    // console.log("constructor");
    this.state = {
      counter: 0,
    };
  }

  //   componentDidMount() {
  //     console.log("componentDidMount");
  //   }

  componentDidUpdate(preProps, preState, snapshot) {
    console.log("componentDidUpdate ", preState);
    console.log("snapshot ", snapshot);
    /* 
        ye undefined hi aata hai
        If your component implements the getSnapshotBeforeUpdate() lifecycle (which is rare), the value it returns will be passed as a third “snapshot” parameter to componentDidUpdate(). Otherwise this parameter will be undefined.
    */
    // console.log("componentDidUpdate " + preState); // isme object object aa raha hai
    // alert("componentDidUpdate " + preState);
    /*
    with the help of preState we can we can compare current and prev state and take some action accordingly 
    */

    // updating state in componentDidUpdate along with some condition
    if (this.state.counter === 10) {
      this.setState({ counter: "ab nahi karna update" });
    } else {
      console.log("counter", this.state.counter);
    }
    // agar bina condition k karte to ye infinite loop me chala jata 
  }

  render() {
    // console.log("render");
    return (
      <div>
        <h1>Component Did Update</h1>
        <h1>{this.state.counter}</h1>
        <button
          onClick={() => {
            this.setState({ counter: this.state.counter + 1 });
          }}
        >
          Click
        </button>
      </div>
    );
  }
}

/*
> whenver prop/ state get updated render and componentDidUpdate gets called.

> never update prop/ state in componentDidUpdate bina kisi condition k because tum prop update karoge to componentDidUpdate will get called then waps se prop update hoga then wapas se componentDidUpdate will get called and this will become a loop. if you have given some condition in componentDidUpdate then it's fine.

    You may call setState() immediately in componentDidUpdate() but note that it must be wrapped in a condition , or you’ll cause an infinite loop

SYNTAX:
    componentDidUpdate(prevProps, prevState, snapshot)
*/
