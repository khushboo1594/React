/*
    > when componentWillUnmount() is called? 
        pehli baat to unmounting ka matlab kya hua?
            unmounting matlab jab bhi hamara component DOM se remove hoga
            react me jab hum koi component show/ hide karte hai, wo hide/ show hota nahi hai it is completely removed from the DOM and during this time componentWillUnmount is called.

        NOTE: 
        ise waha call karna hai jaha component banaya hai na ki jaha component use kiya hai

    > use?
        1. 
*/

import React, { Component } from "react";
import RemoveComponent from "./componentToBeRemoved";

export default class ComponentUnmount extends Component {
  constructor() {
    super();
    this.state = {
      show: true,
    };
  }
  
  render() {
    return (
      <div>
        <center>
          {this.state.show ? <RemoveComponent /> : null}
          <button
            onClick={() => {
              this.setState({ show: !this.state.show });
            }}
          >
            Toggle button
          </button>
        </center>
      </div>
    );
  }
}
