import React, { Component } from "react";
import Hero from "./Hero";
import ErrorBoundary from "./ErrorBoundary";
function AppCopy() {
  return (
    <div>
      <ErrorBoundary>
        <Hero heroName="Superman" />
      </ErrorBoundary> 
      <ErrorBoundary>
        <Hero heroName="joker" />
      </ErrorBoundary>
    </div>
  );
}

export default AppCopy;

/*
Jaise hi hum heroName me joker dalte hai kuch bhi nhi dikhta screen par aur error aane lagti hai console par. Yaha par what do we want is that k jis me error aa rahi hai keval wahi component fallback ho UI me baki display ho. 
*/
