import React from "react";
import { Button } from "react-bootstrap";

export default function MyBootStrap() {
  return (
    <div>
      <center>
        <h1>BootStrap Example</h1>
        <Button variant="secondary">Left</Button>
      </center>
    </div>
  );
}
