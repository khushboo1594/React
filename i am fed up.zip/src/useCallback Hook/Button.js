import React,{memo} from 'react';

function Button({handleClick, children}) {
    console.log(`Rendering ${children}`);
  return (
    <div>
        <button onClick={handleClick}>{children}</button>
    </div>
  )
}

export default memo(Button);