# NOTE 1: 
This is because of something called "referential equality".
Every time a component re-renders, its functions get recreated. Because of this, the addTodo function has actually changed.

# Referential equality
Assigning objects to variables gives us a. memory location instead of the value of the object. React then uses the. reference to that memory location to determine if two objects are different and. only re-renders when the two objects are stored in different places in memory
----------------------------------------------------------------------------------------------------------------------------
