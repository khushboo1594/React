import React,{memo} from "react";

function MemoComp({ name }) {
  console.log("Memo component");
  return <div>MemoComp - {name}</div>;
}

export default memo(MemoComp);
// export default MemoComp;

// jab tak humne ise memo me nahi dala tha to jab bhi parent ki state change ho rahi thi child i.e. memo component was also being rendered again. so to prevent this we wrapped it in HOC called memo. **what React.memo does to a functional component memo does for the class component**

// QUESTION??? child component kuch bhi mtlb class ho ya functional component ho ,chalega? memo k case me?