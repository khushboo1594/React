What pure component is to class component React.memo is for functional component
---------------------------------------------------------------------------------
memo is HOC. it accepts a component as argument and returns a new component
---------------------------------------------------------------------------------
problem thi kya exactlt??? samjah nhi aae?
state update ho rahi thi, har 2 second me and we were passing it to the MemoComp as prop so in this way prop was also changing which was causing the re-rendering but the the state was same it was not changing, so re-rednering faltu me hi ho rahi thi. to prevent this we use memo for class components. 
now the question arises k state to component ki bhi change nahi ho rahi hai to can we stop the re-rendering of parent component also? if yes, the how?

# memo shouldComponentUpdate ka equivalent hai  