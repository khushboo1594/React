import React, { Component, memo } from "react";
import MemoComp from "./MemoComp";
export class Parent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      name: "Khushboo",
    };
  }
  componentDidMount() {
    setInterval(() => {
      this.setState({
        name: "Khushboo",
      });
    }, 2000);
  }
  render() {
    console.log("*****************************Parent***********************");
    return (
      <div>
        Parent
        <MemoComp name={this.state.name} />
        {/* <MemoComp name="passing static value" /> */}
      </div>
    );
  }
}

export default memo(Parent);
// yaha par parent ki rendering q nahi ruk rahi hai? functional component me to hum useCallback ka istemaal karte the to define the dependency what to do in class component?

// 
