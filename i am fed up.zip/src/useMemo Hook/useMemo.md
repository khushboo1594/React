# Definition:
useMemo is a hook that will recompute the cached value only when one of the dependencies have changed.

# useMemo v/s useCallback
When you need to cache a callback use useCallback. When you need to cache a value use useMemo