class Car {
  constructor(color, name) {
    //constructor is called automatically when the Object is created
    // name has to be eaxct
    this.color = color;
    this.name = name;
  }

  display() {
    console.log("Name:" + this.name + " Color:" + this.color);
  }
}

class Audi extends Car {
  constructor(color, name, model) {
    super(color, name);
    this.model = model;
  }

  display() {
    super();
    console.log("Model:" + this.model);
  }
}

var car1 = new Car("black", "Skoda").display();
var audi1 = new Audi("Ink blue", "Audi", "XML").displayA();
