/*
1. data types range
2. how promises replaced callback with example
3. how to stop a setInterval after executing for let's say 5 seconds
*/