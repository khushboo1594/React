/*
We prefer async await over promises
*/

function makeRequest(location) {
  return new Promise((resolve, reject) => {
    console.log(`Making request to ${location}`);
    if (location === "Google") {
      resolve("Google Says hi!!");
    } else {
      reject("We can only talk to Google");
    }
  });
}

function processRequest(response) {
  return new Promise((resolve, reject) => {
    console.log("Processing request");
    resolve(`Extra information ${response}`);
  });
}

// This is not how you do it. You need to do chaining
// makeRequest("Google")
//   .then((message) => console.log(message))
//   .catch((message) => console.log(message));

// processRequest("Hello")
//   .then((message) => console.log(message))
//   .catch((message) => console.log(message));

//   Chaining of promises
makeRequest("Google")
  .then((message) => {
    console.log(message);
    return processRequest(message);
  })
  .then((message) => console.log(message))
  .catch((message) => console.log(message));

//   through async await
async function doWork() {}
// /**
//  * async returns a promise
//  * await waits for a promise
//  */

// // async function name() {
// //     return "hello";
// // }

// /**
//  * above eg is same as below
//  */

// // function name() {
// //     return Promise.resolve("hello");
// // }

// async function myFunc() {
//     return 1;
// }

// myFunc().then(alert);
