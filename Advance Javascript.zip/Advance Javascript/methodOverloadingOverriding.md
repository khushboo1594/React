# Method overloading in Java
Jab 1 hi naam ki 1 se jyada methods ho, unme difference parameters ka ho. Parameter me diff hum 3 tarike se kar skte hai -
* Number
* Sequence
* Data types
***It is not possible to overload a method in Java by changign it's return type. Why??***
class Adder{  
    static int add(int a,int b){return a+b;}  
    static double add(int a,int b){return a+b;}  
}  
class TestOverloading3{  
    public static void main(String[] args){  
    System.out.println(Adder.add(11,11));//ambiguity  
}}  
***This is why***

# Overriding v/s overloading in Java
A method is overridden only when the name and signature of the method is the same, otherwise it is simply overloaded.

# Method overloading -
Method overloading is when 2 or more methods have same name but different 