var add= (a,b)=>a+b;
var add= (a,b)=>a*b;
// console.log(add(2,3));
a => a + 100;
5;

