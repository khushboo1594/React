// console.log(a);

/*
Promises were introduced in ES6.
Promises were meant to replace callback functions.

Producing code: is the code that does something and takes time. For example - uploading a file over the server
Consuming code: is the code that requires the result of the producing code once it is ready
Promise: it links producing and the consuming code

executor is automatically exceuted once new promise is created. 
  executor after doing the job calls resolve or reject
    resolve - it gives the result of the executor
    reject - gives error if any

promise returns 2 things -
  1. state- fulfilled/rejected
  2. result- value/error
  initially state - pending result - undefined
  we cannot access promise properties state or result

ek hi baar call hota hai resolve ya reject. uske baad jo bhi likhoge wo excute nahi hoga
*/

// Example 1 - Web Dev Simplified/////////////////////////////////
// this is how you make a promise
var promise = new Promise((resolve, reject) => {
  var x = 1 + 1;
  if (x === 1) {
    resolve("Success");
  } else {
    reject("Failed");
  }
});
// console.log(promise);

// this is how you use a promise
promise
  .then((message) => console.log(message))
  .catch((message) => console.log(message));

// How to reoslve all the promises at once
const promise1 = new Promise((resolve, reject) => {
  resolve("Hello I am promise one");
});

const promise2 = new Promise((resolve, reject) => {
  reject("Hello I am promise two. I got rejected :-C");
});

const promise3 = new Promise((resolve, reject) => {
  resolve("Hello I am promise three");
});

Promise.all([promise1, promise2, promise3])
  .then((message) => console.log(message))
  .catch((message) => console.log(message));
// this is not working properly. see it once in your free time.

// Example 2////////////////////////////////////////////////////
// var promise = new Promise(function (resolve, reject) {
//   setTimeout(resolve("done"), 5000);
//   console.log("hello");
// });

// var promise = new Promise(function (resolve, reject) {
//   setTimeout(reject(new Error("oops")), 5000);
// });

// // console.log(promise);

// promise.then(
//     result => console.log(result), error => console.log(error)
// )
