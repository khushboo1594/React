async function showData() {
  // read our JSON
  let response = await fetch(
    "https://jsonplaceholder.typicode.com/todos"
  );
  let data =  await response.json();
  console.log(data);

  // console.log("dateTime");
}

showData();
