[
    {
      "sha": "2cca9a9d09fdd45819832294225aa3721fa5a2d4",
      "node_id": "C_kwDOBY7uftoAKDJjY2E5YTlkMDlmZGQ0NTgxOTgzMjI5NDIyNWFhMzcyMWZhNWEyZDQ",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@users.noreply.github.com",
          "date": "2022-02-21T19:48:37Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-21T19:48:37Z"
        },
        "message": "Merge pull request #2885 from Rnbsov/patch-2\n\nMissed exclamation mark",
        "tree": {
          "sha": "529f3a2aae7cc1f62699337f41e938eea7f4efe5",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/529f3a2aae7cc1f62699337f41e938eea7f4efe5"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/2cca9a9d09fdd45819832294225aa3721fa5a2d4",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiE+yVCRBK7hj4Ov3rIwAA33wIAIdhRKGjVKYVHu912WekUFSW\nP2ziKOwISvABsnOGhu/prdTNARYk+6aX4U+Z6iSULecq+eNRWvkrSjUuoqKrdKeD\n4YN1A0eKZoUjcbRcIImKC7ZrD42fdvss8YUPKmKoKy44lNcg2bzP7f3v+VGZuWSX\nMpqp9iooL55FsmtzNk94EuEN/9nLfD38QTcvDEmd2u8MtheVyC3rn1kFLP5BsmaK\nHm2v6a7mzsgchgAf4jvDDbXjvDe2CyB9FHv1dNwlPM2WEYHpL17fjAGIseMte/D+\nZJ0h+tXlWgaEqWl0esiLlDpovZWcLjXY1OWDf9nihCLqrukQjp2pas1QEeSTyvU=\n=GzHb\n-----END PGP SIGNATURE-----\n",
          "payload": "tree 529f3a2aae7cc1f62699337f41e938eea7f4efe5\nparent bb41c392476cd7e71fcb865878d8777ddadba2ee\nparent e1db5dcebea063e4afe2252894ded11dff9d595c\nauthor Ilya Kantor <iliakan@users.noreply.github.com> 1645472917 +0300\ncommitter GitHub <noreply@github.com> 1645472917 +0300\n\nMerge pull request #2885 from Rnbsov/patch-2\n\nMissed exclamation mark"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/2cca9a9d09fdd45819832294225aa3721fa5a2d4",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/2cca9a9d09fdd45819832294225aa3721fa5a2d4",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/2cca9a9d09fdd45819832294225aa3721fa5a2d4/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "bb41c392476cd7e71fcb865878d8777ddadba2ee",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/bb41c392476cd7e71fcb865878d8777ddadba2ee",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/bb41c392476cd7e71fcb865878d8777ddadba2ee"
        },
        {
          "sha": "e1db5dcebea063e4afe2252894ded11dff9d595c",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/e1db5dcebea063e4afe2252894ded11dff9d595c",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/e1db5dcebea063e4afe2252894ded11dff9d595c"
        }
      ]
    },
    {
      "sha": "bb41c392476cd7e71fcb865878d8777ddadba2ee",
      "node_id": "C_kwDOBY7uftoAKGJiNDFjMzkyNDc2Y2Q3ZTcxZmNiODY1ODc4ZDg3NzdkZGFkYmEyZWU",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@users.noreply.github.com",
          "date": "2022-02-21T19:40:28Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-21T19:40:28Z"
        },
        "message": "Merge pull request #2883 from Vitruvius21/patch-1\n\nFix LI content numbers",
        "tree": {
          "sha": "5a5efd64c06c754aeb407b1e3579ad08d764b046",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/5a5efd64c06c754aeb407b1e3579ad08d764b046"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/bb41c392476cd7e71fcb865878d8777ddadba2ee",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiE+qsCRBK7hj4Ov3rIwAAcPoIAFizmTsBgqFEUZ4T9K+HHUK0\niNYim5bxM56udizU0eA2hXjmAwPAtd1i56WJLScLe1WJIf0JizAZDzkvXtLV0TD6\ncASf80PeBBEgNX3CRSaKxMsuSS5MwScCipPbGMJ5ZF1MxB8BLGnWYeCKHAuY3j7a\nvzazYS7hua0dgsmBwmE3NuSXTsYKNLfPhN5XdcTp/YGwFOe5OrGQqWOkmkA0Wa0O\nXY+EprO/Ds1jXVSAK3xyw0NqyH2Ids6fSd5K09w2qli+Bt1drspb+p97yVCPPzyx\n4+CZP+kWVe33u6hPhc0Y2rc4Sw6d3NUnWjsEp+i9RrPuJ5DaoECxoai1NwrKx7k=\n=U5xs\n-----END PGP SIGNATURE-----\n",
          "payload": "tree 5a5efd64c06c754aeb407b1e3579ad08d764b046\nparent e2f9e5840737e00846bfd492192d8a3828820c60\nparent 16ace5ae32b44a84afb981af32958704fb5b1310\nauthor Ilya Kantor <iliakan@users.noreply.github.com> 1645472428 +0300\ncommitter GitHub <noreply@github.com> 1645472428 +0300\n\nMerge pull request #2883 from Vitruvius21/patch-1\n\nFix LI content numbers"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/bb41c392476cd7e71fcb865878d8777ddadba2ee",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/bb41c392476cd7e71fcb865878d8777ddadba2ee",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/bb41c392476cd7e71fcb865878d8777ddadba2ee/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "e2f9e5840737e00846bfd492192d8a3828820c60",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/e2f9e5840737e00846bfd492192d8a3828820c60",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/e2f9e5840737e00846bfd492192d8a3828820c60"
        },
        {
          "sha": "16ace5ae32b44a84afb981af32958704fb5b1310",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/16ace5ae32b44a84afb981af32958704fb5b1310",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/16ace5ae32b44a84afb981af32958704fb5b1310"
        }
      ]
    },
    {
      "sha": "e1db5dcebea063e4afe2252894ded11dff9d595c",
      "node_id": "C_kwDOBY7uftoAKGUxZGI1ZGNlYmVhMDYzZTRhZmUyMjUyODk0ZGVkMTFkZmY5ZDU5NWM",
      "commit": {
        "author": {
          "name": "Lavrentiy Rubtsov",
          "email": "73550760+Rnbsov@users.noreply.github.com",
          "date": "2022-02-20T14:33:10Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-20T14:33:10Z"
        },
        "message": "Missed exclamation mark",
        "tree": {
          "sha": "92aa7a2499ee203c3bf6b9aea57cf80ca389addb",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/92aa7a2499ee203c3bf6b9aea57cf80ca389addb"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/e1db5dcebea063e4afe2252894ded11dff9d595c",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiElEmCRBK7hj4Ov3rIwAA6l8IADNscJK0w1Y1kzgXbF3IgHLw\ny1a4FHQnplRb6V1PAeFiH7SIC+aMi9DBWQLSXJk9aVRuDeFuVLFWqLqUisSrWg38\nkYGn6uqVkzKc0c/zSjmG5/0zOiTm4sjsND8xJuIJ4CV7j+9mWufY9/NcJdHDc1M4\nybghZjlCIaudVz0VC5cOhseruIP3txqGaxP8bfSwG8wGTVG4qrjcYPC/43yn0V/u\nl2GxFqDXXfYpXRR4x8QFJt65nBzPPIjd6XJKaAYcsrzvsjmx3nsNlq5VlIz5J/6T\nH4OSj2l0NIa6kxpTPG7lGG/kVnMB9pYpKCQh7QUZdJHi17QOCf0zqnd3Mm+4T5A=\n=EQCn\n-----END PGP SIGNATURE-----\n",
          "payload": "tree 92aa7a2499ee203c3bf6b9aea57cf80ca389addb\nparent e2f9e5840737e00846bfd492192d8a3828820c60\nauthor Lavrentiy Rubtsov <73550760+Rnbsov@users.noreply.github.com> 1645367590 +0600\ncommitter GitHub <noreply@github.com> 1645367590 +0600\n\nMissed exclamation mark"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/e1db5dcebea063e4afe2252894ded11dff9d595c",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/e1db5dcebea063e4afe2252894ded11dff9d595c",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/e1db5dcebea063e4afe2252894ded11dff9d595c/comments",
      "author": {
        "login": "Rnbsov",
        "id": 73550760,
        "node_id": "MDQ6VXNlcjczNTUwNzYw",
        "avatar_url": "https://avatars.githubusercontent.com/u/73550760?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/Rnbsov",
        "html_url": "https://github.com/Rnbsov",
        "followers_url": "https://api.github.com/users/Rnbsov/followers",
        "following_url": "https://api.github.com/users/Rnbsov/following{/other_user}",
        "gists_url": "https://api.github.com/users/Rnbsov/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/Rnbsov/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/Rnbsov/subscriptions",
        "organizations_url": "https://api.github.com/users/Rnbsov/orgs",
        "repos_url": "https://api.github.com/users/Rnbsov/repos",
        "events_url": "https://api.github.com/users/Rnbsov/events{/privacy}",
        "received_events_url": "https://api.github.com/users/Rnbsov/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "e2f9e5840737e00846bfd492192d8a3828820c60",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/e2f9e5840737e00846bfd492192d8a3828820c60",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/e2f9e5840737e00846bfd492192d8a3828820c60"
        }
      ]
    },
    {
      "sha": "16ace5ae32b44a84afb981af32958704fb5b1310",
      "node_id": "C_kwDOBY7uftoAKDE2YWNlNWFlMzJiNDRhODRhZmI5ODFhZjMyOTU4NzA0ZmI1YjEzMTA",
      "commit": {
        "author": {
          "name": "ᚷᛁᛟᚱᚷᛁ ᛒᚨᛚᚨᚲᚻᚨᛞᛉᛖ",
          "email": "balakhadze.dev@gmail.com",
          "date": "2022-02-18T20:17:37Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-18T20:17:37Z"
        },
        "message": "Fix LI content numbers\n\nI think this is more convenient. If one will call chapter.closest('.chapter') they will understand that it returns the first <li class=\"chapter\">",
        "tree": {
          "sha": "5a5efd64c06c754aeb407b1e3579ad08d764b046",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/5a5efd64c06c754aeb407b1e3579ad08d764b046"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/16ace5ae32b44a84afb981af32958704fb5b1310",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiD/7hCRBK7hj4Ov3rIwAAtngIAF9NeNrsdeScktKRdCN5ergO\nyateauhRcplXwKoveX/rugenz4lmLlaGpMTsYJvZFKdU2FagVE1dk+xwd54feAiv\noJQBeeoR3GWOmkcun6Fw5UVrgMPXfuuNE4Oc77ki5Ll7vQ8lgSRkwfDQkkhGWkSa\nt+RUwXyzLZ72lAisV8fhobxYv5XtQ1PRe4MwhHWhh53+b6Il78mIJSHqQ2KEdVn+\nKyYYlfJQ/kRblc8+LwAhzpJgjqs+uj2kdfJo/l+KYBYMWke6AAUDsgkKCGZbjyYP\nAvYAVt47jDUqYQetieaCuSfJ5if+/Ax7M3SnZUPxpTxeZQDvh/P6LhfvCs3rfl4=\n=31y5\n-----END PGP SIGNATURE-----\n",
          "payload": "tree 5a5efd64c06c754aeb407b1e3579ad08d764b046\nparent e2f9e5840737e00846bfd492192d8a3828820c60\nauthor ᚷᛁᛟᚱᚷᛁ ᛒᚨᛚᚨᚲᚻᚨᛞᛉᛖ <balakhadze.dev@gmail.com> 1645215457 +0400\ncommitter GitHub <noreply@github.com> 1645215457 +0400\n\nFix LI content numbers\n\nI think this is more convenient. If one will call chapter.closest('.chapter') they will understand that it returns the first <li class=\"chapter\">"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/16ace5ae32b44a84afb981af32958704fb5b1310",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/16ace5ae32b44a84afb981af32958704fb5b1310",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/16ace5ae32b44a84afb981af32958704fb5b1310/comments",
      "author": {
        "login": "Vitruvius21",
        "id": 38228361,
        "node_id": "MDQ6VXNlcjM4MjI4MzYx",
        "avatar_url": "https://avatars.githubusercontent.com/u/38228361?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/Vitruvius21",
        "html_url": "https://github.com/Vitruvius21",
        "followers_url": "https://api.github.com/users/Vitruvius21/followers",
        "following_url": "https://api.github.com/users/Vitruvius21/following{/other_user}",
        "gists_url": "https://api.github.com/users/Vitruvius21/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/Vitruvius21/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/Vitruvius21/subscriptions",
        "organizations_url": "https://api.github.com/users/Vitruvius21/orgs",
        "repos_url": "https://api.github.com/users/Vitruvius21/repos",
        "events_url": "https://api.github.com/users/Vitruvius21/events{/privacy}",
        "received_events_url": "https://api.github.com/users/Vitruvius21/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "e2f9e5840737e00846bfd492192d8a3828820c60",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/e2f9e5840737e00846bfd492192d8a3828820c60",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/e2f9e5840737e00846bfd492192d8a3828820c60"
        }
      ]
    },
    {
      "sha": "e2f9e5840737e00846bfd492192d8a3828820c60",
      "node_id": "C_kwDOBY7uftoAKGUyZjllNTg0MDczN2UwMDg0NmJmZDQ5MjE5MmQ4YTM4Mjg4MjBjNjA",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@users.noreply.github.com",
          "date": "2022-02-18T14:42:31Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-18T14:42:31Z"
        },
        "message": "Merge pull request #2861 from marahmanjs/patch-1\n\nupdate webpack url",
        "tree": {
          "sha": "36959dc3ca914d201ff8057e8537d5a9528fa9bf",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/36959dc3ca914d201ff8057e8537d5a9528fa9bf"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/e2f9e5840737e00846bfd492192d8a3828820c60",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiD7BXCRBK7hj4Ov3rIwAAQlcIADFIZHFgHaudU4KdsyDLKf/x\ntgKPidJjgIcoe1kxEEzCEx2t3YOQnLMMqsK074PIO/Ko9Md/Ld+uH8HfDg8nLfsw\nGo1+VpVhQfCBnJ0USb7aBfOVLHVMONPbLR3vXtab9HAC4IHfKgfW/a9vOlNlf62t\n4hm/Ad5/cw39gQ7mGptga+g0LW8DagXfic4YFTqE/p3zIE2GMToUob0xpCpLwcBN\nDzjAi070+PIie6chSa2UDuQbxd81uOOotxiOpcoyM5mQobwtIEtYmXP7mkXyMKfI\n6kseWNcTVLgwKkkdfcee565OUT4EOAcDT3jFJp5nTVhW1os9orgbZh47x8teCdY=\n=HEMT\n-----END PGP SIGNATURE-----\n",
          "payload": "tree 36959dc3ca914d201ff8057e8537d5a9528fa9bf\nparent 39da5f824821c0dfaecf3cd4a210ca312f06a5a4\nparent 8d7a9dd99c9e25f1a6af4407914b40650f8e6e4a\nauthor Ilya Kantor <iliakan@users.noreply.github.com> 1645195351 +0300\ncommitter GitHub <noreply@github.com> 1645195351 +0300\n\nMerge pull request #2861 from marahmanjs/patch-1\n\nupdate webpack url"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/e2f9e5840737e00846bfd492192d8a3828820c60",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/e2f9e5840737e00846bfd492192d8a3828820c60",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/e2f9e5840737e00846bfd492192d8a3828820c60/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "39da5f824821c0dfaecf3cd4a210ca312f06a5a4",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/39da5f824821c0dfaecf3cd4a210ca312f06a5a4",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/39da5f824821c0dfaecf3cd4a210ca312f06a5a4"
        },
        {
          "sha": "8d7a9dd99c9e25f1a6af4407914b40650f8e6e4a",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/8d7a9dd99c9e25f1a6af4407914b40650f8e6e4a",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/8d7a9dd99c9e25f1a6af4407914b40650f8e6e4a"
        }
      ]
    },
    {
      "sha": "39da5f824821c0dfaecf3cd4a210ca312f06a5a4",
      "node_id": "C_kwDOBY7uftoAKDM5ZGE1ZjgyNDgyMWMwZGZhZWNmM2NkNGEyMTBjYTMxMmYwNmE1YTQ",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@users.noreply.github.com",
          "date": "2022-02-18T14:42:19Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-18T14:42:19Z"
        },
        "message": "Merge pull request #2862 from huyenltnguyen/docs/link\n\ndocs: minor grammar fix and link update",
        "tree": {
          "sha": "2603b7d156578ac3d3cd1c85eee319d034059099",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/2603b7d156578ac3d3cd1c85eee319d034059099"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/39da5f824821c0dfaecf3cd4a210ca312f06a5a4",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiD7BLCRBK7hj4Ov3rIwAAG4oIABL1MoGEixnPkbP9a7LFQ5a2\nB+ZbGCPYMB9uRBdVH6E6P9of7sK1nMRuV2QztlR8/U58z2kU6gKQzBlOblfdzHIm\n+gnb7zeNzCIq14CxwmitQWbrnii4jaAcu3zZ14nuV1bgqgvPsx09GaDw9EpMD66y\nWHGRZExmYsTxxWtPf3PmsQcLmr7mYXm2xvPHhlIS1uGAEg2YFbtEtCyBGiXMc5qg\ndx40Y3deXBOEj7ZbCZXZV3tai8w8Jvtbr4P2GNoJNiPooddiEvw1yBr4K/8+kLdD\nl0UmVNNOnzU0KYkDNHCBkhfit6KjfkTQaEn2+JwDhVFX7QZcDGOrgiNUU6Dl8EM=\n=bUnT\n-----END PGP SIGNATURE-----\n",
          "payload": "tree 2603b7d156578ac3d3cd1c85eee319d034059099\nparent 54bc5776a9120ed1fd91719fdef596734d9b5673\nparent 5315ba590c3ebe57f731b3a17af460eff5eb551a\nauthor Ilya Kantor <iliakan@users.noreply.github.com> 1645195339 +0300\ncommitter GitHub <noreply@github.com> 1645195339 +0300\n\nMerge pull request #2862 from huyenltnguyen/docs/link\n\ndocs: minor grammar fix and link update"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/39da5f824821c0dfaecf3cd4a210ca312f06a5a4",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/39da5f824821c0dfaecf3cd4a210ca312f06a5a4",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/39da5f824821c0dfaecf3cd4a210ca312f06a5a4/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "54bc5776a9120ed1fd91719fdef596734d9b5673",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/54bc5776a9120ed1fd91719fdef596734d9b5673",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/54bc5776a9120ed1fd91719fdef596734d9b5673"
        },
        {
          "sha": "5315ba590c3ebe57f731b3a17af460eff5eb551a",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/5315ba590c3ebe57f731b3a17af460eff5eb551a",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/5315ba590c3ebe57f731b3a17af460eff5eb551a"
        }
      ]
    },
    {
      "sha": "54bc5776a9120ed1fd91719fdef596734d9b5673",
      "node_id": "C_kwDOBY7uftoAKDU0YmM1Nzc2YTkxMjBlZDFmZDkxNzE5ZmRlZjU5NjczNGQ5YjU2NzM",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@users.noreply.github.com",
          "date": "2022-02-18T14:41:35Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-18T14:41:35Z"
        },
        "message": "Merge pull request #2868 from vabushkevich/patch-1\n\nAdd mention of radio buttons",
        "tree": {
          "sha": "4f27f260984d9f240f478345914be9a0b02e002e",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/4f27f260984d9f240f478345914be9a0b02e002e"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/54bc5776a9120ed1fd91719fdef596734d9b5673",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiD7AfCRBK7hj4Ov3rIwAAsDQIALC46u043T05SFlItKkVYXA9\n0Gcog7b5eFynWVz5LDDt399sboWy1JFdV+n99quj6dVe0j1VPvkQ6Uvc2JaC8wcy\n53xCHnES1G8jK8Jgxh4hJGjcvc5ZXjfdovVXqbBT0otLx90d1LJZTV6n2jY/JaXz\nuAxxLZlxqFJ3vPgPVzI+3PqbZkwNTAJltRAqUkXD5QCyGyFrrHKHQEplbinApSRV\nFstWz3iuIKJGoNz8LkstTkRTiU+1kPgXVlJHskrxIvnmif3NG+ia45NL/lQnwva/\nMALxuBcQpvdoJmSnK917vyhT5p4mny24Hoa3N/YrpfYRgs/k3rZPXP9AWDyJgEg=\n=GBOe\n-----END PGP SIGNATURE-----\n",
          "payload": "tree 4f27f260984d9f240f478345914be9a0b02e002e\nparent d3bfbe34877ca6b477d7afabea1d99f3b6a95320\nparent efbe490afbc34c78d80ed7fd26c022efcf29e59c\nauthor Ilya Kantor <iliakan@users.noreply.github.com> 1645195295 +0300\ncommitter GitHub <noreply@github.com> 1645195295 +0300\n\nMerge pull request #2868 from vabushkevich/patch-1\n\nAdd mention of radio buttons"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/54bc5776a9120ed1fd91719fdef596734d9b5673",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/54bc5776a9120ed1fd91719fdef596734d9b5673",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/54bc5776a9120ed1fd91719fdef596734d9b5673/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "d3bfbe34877ca6b477d7afabea1d99f3b6a95320",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/d3bfbe34877ca6b477d7afabea1d99f3b6a95320",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/d3bfbe34877ca6b477d7afabea1d99f3b6a95320"
        },
        {
          "sha": "efbe490afbc34c78d80ed7fd26c022efcf29e59c",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/efbe490afbc34c78d80ed7fd26c022efcf29e59c",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/efbe490afbc34c78d80ed7fd26c022efcf29e59c"
        }
      ]
    },
    {
      "sha": "d3bfbe34877ca6b477d7afabea1d99f3b6a95320",
      "node_id": "C_kwDOBY7uftoAKGQzYmZiZTM0ODc3Y2E2YjQ3N2Q3YWZhYmVhMWQ5OWYzYjZhOTUzMjA",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@users.noreply.github.com",
          "date": "2022-02-18T14:38:43Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-18T14:38:43Z"
        },
        "message": "Merge pull request #2880 from skaunov/patch-1\n\nUpdate test.js",
        "tree": {
          "sha": "74bfb7934acc6ce82c0f9ac072d41997da86637b",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/74bfb7934acc6ce82c0f9ac072d41997da86637b"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/d3bfbe34877ca6b477d7afabea1d99f3b6a95320",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiD69zCRBK7hj4Ov3rIwAAXQ8IAJGoR6e5e54ohnUYbB1hWV2W\nwfb7CzMcPmEmblDrZnlMDBM9cO3d8BbfhVyy6NPL4lS9sm9kNsqg3xEJgOY1dV/m\n5X8DJLdx2YPuypvRiLulDKYH/p4PNTH+4siZptmWMkixZ28VScT60SBAiEaua6v2\n6sTPKw+BG2vlg/QQYAS7cdd4DeSiwpnr5poPI8ZJyn1vHJe7pdLNa1dr19Nzv2fS\nthZbwhj75tFMaWDsS45DqBf34k7C37pLRySplBY8CS24m1tkH0NCRmEuE64zG87L\ngRSnUD3r/V9vP1hrqSNSpIt2XTzBSVCApaiE2qpUxWqO94RxUFmIpWSZloPnixA=\n=XMus\n-----END PGP SIGNATURE-----\n",
          "payload": "tree 74bfb7934acc6ce82c0f9ac072d41997da86637b\nparent 883bd606d70e0321334f657b61502b67fa636b84\nparent c68cb111a4fbc5820026aea57f25971092ccb013\nauthor Ilya Kantor <iliakan@users.noreply.github.com> 1645195123 +0300\ncommitter GitHub <noreply@github.com> 1645195123 +0300\n\nMerge pull request #2880 from skaunov/patch-1\n\nUpdate test.js"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/d3bfbe34877ca6b477d7afabea1d99f3b6a95320",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/d3bfbe34877ca6b477d7afabea1d99f3b6a95320",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/d3bfbe34877ca6b477d7afabea1d99f3b6a95320/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "883bd606d70e0321334f657b61502b67fa636b84",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/883bd606d70e0321334f657b61502b67fa636b84",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/883bd606d70e0321334f657b61502b67fa636b84"
        },
        {
          "sha": "c68cb111a4fbc5820026aea57f25971092ccb013",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/c68cb111a4fbc5820026aea57f25971092ccb013",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/c68cb111a4fbc5820026aea57f25971092ccb013"
        }
      ]
    },
    {
      "sha": "883bd606d70e0321334f657b61502b67fa636b84",
      "node_id": "C_kwDOBY7uftoAKDg4M2JkNjA2ZDcwZTAzMjEzMzRmNjU3YjYxNTAyYjY3ZmE2MzZiODQ",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@users.noreply.github.com",
          "date": "2022-02-18T14:38:24Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-18T14:38:24Z"
        },
        "message": "Merge pull request #2881 from leviding/patch-42\n\nfix error in 1-js/13-modules/01-modules-intro/article.md",
        "tree": {
          "sha": "f9a2a83293b666aafe4cb15ca2279ee376283237",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/f9a2a83293b666aafe4cb15ca2279ee376283237"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/883bd606d70e0321334f657b61502b67fa636b84",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiD69gCRBK7hj4Ov3rIwAAbTcIACwcu2pXewKU94djqWawjqu2\nC/VYgQjev9+9mUfGhc3RiDCeWh89pCxv6i59h9pGmjCafxv+n00+jksd0ogDYjet\nYY4rRkFtauIe/ihh5mHOm7kktHFxjiOr88K7Xn0T00q3q8vyIGDgOZnOrax3mVZ9\nOane9na/nPIy3UIxnL/a3SP7GbsJv7E0ztvbviQtVThjkfGSRYOlLeBrj1q5xylz\nWjCO0Cjvjlt/yKHu4sjiT/cRDdbK5JTCf1/lNfgerIqIycsL4EufJaHjrj83XJe/\nng4iOR4ns6aLL9LJghOrAsCIfTs/60wRzuR+/D/ouCbsm4+fvnCakyamRjhU0hg=\n=+Kqm\n-----END PGP SIGNATURE-----\n",
          "payload": "tree f9a2a83293b666aafe4cb15ca2279ee376283237\nparent 6eba0627a49c8267442292b7a8a624361a4ce6cb\nparent 79a1b9293b60eb684dc9314307da2622a2beb904\nauthor Ilya Kantor <iliakan@users.noreply.github.com> 1645195104 +0300\ncommitter GitHub <noreply@github.com> 1645195104 +0300\n\nMerge pull request #2881 from leviding/patch-42\n\nfix error in 1-js/13-modules/01-modules-intro/article.md"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/883bd606d70e0321334f657b61502b67fa636b84",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/883bd606d70e0321334f657b61502b67fa636b84",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/883bd606d70e0321334f657b61502b67fa636b84/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "6eba0627a49c8267442292b7a8a624361a4ce6cb",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/6eba0627a49c8267442292b7a8a624361a4ce6cb",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/6eba0627a49c8267442292b7a8a624361a4ce6cb"
        },
        {
          "sha": "79a1b9293b60eb684dc9314307da2622a2beb904",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/79a1b9293b60eb684dc9314307da2622a2beb904",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/79a1b9293b60eb684dc9314307da2622a2beb904"
        }
      ]
    },
    {
      "sha": "6eba0627a49c8267442292b7a8a624361a4ce6cb",
      "node_id": "C_kwDOBY7uftoAKDZlYmEwNjI3YTQ5YzgyNjc0NDIyOTJiN2E4YTYyNDM2MWE0Y2U2Y2I",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@users.noreply.github.com",
          "date": "2022-02-17T05:36:36Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-17T05:36:36Z"
        },
        "message": "Merge pull request #2872 from umakantv/patch-1\n\n[Fix] Convert message from Buffer to String",
        "tree": {
          "sha": "4a6862a4ef8459893ca759df667490f2ffaa29c3",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/4a6862a4ef8459893ca759df667490f2ffaa29c3"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/6eba0627a49c8267442292b7a8a624361a4ce6cb",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiDd7kCRBK7hj4Ov3rIwAA+tYIAKXci9yOx5z0/Rvy0fQEzgFJ\nSeFklbLK4jQbnjClOHyCjAguCjqdKBwutfeeUadtXQ0fGs1KpmYuzdY5kcxf8V8L\nTlyr5q+ZN4UFPxtowiEEhi6TXTPEbFUhi6JaaIs04rh1DcbfWPPKOzbP7bl3xW+3\nVVPSwLUKkANGyyD25yF7g45/g2ubsTKTFsRLKXQ77F51uqdFXufCs738K50IGB9D\nOsGHOBtKkVVy1+KTR3YuHz0YJH7PTh4XI08cHt13x1+v/NLxgIYwQR3W8jd6gS5Q\n3acO0OjMWyILmsh18s1k3uhCinH+oJhv7NOwOHOLeRM/cHdaooMlKj2ph8VvRM4=\n=Ye+l\n-----END PGP SIGNATURE-----\n",
          "payload": "tree 4a6862a4ef8459893ca759df667490f2ffaa29c3\nparent 29216730a877be28d0a75a459676db6e7f5c4834\nparent d5cce9465038a88ad0e42c8673e799c021340d5e\nauthor Ilya Kantor <iliakan@users.noreply.github.com> 1645076196 +0300\ncommitter GitHub <noreply@github.com> 1645076196 +0300\n\nMerge pull request #2872 from umakantv/patch-1\n\n[Fix] Convert message from Buffer to String"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/6eba0627a49c8267442292b7a8a624361a4ce6cb",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/6eba0627a49c8267442292b7a8a624361a4ce6cb",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/6eba0627a49c8267442292b7a8a624361a4ce6cb/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "29216730a877be28d0a75a459676db6e7f5c4834",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/29216730a877be28d0a75a459676db6e7f5c4834",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/29216730a877be28d0a75a459676db6e7f5c4834"
        },
        {
          "sha": "d5cce9465038a88ad0e42c8673e799c021340d5e",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/d5cce9465038a88ad0e42c8673e799c021340d5e",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/d5cce9465038a88ad0e42c8673e799c021340d5e"
        }
      ]
    },
    {
      "sha": "79a1b9293b60eb684dc9314307da2622a2beb904",
      "node_id": "C_kwDOBY7uftoAKDc5YTFiOTI5M2I2MGViNjg0ZGM5MzE0MzA3ZGEyNjIyYTJiZWI5MDQ",
      "commit": {
        "author": {
          "name": "LeviDing",
          "email": "imdingxuewen@gmail.com",
          "date": "2022-02-16T01:11:59Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-16T01:11:59Z"
        },
        "message": "Update article.md",
        "tree": {
          "sha": "aab2d28e0b5065b9932b3b1d2f11c2cfb6bd117a",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/aab2d28e0b5065b9932b3b1d2f11c2cfb6bd117a"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/79a1b9293b60eb684dc9314307da2622a2beb904",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiDE9fCRBK7hj4Ov3rIwAAMBIIAGTED+C9mvdXBy59w6Cdyvrf\nlaKH63TpADUkPkVKdmB9jdmDNGo3tGi7VDokfZpuFn+pRW5sUfLkkxoi/Eccj4Yx\nRoQcMw5A/I/xSXseYCCdRAG7fJ7ogb5qhVY9m1VC/eDeeXmIo+MVh/TPQKxZZEVx\nq1Kv2Yyy0kJtP2Cd1URxuojQJXh1ZtfwcEwNGTDN5F8AtrWnzWetedI0Ub1aJ1dU\nZBD8kGZEWnFMfT7xdhqf+3sc1W7pHdh+7TjnM8S4eHbb0R6sZVjvCAAtbo030MUo\n7hstncydHvNuaK58cmISj2VM/5bF+b5UDknY/qiIlavVicpDONkgei5wg9ccdRE=\n=qVEk\n-----END PGP SIGNATURE-----\n",
          "payload": "tree aab2d28e0b5065b9932b3b1d2f11c2cfb6bd117a\nparent 29216730a877be28d0a75a459676db6e7f5c4834\nauthor LeviDing <imdingxuewen@gmail.com> 1644973919 +0800\ncommitter GitHub <noreply@github.com> 1644973919 +0800\n\nUpdate article.md"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/79a1b9293b60eb684dc9314307da2622a2beb904",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/79a1b9293b60eb684dc9314307da2622a2beb904",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/79a1b9293b60eb684dc9314307da2622a2beb904/comments",
      "author": {
        "login": "leviding",
        "id": 26959437,
        "node_id": "MDQ6VXNlcjI2OTU5NDM3",
        "avatar_url": "https://avatars.githubusercontent.com/u/26959437?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/leviding",
        "html_url": "https://github.com/leviding",
        "followers_url": "https://api.github.com/users/leviding/followers",
        "following_url": "https://api.github.com/users/leviding/following{/other_user}",
        "gists_url": "https://api.github.com/users/leviding/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/leviding/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/leviding/subscriptions",
        "organizations_url": "https://api.github.com/users/leviding/orgs",
        "repos_url": "https://api.github.com/users/leviding/repos",
        "events_url": "https://api.github.com/users/leviding/events{/privacy}",
        "received_events_url": "https://api.github.com/users/leviding/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "29216730a877be28d0a75a459676db6e7f5c4834",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/29216730a877be28d0a75a459676db6e7f5c4834",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/29216730a877be28d0a75a459676db6e7f5c4834"
        }
      ]
    },
    {
      "sha": "c68cb111a4fbc5820026aea57f25971092ccb013",
      "node_id": "C_kwDOBY7uftoAKGM2OGNiMTExYTRmYmM1ODIwMDI2YWVhNTdmMjU5NzEwOTJjY2IwMTM",
      "commit": {
        "author": {
          "name": "skaunov",
          "email": "65976143+skaunov@users.noreply.github.com",
          "date": "2022-02-15T13:53:29Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-15T13:53:29Z"
        },
        "message": "Update test.js\n\nHey there! I suggest to slightly modify the first test case, so its input cover both checks in the solution.\r\nCurrently omitting the check for _a_ still let solution to pass the test.\r\n```js\r\nif (/* val < a || */ val > b) {\r\n        arr.splice(i, 1);\r\n        i--;\r\n      }\r\n```",
        "tree": {
          "sha": "e8f1fa0e40ac5ed000789a98bb5bfb005a848598",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/e8f1fa0e40ac5ed000789a98bb5bfb005a848598"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/c68cb111a4fbc5820026aea57f25971092ccb013",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiC7BZCRBK7hj4Ov3rIwAAn0wIAHi9kMR9JZsRtADpw55/6ho7\nHr/O/1C7P27lObXB86y79lv40E5QEUPEYnxvUv/hIdRzG8y36IZYjeFx7fgF+yIf\nNmDif/+zJpQPxaKxUyaSYeMjfqQVmFV8Zq5tRzfUXWMZ0zCwFRXw0jn26/JvZMtp\n39H3Rt9/mHW6UR2JwvBHX5en1pfHiBvgSaUADHxwxmcoMTC8y1eZnsvsHKvD8TWX\nqqrpPAnA/IseS+rzgzjn5RAprmKzyK+EphIBhj29vqSfuJe98OLuN0LPBa+8zfA2\ni6mKtpVLQKcwTeNasR1i5Mrjc1+34JvDGFgjAFw3PePnS0kpZ1FGwOVN/5x/J4A=\n=TY/J\n-----END PGP SIGNATURE-----\n",
          "payload": "tree e8f1fa0e40ac5ed000789a98bb5bfb005a848598\nparent 29216730a877be28d0a75a459676db6e7f5c4834\nauthor skaunov <65976143+skaunov@users.noreply.github.com> 1644933209 +0300\ncommitter GitHub <noreply@github.com> 1644933209 +0300\n\nUpdate test.js\n\nHey there! I suggest to slightly modify the first test case, so its input cover both checks in the solution.\r\nCurrently omitting the check for _a_ still let solution to pass the test.\r\n```js\r\nif (/* val < a || */ val > b) {\r\n        arr.splice(i, 1);\r\n        i--;\r\n      }\r\n```"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/c68cb111a4fbc5820026aea57f25971092ccb013",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/c68cb111a4fbc5820026aea57f25971092ccb013",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/c68cb111a4fbc5820026aea57f25971092ccb013/comments",
      "author": {
        "login": "skaunov",
        "id": 65976143,
        "node_id": "MDQ6VXNlcjY1OTc2MTQz",
        "avatar_url": "https://avatars.githubusercontent.com/u/65976143?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/skaunov",
        "html_url": "https://github.com/skaunov",
        "followers_url": "https://api.github.com/users/skaunov/followers",
        "following_url": "https://api.github.com/users/skaunov/following{/other_user}",
        "gists_url": "https://api.github.com/users/skaunov/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/skaunov/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/skaunov/subscriptions",
        "organizations_url": "https://api.github.com/users/skaunov/orgs",
        "repos_url": "https://api.github.com/users/skaunov/repos",
        "events_url": "https://api.github.com/users/skaunov/events{/privacy}",
        "received_events_url": "https://api.github.com/users/skaunov/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "29216730a877be28d0a75a459676db6e7f5c4834",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/29216730a877be28d0a75a459676db6e7f5c4834",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/29216730a877be28d0a75a459676db6e7f5c4834"
        }
      ]
    },
    {
      "sha": "29216730a877be28d0a75a459676db6e7f5c4834",
      "node_id": "C_kwDOBY7uftoAKDI5MjE2NzMwYTg3N2JlMjhkMGE3NWE0NTk2NzZkYjZlN2Y1YzQ4MzQ",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@gmail.com",
          "date": "2022-02-12T13:15:38Z"
        },
        "committer": {
          "name": "Ilya Kantor",
          "email": "iliakan@gmail.com",
          "date": "2022-02-12T13:15:38Z"
        },
        "message": "minor fixes",
        "tree": {
          "sha": "9aee756f56984d4454bc05abc6c64a11e3d6d42d",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/9aee756f56984d4454bc05abc6c64a11e3d6d42d"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/29216730a877be28d0a75a459676db6e7f5c4834",
        "comment_count": 0,
        "verification": {
          "verified": false,
          "reason": "unsigned",
          "signature": null,
          "payload": null
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/29216730a877be28d0a75a459676db6e7f5c4834",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/29216730a877be28d0a75a459676db6e7f5c4834",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/29216730a877be28d0a75a459676db6e7f5c4834/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "d7c8c7506e13eabe20c1022d65ed247ab69fc197",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/d7c8c7506e13eabe20c1022d65ed247ab69fc197",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/d7c8c7506e13eabe20c1022d65ed247ab69fc197"
        }
      ]
    },
    {
      "sha": "d5cce9465038a88ad0e42c8673e799c021340d5e",
      "node_id": "C_kwDOBY7uftoAKGQ1Y2NlOTQ2NTAzOGE4OGFkMGU0MmM4NjczZTc5OWMwMjEzNDBkNWU",
      "commit": {
        "author": {
          "name": "Umakant Vashishtha",
          "email": "41837826+umakantv@users.noreply.github.com",
          "date": "2022-02-10T14:18:31Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-10T14:18:31Z"
        },
        "message": "[Fix] Convert message from Buffer to String\n\nFixed the issue - https://github.com/javascript-tutorial/en.javascript.info/issues/2870",
        "tree": {
          "sha": "e9b8daccd8f4d368c38e3c6f74afc8c0d2d0a284",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/e9b8daccd8f4d368c38e3c6f74afc8c0d2d0a284"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/d5cce9465038a88ad0e42c8673e799c021340d5e",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiBR63CRBK7hj4Ov3rIwAADHMIAJbxoLXgV641EIeVfNXQCmFg\nWhAJFuvOWr/YK/XrcJFyQR3IlMkzjGXaHT7uICKWg9zgD8j8cbAYBoGr3pzlFHCV\nmPaSGyZ0NUq6if779epuVnFLYQeMZbvv9+lbl7ZtR2+ZedXq3igisZbSydRH3GbL\nWk9KbLAqUAjt4GMVkKSA7cJXVqkTMs6GA0zFh3GYlcCGEIgjNHSMg73zWPjXxzAA\nPGazolGljzaTlq0/AZ8ub/w4OLkOSGz4TgKI/rw4gCPm2ipTCNkHyBeWBtO5sgrj\n9pnXS8GppnLvXMVEbVwrMMvWf6bKdISInhQEnipR7pHnp8XjV/cyOPkzXpXZOEw=\n=lltr\n-----END PGP SIGNATURE-----\n",
          "payload": "tree e9b8daccd8f4d368c38e3c6f74afc8c0d2d0a284\nparent d7c8c7506e13eabe20c1022d65ed247ab69fc197\nauthor Umakant Vashishtha <41837826+umakantv@users.noreply.github.com> 1644502711 +0530\ncommitter GitHub <noreply@github.com> 1644502711 +0530\n\n[Fix] Convert message from Buffer to String\n\nFixed the issue - https://github.com/javascript-tutorial/en.javascript.info/issues/2870"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/d5cce9465038a88ad0e42c8673e799c021340d5e",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/d5cce9465038a88ad0e42c8673e799c021340d5e",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/d5cce9465038a88ad0e42c8673e799c021340d5e/comments",
      "author": {
        "login": "umakantv",
        "id": 41837826,
        "node_id": "MDQ6VXNlcjQxODM3ODI2",
        "avatar_url": "https://avatars.githubusercontent.com/u/41837826?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/umakantv",
        "html_url": "https://github.com/umakantv",
        "followers_url": "https://api.github.com/users/umakantv/followers",
        "following_url": "https://api.github.com/users/umakantv/following{/other_user}",
        "gists_url": "https://api.github.com/users/umakantv/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/umakantv/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/umakantv/subscriptions",
        "organizations_url": "https://api.github.com/users/umakantv/orgs",
        "repos_url": "https://api.github.com/users/umakantv/repos",
        "events_url": "https://api.github.com/users/umakantv/events{/privacy}",
        "received_events_url": "https://api.github.com/users/umakantv/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "d7c8c7506e13eabe20c1022d65ed247ab69fc197",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/d7c8c7506e13eabe20c1022d65ed247ab69fc197",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/d7c8c7506e13eabe20c1022d65ed247ab69fc197"
        }
      ]
    },
    {
      "sha": "efbe490afbc34c78d80ed7fd26c022efcf29e59c",
      "node_id": "C_kwDOBY7uftoAKGVmYmU0OTBhZmJjMzRjNzhkODBlZDdmZDI2YzAyMmVmY2YyOWU1OWM",
      "commit": {
        "author": {
          "name": "Vyacheslav Abushkevich",
          "email": "abshkvch@gmail.com",
          "date": "2022-02-09T17:37:34Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-09T17:37:34Z"
        },
        "message": "Add mention of radio buttons",
        "tree": {
          "sha": "a28a2e07382b8aa8106b2a99e8b480bdc21e6ce3",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/a28a2e07382b8aa8106b2a99e8b480bdc21e6ce3"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/efbe490afbc34c78d80ed7fd26c022efcf29e59c",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiA/veCRBK7hj4Ov3rIwAAvNcIAA05BlDzp5fp/iGpMJTG+fX9\naZFOMLlN20UNVyS8qMhmDtDyb1FgGzMIEgxNMhnYMgBr0yk41VJqGVydLf/hLdVm\nh662Wsv9UtTLa93gO+SMW/gmQeqAwP248WhYqPJvUaqWY4vTrfCfofyc+hiNzkhh\nORRuRoD6zYjlmh+Eeep+XyinIt/fs8bKPGPL8eXQb/zXtP8emOpgbriYYX+72R74\njEU9TJDgvXWQO6nQXpWsH5BGIt2xL4Krp0xDoi9PFWkN7+Ugq3RA1u6j1wFYh49j\nbPbD6XdrLeQ0INUwSLT+DASw097Zfx75bCCNxFi47NwxxADVQeMf7l/8/aTsZzQ=\n=Qg/1\n-----END PGP SIGNATURE-----\n",
          "payload": "tree a28a2e07382b8aa8106b2a99e8b480bdc21e6ce3\nparent d7c8c7506e13eabe20c1022d65ed247ab69fc197\nauthor Vyacheslav Abushkevich <abshkvch@gmail.com> 1644428254 +0300\ncommitter GitHub <noreply@github.com> 1644428254 +0300\n\nAdd mention of radio buttons"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/efbe490afbc34c78d80ed7fd26c022efcf29e59c",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/efbe490afbc34c78d80ed7fd26c022efcf29e59c",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/efbe490afbc34c78d80ed7fd26c022efcf29e59c/comments",
      "author": {
        "login": "vabushkevich",
        "id": 23465488,
        "node_id": "MDQ6VXNlcjIzNDY1NDg4",
        "avatar_url": "https://avatars.githubusercontent.com/u/23465488?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/vabushkevich",
        "html_url": "https://github.com/vabushkevich",
        "followers_url": "https://api.github.com/users/vabushkevich/followers",
        "following_url": "https://api.github.com/users/vabushkevich/following{/other_user}",
        "gists_url": "https://api.github.com/users/vabushkevich/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/vabushkevich/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/vabushkevich/subscriptions",
        "organizations_url": "https://api.github.com/users/vabushkevich/orgs",
        "repos_url": "https://api.github.com/users/vabushkevich/repos",
        "events_url": "https://api.github.com/users/vabushkevich/events{/privacy}",
        "received_events_url": "https://api.github.com/users/vabushkevich/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "d7c8c7506e13eabe20c1022d65ed247ab69fc197",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/d7c8c7506e13eabe20c1022d65ed247ab69fc197",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/d7c8c7506e13eabe20c1022d65ed247ab69fc197"
        }
      ]
    },
    {
      "sha": "d7c8c7506e13eabe20c1022d65ed247ab69fc197",
      "node_id": "C_kwDOBY7uftoAKGQ3YzhjNzUwNmUxM2VhYmUyMGMxMDIyZDY1ZWQyNDdhYjY5ZmMxOTc",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@users.noreply.github.com",
          "date": "2022-02-08T05:22:48Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-08T05:22:48Z"
        },
        "message": "Merge pull request #2866 from joaquinelio/patch-9\n\nGB unit symbol",
        "tree": {
          "sha": "e1e47ba48dd778da8d3fc959ab6151057214758d",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/e1e47ba48dd778da8d3fc959ab6151057214758d"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/d7c8c7506e13eabe20c1022d65ed247ab69fc197",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiAf4oCRBK7hj4Ov3rIwAAIDkIAFKCa/tnG56ORoCtmJ03m5SX\nZCljZ/+u2NEpCn36Asj9Dfkoxc929XDf6hhrm4AJqiWhAUT4eBTIEZ7QZEwYk0gW\nODSGndnnRrz/4tqyBOdhlIU9emuIP4Rsn6nBIWyajBT4EUC/bMnCiDNVwIt1oWhV\nKZhUta19aR1tihbGdm0jE0iu2K+wgIAaqhsNixmfh9HBNI8HJWxeEuQTp+oWHazU\n7wunxAbLv48qe3mrzLfrkv9bFIuyzc8SNeVpe5U47W3HuWOCJwhav1IAe/zeMP+L\nkEHq32mMf5BHK4F46j4b26gabo3uYw254vl8W3JGA5x/8H3T5F4jp6s5Ci6Hsx0=\n=MlL+\n-----END PGP SIGNATURE-----\n",
          "payload": "tree e1e47ba48dd778da8d3fc959ab6151057214758d\nparent 1e1f04fe1613296490c8eeffc490b4b25320dee0\nparent bf7eb930350c16a6219e8dc55c90c6d3b1367bb2\nauthor Ilya Kantor <iliakan@users.noreply.github.com> 1644297768 +0300\ncommitter GitHub <noreply@github.com> 1644297768 +0300\n\nMerge pull request #2866 from joaquinelio/patch-9\n\nGB unit symbol"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/d7c8c7506e13eabe20c1022d65ed247ab69fc197",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/d7c8c7506e13eabe20c1022d65ed247ab69fc197",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/d7c8c7506e13eabe20c1022d65ed247ab69fc197/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "1e1f04fe1613296490c8eeffc490b4b25320dee0",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/1e1f04fe1613296490c8eeffc490b4b25320dee0",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/1e1f04fe1613296490c8eeffc490b4b25320dee0"
        },
        {
          "sha": "bf7eb930350c16a6219e8dc55c90c6d3b1367bb2",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/bf7eb930350c16a6219e8dc55c90c6d3b1367bb2",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/bf7eb930350c16a6219e8dc55c90c6d3b1367bb2"
        }
      ]
    },
    {
      "sha": "bf7eb930350c16a6219e8dc55c90c6d3b1367bb2",
      "node_id": "C_kwDOBY7uftoAKGJmN2ViOTMwMzUwYzE2YTYyMTllOGRjNTVjOTBjNmQzYjEzNjdiYjI",
      "commit": {
        "author": {
          "name": "joaquinelio",
          "email": "joaquinelio@gmail.com",
          "date": "2022-02-07T20:01:16Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-07T20:01:16Z"
        },
        "message": "GB unit symbol",
        "tree": {
          "sha": "e1e47ba48dd778da8d3fc959ab6151057214758d",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/e1e47ba48dd778da8d3fc959ab6151057214758d"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/bf7eb930350c16a6219e8dc55c90c6d3b1367bb2",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiAXqMCRBK7hj4Ov3rIwAAOIIIADgAOyw35uCqjqy73Z449ysc\nBfiy0YStIuq2S3va0wdQ1CqfSetJtU0dH3aVbZN0B1X9wdzsMoGCDd6EZaU2e28S\nbPGwsnUjXOylIgM8T3XxNNJv7b/ZkdnyFXNVfBZG6dHH+w2hJy/5ypyAmAX+vYvC\n1qzpALuu9sVwAoz1zks8nRlJmX0bEZ8i61bvKbRF43h5dJpxpOVZkVxf+Krd/BbL\n6NLRcuJ6kA2Vtgy5dRIGYCZpgk06tODuggW4oUioJnJBznMiF64bKjjubmhdtLzR\nQoWhipNmqNWqnj9yMQthXznMqNorp1kHQZ8iS0n20cu+cxxlGpFTp8Sj8Tg3uZs=\n=FzjU\n-----END PGP SIGNATURE-----\n",
          "payload": "tree e1e47ba48dd778da8d3fc959ab6151057214758d\nparent 1e1f04fe1613296490c8eeffc490b4b25320dee0\nauthor joaquinelio <joaquinelio@gmail.com> 1644264076 -0300\ncommitter GitHub <noreply@github.com> 1644264076 -0300\n\nGB unit symbol"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/bf7eb930350c16a6219e8dc55c90c6d3b1367bb2",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/bf7eb930350c16a6219e8dc55c90c6d3b1367bb2",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/bf7eb930350c16a6219e8dc55c90c6d3b1367bb2/comments",
      "author": {
        "login": "joaquinelio",
        "id": 6558304,
        "node_id": "MDQ6VXNlcjY1NTgzMDQ=",
        "avatar_url": "https://avatars.githubusercontent.com/u/6558304?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/joaquinelio",
        "html_url": "https://github.com/joaquinelio",
        "followers_url": "https://api.github.com/users/joaquinelio/followers",
        "following_url": "https://api.github.com/users/joaquinelio/following{/other_user}",
        "gists_url": "https://api.github.com/users/joaquinelio/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/joaquinelio/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/joaquinelio/subscriptions",
        "organizations_url": "https://api.github.com/users/joaquinelio/orgs",
        "repos_url": "https://api.github.com/users/joaquinelio/repos",
        "events_url": "https://api.github.com/users/joaquinelio/events{/privacy}",
        "received_events_url": "https://api.github.com/users/joaquinelio/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "1e1f04fe1613296490c8eeffc490b4b25320dee0",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/1e1f04fe1613296490c8eeffc490b4b25320dee0",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/1e1f04fe1613296490c8eeffc490b4b25320dee0"
        }
      ]
    },
    {
      "sha": "1e1f04fe1613296490c8eeffc490b4b25320dee0",
      "node_id": "C_kwDOBY7uftoAKDFlMWYwNGZlMTYxMzI5NjQ5MGM4ZWVmZmM0OTBiNGIyNTMyMGRlZTA",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@users.noreply.github.com",
          "date": "2022-02-07T15:23:27Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-07T15:23:27Z"
        },
        "message": "Merge pull request #2864 from leviding/patch-40\n\nPrecedence of \"addition\" (binary plus) is 12",
        "tree": {
          "sha": "c572730fa4eafb48e12091d433527bcddf95c06f",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/c572730fa4eafb48e12091d433527bcddf95c06f"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/1e1f04fe1613296490c8eeffc490b4b25320dee0",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiATlvCRBK7hj4Ov3rIwAApG0IAD6x3YSvHfM9FW8sUUzAPYm+\nfd2k1lpK0ZKheGalq5FMGLmWJ5P6+bOmfw6qJRPNX+0/COGBu7fJA/lV/UXn5TZv\nuKQ4eD7Nmp52Arr7AUzfiN+sMZ98jG/+JrWp07rg5P6dz2x1vaAxy9SKUUp+0GvB\nO3Q8RnxZ8m8JACn3V1cgs2HtPUgaGFpGzSedSUlXtsj8OejtwRs8Y29GO30P9F1Q\nuTv64h0pzHovHXH1IKEo++QucEl8TIx5KaDhjQi+pStCOvQ/z4lDVLtJUmhK+muL\nzm6y9N5zuUM5vBE5LoCgX8VJKjlrWjUHt+dKgBzJRIFLZ2pSSEPAVtKPUlveLIo=\n=CvI0\n-----END PGP SIGNATURE-----\n",
          "payload": "tree c572730fa4eafb48e12091d433527bcddf95c06f\nparent 71da17e5960f1c76aad0d04d21f10bc65318d3f6\nparent 962839108f8a581e18df070121a6a01d64cde39d\nauthor Ilya Kantor <iliakan@users.noreply.github.com> 1644247407 +0300\ncommitter GitHub <noreply@github.com> 1644247407 +0300\n\nMerge pull request #2864 from leviding/patch-40\n\nPrecedence of \"addition\" (binary plus) is 12"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/1e1f04fe1613296490c8eeffc490b4b25320dee0",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/1e1f04fe1613296490c8eeffc490b4b25320dee0",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/1e1f04fe1613296490c8eeffc490b4b25320dee0/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "71da17e5960f1c76aad0d04d21f10bc65318d3f6",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/71da17e5960f1c76aad0d04d21f10bc65318d3f6",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/71da17e5960f1c76aad0d04d21f10bc65318d3f6"
        },
        {
          "sha": "962839108f8a581e18df070121a6a01d64cde39d",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/962839108f8a581e18df070121a6a01d64cde39d",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/962839108f8a581e18df070121a6a01d64cde39d"
        }
      ]
    },
    {
      "sha": "962839108f8a581e18df070121a6a01d64cde39d",
      "node_id": "C_kwDOBY7uftoAKDk2MjgzOTEwOGY4YTU4MWUxOGRmMDcwMTIxYTZhMDFkNjRjZGUzOWQ",
      "commit": {
        "author": {
          "name": "LeviDing",
          "email": "imdingxuewen@gmail.com",
          "date": "2022-02-07T15:01:54Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-07T15:01:54Z"
        },
        "message": "Update article.md",
        "tree": {
          "sha": "c572730fa4eafb48e12091d433527bcddf95c06f",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/c572730fa4eafb48e12091d433527bcddf95c06f"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/962839108f8a581e18df070121a6a01d64cde39d",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiATRiCRBK7hj4Ov3rIwAAvHMIAItsyjMml8piyNOXJdsZfh04\nVnLStoORxG2kppwN9Wlddf2chocaPhihHSBH3w+eKd78BneavmbDKLnUxm+CnmxC\nPDAVVPaxmDLrkoXiTLruVMerm2YJ47p+ry72chx/9bpOUod/BqdmgkuodGNtFZVo\nCFbXbfyFaMVZzkfIvR2cla1I9NUR8TLi9RsCFPLWRs6n8ruqmfp6KJkyuBafXuJt\nr6VEb4WGpARsZOZyty2VamOo7pIpPWSSA4Tab4zXt5s9prUXfsf4heAc9khQGF4a\n+5QO8sX3Y9Em7CyFS/kJJLjayMffoNUzgoLT+B96dsrZah6OlxCBrYEnLuGqU6M=\n=2er+\n-----END PGP SIGNATURE-----\n",
          "payload": "tree c572730fa4eafb48e12091d433527bcddf95c06f\nparent 71da17e5960f1c76aad0d04d21f10bc65318d3f6\nauthor LeviDing <imdingxuewen@gmail.com> 1644246114 +0800\ncommitter GitHub <noreply@github.com> 1644246114 +0800\n\nUpdate article.md"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/962839108f8a581e18df070121a6a01d64cde39d",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/962839108f8a581e18df070121a6a01d64cde39d",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/962839108f8a581e18df070121a6a01d64cde39d/comments",
      "author": {
        "login": "leviding",
        "id": 26959437,
        "node_id": "MDQ6VXNlcjI2OTU5NDM3",
        "avatar_url": "https://avatars.githubusercontent.com/u/26959437?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/leviding",
        "html_url": "https://github.com/leviding",
        "followers_url": "https://api.github.com/users/leviding/followers",
        "following_url": "https://api.github.com/users/leviding/following{/other_user}",
        "gists_url": "https://api.github.com/users/leviding/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/leviding/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/leviding/subscriptions",
        "organizations_url": "https://api.github.com/users/leviding/orgs",
        "repos_url": "https://api.github.com/users/leviding/repos",
        "events_url": "https://api.github.com/users/leviding/events{/privacy}",
        "received_events_url": "https://api.github.com/users/leviding/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "71da17e5960f1c76aad0d04d21f10bc65318d3f6",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/71da17e5960f1c76aad0d04d21f10bc65318d3f6",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/71da17e5960f1c76aad0d04d21f10bc65318d3f6"
        }
      ]
    },
    {
      "sha": "5315ba590c3ebe57f731b3a17af460eff5eb551a",
      "node_id": "C_kwDOBY7uftoAKDUzMTViYTU5MGMzZWJlNTdmNzMxYjNhMTdhZjQ2MGVmZjVlYjU1MWE",
      "commit": {
        "author": {
          "name": "Huyen Nguyen",
          "email": "25715018+huyenltnguyen@users.noreply.github.com",
          "date": "2022-02-07T04:08:41Z"
        },
        "committer": {
          "name": "Huyen Nguyen",
          "email": "25715018+huyenltnguyen@users.noreply.github.com",
          "date": "2022-02-07T04:08:41Z"
        },
        "message": "docs: minor grammar fix and link update",
        "tree": {
          "sha": "d43c9d040f59ad5da8f4765e13a075329a095f47",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/d43c9d040f59ad5da8f4765e13a075329a095f47"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/5315ba590c3ebe57f731b3a17af460eff5eb551a",
        "comment_count": 0,
        "verification": {
          "verified": false,
          "reason": "unsigned",
          "signature": null,
          "payload": null
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/5315ba590c3ebe57f731b3a17af460eff5eb551a",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/5315ba590c3ebe57f731b3a17af460eff5eb551a",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/5315ba590c3ebe57f731b3a17af460eff5eb551a/comments",
      "author": {
        "login": "huyenltnguyen",
        "id": 25715018,
        "node_id": "MDQ6VXNlcjI1NzE1MDE4",
        "avatar_url": "https://avatars.githubusercontent.com/u/25715018?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/huyenltnguyen",
        "html_url": "https://github.com/huyenltnguyen",
        "followers_url": "https://api.github.com/users/huyenltnguyen/followers",
        "following_url": "https://api.github.com/users/huyenltnguyen/following{/other_user}",
        "gists_url": "https://api.github.com/users/huyenltnguyen/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/huyenltnguyen/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/huyenltnguyen/subscriptions",
        "organizations_url": "https://api.github.com/users/huyenltnguyen/orgs",
        "repos_url": "https://api.github.com/users/huyenltnguyen/repos",
        "events_url": "https://api.github.com/users/huyenltnguyen/events{/privacy}",
        "received_events_url": "https://api.github.com/users/huyenltnguyen/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "huyenltnguyen",
        "id": 25715018,
        "node_id": "MDQ6VXNlcjI1NzE1MDE4",
        "avatar_url": "https://avatars.githubusercontent.com/u/25715018?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/huyenltnguyen",
        "html_url": "https://github.com/huyenltnguyen",
        "followers_url": "https://api.github.com/users/huyenltnguyen/followers",
        "following_url": "https://api.github.com/users/huyenltnguyen/following{/other_user}",
        "gists_url": "https://api.github.com/users/huyenltnguyen/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/huyenltnguyen/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/huyenltnguyen/subscriptions",
        "organizations_url": "https://api.github.com/users/huyenltnguyen/orgs",
        "repos_url": "https://api.github.com/users/huyenltnguyen/repos",
        "events_url": "https://api.github.com/users/huyenltnguyen/events{/privacy}",
        "received_events_url": "https://api.github.com/users/huyenltnguyen/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "71da17e5960f1c76aad0d04d21f10bc65318d3f6",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/71da17e5960f1c76aad0d04d21f10bc65318d3f6",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/71da17e5960f1c76aad0d04d21f10bc65318d3f6"
        }
      ]
    },
    {
      "sha": "8d7a9dd99c9e25f1a6af4407914b40650f8e6e4a",
      "node_id": "C_kwDOBY7uftoAKDhkN2E5ZGQ5OWM5ZTI1ZjFhNmFmNDQwNzkxNGI0MDY1MGY4ZTZlNGE",
      "commit": {
        "author": {
          "name": "Anis",
          "email": "imarahmandev@gmail.com",
          "date": "2022-02-06T17:47:20Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-06T17:47:20Z"
        },
        "message": "update webpack url\n\nupdated webpack url from an older one to latest",
        "tree": {
          "sha": "2a6610e78170a2f4596040e5819d138659d7c542",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/2a6610e78170a2f4596040e5819d138659d7c542"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/8d7a9dd99c9e25f1a6af4407914b40650f8e6e4a",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJiAAmoCRBK7hj4Ov3rIwAAtAwIAGtGmJ+sQLHhAKuG0VrTIgfA\ndEbWyHJe9SYCGqV/hswRyp0Ref4zole40LiaHzKXT31Fsxa5gznUn/J6f5IVBMk4\nR2TiE45cQmwHD+oDkEIEaUC8RgCPUeCrlvXlE/lb+H61CZJs7lh8NAK3jhO8MU+M\ndj0Wu/K+2Suu3AR+ByRnc8m7nf/55DXQJBeMctiFqPrychQpRQBIx+DTh8h/Icwo\nj+PNNMOr+/EFLt/F+dBdnhRSTq0ms8fyMp6ZPyoaMqd66Utf2Fi5Ur+6VkuXmwto\nJ7SfudlZ8vpOj3M60H9DaroKG40je73s/rCLUBD644UMaGmieFSfi3MqfI1viI4=\n=JpCU\n-----END PGP SIGNATURE-----\n",
          "payload": "tree 2a6610e78170a2f4596040e5819d138659d7c542\nparent 71da17e5960f1c76aad0d04d21f10bc65318d3f6\nauthor Anis <imarahmandev@gmail.com> 1644169640 +0500\ncommitter GitHub <noreply@github.com> 1644169640 +0500\n\nupdate webpack url\n\nupdated webpack url from an older one to latest"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/8d7a9dd99c9e25f1a6af4407914b40650f8e6e4a",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/8d7a9dd99c9e25f1a6af4407914b40650f8e6e4a",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/8d7a9dd99c9e25f1a6af4407914b40650f8e6e4a/comments",
      "author": {
        "login": "marahmanjs",
        "id": 24876790,
        "node_id": "MDQ6VXNlcjI0ODc2Nzkw",
        "avatar_url": "https://avatars.githubusercontent.com/u/24876790?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/marahmanjs",
        "html_url": "https://github.com/marahmanjs",
        "followers_url": "https://api.github.com/users/marahmanjs/followers",
        "following_url": "https://api.github.com/users/marahmanjs/following{/other_user}",
        "gists_url": "https://api.github.com/users/marahmanjs/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/marahmanjs/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/marahmanjs/subscriptions",
        "organizations_url": "https://api.github.com/users/marahmanjs/orgs",
        "repos_url": "https://api.github.com/users/marahmanjs/repos",
        "events_url": "https://api.github.com/users/marahmanjs/events{/privacy}",
        "received_events_url": "https://api.github.com/users/marahmanjs/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "71da17e5960f1c76aad0d04d21f10bc65318d3f6",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/71da17e5960f1c76aad0d04d21f10bc65318d3f6",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/71da17e5960f1c76aad0d04d21f10bc65318d3f6"
        }
      ]
    },
    {
      "sha": "71da17e5960f1c76aad0d04d21f10bc65318d3f6",
      "node_id": "C_kwDOBY7uftoAKDcxZGExN2U1OTYwZjFjNzZhYWQwZDA0ZDIxZjEwYmM2NTMxOGQzZjY",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@gmail.com",
          "date": "2022-02-06T10:19:41Z"
        },
        "committer": {
          "name": "Ilya Kantor",
          "email": "iliakan@gmail.com",
          "date": "2022-02-06T10:19:41Z"
        },
        "message": "minor fixes",
        "tree": {
          "sha": "b1d649d6685c6d0f3e745bbfc433be087bbfbadf",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/b1d649d6685c6d0f3e745bbfc433be087bbfbadf"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/71da17e5960f1c76aad0d04d21f10bc65318d3f6",
        "comment_count": 0,
        "verification": {
          "verified": false,
          "reason": "unsigned",
          "signature": null,
          "payload": null
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/71da17e5960f1c76aad0d04d21f10bc65318d3f6",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/71da17e5960f1c76aad0d04d21f10bc65318d3f6",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/71da17e5960f1c76aad0d04d21f10bc65318d3f6/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "f95671cd28012af88da33858690322bc350187f2",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/f95671cd28012af88da33858690322bc350187f2",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/f95671cd28012af88da33858690322bc350187f2"
        }
      ]
    },
    {
      "sha": "f95671cd28012af88da33858690322bc350187f2",
      "node_id": "C_kwDOBY7uftoAKGY5NTY3MWNkMjgwMTJhZjg4ZGEzMzg1ODY5MDMyMmJjMzUwMTg3ZjI",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@gmail.com",
          "date": "2022-02-06T10:18:25Z"
        },
        "committer": {
          "name": "Ilya Kantor",
          "email": "iliakan@gmail.com",
          "date": "2022-02-06T10:18:25Z"
        },
        "message": "minor fixes",
        "tree": {
          "sha": "894d72dc79edab4a4d7aeb32b8cc248708d9f9de",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/894d72dc79edab4a4d7aeb32b8cc248708d9f9de"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/f95671cd28012af88da33858690322bc350187f2",
        "comment_count": 0,
        "verification": {
          "verified": false,
          "reason": "unsigned",
          "signature": null,
          "payload": null
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/f95671cd28012af88da33858690322bc350187f2",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/f95671cd28012af88da33858690322bc350187f2",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/f95671cd28012af88da33858690322bc350187f2/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "9a2981cf3d0f0e8c5a233042a88e83e7d04092e6",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/9a2981cf3d0f0e8c5a233042a88e83e7d04092e6",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/9a2981cf3d0f0e8c5a233042a88e83e7d04092e6"
        }
      ]
    },
    {
      "sha": "9a2981cf3d0f0e8c5a233042a88e83e7d04092e6",
      "node_id": "C_kwDOBY7uftoAKDlhMjk4MWNmM2QwZjBlOGM1YTIzMzA0MmE4OGU4M2U3ZDA0MDkyZTY",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@gmail.com",
          "date": "2022-02-06T10:18:04Z"
        },
        "committer": {
          "name": "Ilya Kantor",
          "email": "iliakan@gmail.com",
          "date": "2022-02-06T10:18:04Z"
        },
        "message": "minor fixes",
        "tree": {
          "sha": "d05f16e4f2aa32f6755f17f58717bf5356bbcf13",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/d05f16e4f2aa32f6755f17f58717bf5356bbcf13"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/9a2981cf3d0f0e8c5a233042a88e83e7d04092e6",
        "comment_count": 0,
        "verification": {
          "verified": false,
          "reason": "unsigned",
          "signature": null,
          "payload": null
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/9a2981cf3d0f0e8c5a233042a88e83e7d04092e6",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/9a2981cf3d0f0e8c5a233042a88e83e7d04092e6",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/9a2981cf3d0f0e8c5a233042a88e83e7d04092e6/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "c9063dcdd8fa326c98986b1457620432597cd7ea",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/c9063dcdd8fa326c98986b1457620432597cd7ea",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/c9063dcdd8fa326c98986b1457620432597cd7ea"
        }
      ]
    },
    {
      "sha": "c9063dcdd8fa326c98986b1457620432597cd7ea",
      "node_id": "C_kwDOBY7uftoAKGM5MDYzZGNkZDhmYTMyNmM5ODk4NmIxNDU3NjIwNDMyNTk3Y2Q3ZWE",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@users.noreply.github.com",
          "date": "2022-02-06T10:11:09Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-06T10:11:09Z"
        },
        "message": "Merge pull request #2857 from buynao/master\n\nUpdate blob article.md",
        "tree": {
          "sha": "7911b39c3e62af34ad58c12b73621d43e2fdf9ed",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/7911b39c3e62af34ad58c12b73621d43e2fdf9ed"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/c9063dcdd8fa326c98986b1457620432597cd7ea",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJh/569CRBK7hj4Ov3rIwAA6cEIAG1YPowhGiVVF/uVJB0inHtS\nxQMedUyRotjxEEMIW8RZmg7ORzkMtAyjwjIDukrWHRhfIsXmVHjq66+YlwK0dljl\nKFbfaCr7tghGNhboYzYF3yIDeFsFHdogplV+mqh4yGxKNxeHnp4cIbS57+olafYr\nzIzJdPrDXDt8xRxnNpddqYQrxrzRKOGoeI7NGtHGdoZLHmDxA/fh69E51rTPSpaf\n3yWLEIhuKqLVPiunOLv5WIzxsEq7pcXRDa1Ct9A2f7FrEvM9UzBn4S2UMf/jxTzy\nd9OX7Ku/r0p2Q19JLZszsX62eK/q8zqPML7MA8hOcAoQtKUod+8/bUZBukUONvg=\n=yWkL\n-----END PGP SIGNATURE-----\n",
          "payload": "tree 7911b39c3e62af34ad58c12b73621d43e2fdf9ed\nparent d159503ae6245b4c8ef4896cf6a97a3019249193\nparent fb070940efe331ff1c3b072d0fbfb38ddd39e6c5\nauthor Ilya Kantor <iliakan@users.noreply.github.com> 1644142269 +0300\ncommitter GitHub <noreply@github.com> 1644142269 +0300\n\nMerge pull request #2857 from buynao/master\n\nUpdate blob article.md"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/c9063dcdd8fa326c98986b1457620432597cd7ea",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/c9063dcdd8fa326c98986b1457620432597cd7ea",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/c9063dcdd8fa326c98986b1457620432597cd7ea/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "d159503ae6245b4c8ef4896cf6a97a3019249193",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/d159503ae6245b4c8ef4896cf6a97a3019249193",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/d159503ae6245b4c8ef4896cf6a97a3019249193"
        },
        {
          "sha": "fb070940efe331ff1c3b072d0fbfb38ddd39e6c5",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/fb070940efe331ff1c3b072d0fbfb38ddd39e6c5",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/fb070940efe331ff1c3b072d0fbfb38ddd39e6c5"
        }
      ]
    },
    {
      "sha": "d159503ae6245b4c8ef4896cf6a97a3019249193",
      "node_id": "C_kwDOBY7uftoAKGQxNTk1MDNhZTYyNDViNGM4ZWY0ODk2Y2Y2YTk3YTMwMTkyNDkxOTM",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@users.noreply.github.com",
          "date": "2022-02-06T10:10:10Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-06T10:10:10Z"
        },
        "message": "Merge pull request #2854 from lankerened/patch-1\n\nfix: bug caused by GitHub data change",
        "tree": {
          "sha": "6bc533bfeb1b0ebc5597a1c1f68d9540eccdd5bb",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/6bc533bfeb1b0ebc5597a1c1f68d9540eccdd5bb"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/d159503ae6245b4c8ef4896cf6a97a3019249193",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJh/56CCRBK7hj4Ov3rIwAA600IAGFOYcE8KD+4KYqIO+YLiVcV\nWaZpJfGoiRXeO4OSPt+pEvgKqWuMGYi/7Kls0kAIY1OVyRqVG4e8Jat2xFjjhCrC\neCeZX2cczxbv3zE7qTVvcl6NMOHjXtDVmcwlHGC+X4pq82ws+KHLebvbTd7/6zm+\nJIHaBH0rvz7kp8MSDhL48JZDbDXlvhU/I/xY+Jyg2xekda6pnLJI6o8zjgCt5vJ2\nkHeRdfqfo5OElG68UkcDvXeAHFE9c0wqm6CiTmIyMuYNSwRkMaRAQCvnZvRK49SY\nmwBVKRQTSWMOpkBXY1QDfZRXjIOA1JNtcndV+fl+Va7gPkgg7xwnxVUD2tHcH8o=\n=ChK0\n-----END PGP SIGNATURE-----\n",
          "payload": "tree 6bc533bfeb1b0ebc5597a1c1f68d9540eccdd5bb\nparent 533d54db869ff8634441da231321308a05f4be30\nparent e1be207fe86ecd9fddabf03bc537c01793a18188\nauthor Ilya Kantor <iliakan@users.noreply.github.com> 1644142210 +0300\ncommitter GitHub <noreply@github.com> 1644142210 +0300\n\nMerge pull request #2854 from lankerened/patch-1\n\nfix: bug caused by GitHub data change"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/d159503ae6245b4c8ef4896cf6a97a3019249193",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/d159503ae6245b4c8ef4896cf6a97a3019249193",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/d159503ae6245b4c8ef4896cf6a97a3019249193/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "533d54db869ff8634441da231321308a05f4be30",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/533d54db869ff8634441da231321308a05f4be30",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/533d54db869ff8634441da231321308a05f4be30"
        },
        {
          "sha": "e1be207fe86ecd9fddabf03bc537c01793a18188",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/e1be207fe86ecd9fddabf03bc537c01793a18188",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/e1be207fe86ecd9fddabf03bc537c01793a18188"
        }
      ]
    },
    {
      "sha": "533d54db869ff8634441da231321308a05f4be30",
      "node_id": "C_kwDOBY7uftoAKDUzM2Q1NGRiODY5ZmY4NjM0NDQxZGEyMzEzMjEzMDhhMDVmNGJlMzA",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@users.noreply.github.com",
          "date": "2022-02-06T10:10:01Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-06T10:10:01Z"
        },
        "message": "Merge pull request #2853 from leviding/patch-39\n\nUpdate operator precedence",
        "tree": {
          "sha": "23deaa6d2749fd406e509bdd82af2e375e97a8b7",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/23deaa6d2749fd406e509bdd82af2e375e97a8b7"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/533d54db869ff8634441da231321308a05f4be30",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJh/555CRBK7hj4Ov3rIwAAR3AIAFTkf46/E9B8WmksvMtE+EmB\nkd1wCoFVu8a9GuHHN7749kugvhe4NjViPRaroP2Gt99MCkfhFnv4L5mB+C9eryo1\n3dghg1Hv72qH27plufZknqF+fcGaTWPCqIw22ry8HBihyJUTrIcYPuDVs3HOLyYB\nIwMRxGwcE1j96ITOP1ulkkFVdCzcIySypiZU5YpdYPo4XUdi/bDqe9xRey3C4aD/\nypJW/HntIQoLFv3lnnZx43XtBrs51Bc4plVV4wpxl+nPxXiPXS2exZX+yBhco5AW\n2y3iP6Yr26QDx8jRDQ77/0WIxt0yDwyKbbZeGB2zETjQ27Ge+QFPIVX/5YD7hdI=\n=Dayr\n-----END PGP SIGNATURE-----\n",
          "payload": "tree 23deaa6d2749fd406e509bdd82af2e375e97a8b7\nparent 7647ab913f4406f35cd8108a130a0564fa28655a\nparent fc7bfbb993dd6490903e3227ef6e8b0f75f18b92\nauthor Ilya Kantor <iliakan@users.noreply.github.com> 1644142201 +0300\ncommitter GitHub <noreply@github.com> 1644142201 +0300\n\nMerge pull request #2853 from leviding/patch-39\n\nUpdate operator precedence"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/533d54db869ff8634441da231321308a05f4be30",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/533d54db869ff8634441da231321308a05f4be30",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/533d54db869ff8634441da231321308a05f4be30/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "7647ab913f4406f35cd8108a130a0564fa28655a",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/7647ab913f4406f35cd8108a130a0564fa28655a",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/7647ab913f4406f35cd8108a130a0564fa28655a"
        },
        {
          "sha": "fc7bfbb993dd6490903e3227ef6e8b0f75f18b92",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/fc7bfbb993dd6490903e3227ef6e8b0f75f18b92",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/fc7bfbb993dd6490903e3227ef6e8b0f75f18b92"
        }
      ]
    },
    {
      "sha": "7647ab913f4406f35cd8108a130a0564fa28655a",
      "node_id": "C_kwDOBY7uftoAKDc2NDdhYjkxM2Y0NDA2ZjM1Y2Q4MTA4YTEzMGEwNTY0ZmEyODY1NWE",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@gmail.com",
          "date": "2022-02-06T10:05:02Z"
        },
        "committer": {
          "name": "Ilya Kantor",
          "email": "iliakan@gmail.com",
          "date": "2022-02-06T10:05:02Z"
        },
        "message": "minor fixes",
        "tree": {
          "sha": "9476502c0f3cb3241b2cee877dfb062decce6540",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/9476502c0f3cb3241b2cee877dfb062decce6540"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/7647ab913f4406f35cd8108a130a0564fa28655a",
        "comment_count": 0,
        "verification": {
          "verified": false,
          "reason": "unsigned",
          "signature": null,
          "payload": null
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/7647ab913f4406f35cd8108a130a0564fa28655a",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/7647ab913f4406f35cd8108a130a0564fa28655a",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/7647ab913f4406f35cd8108a130a0564fa28655a/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "f2e4db7e66350cc99b397c2239b1b54abce772ad",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/f2e4db7e66350cc99b397c2239b1b54abce772ad",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/f2e4db7e66350cc99b397c2239b1b54abce772ad"
        }
      ]
    },
    {
      "sha": "fb070940efe331ff1c3b072d0fbfb38ddd39e6c5",
      "node_id": "C_kwDOBY7uftoAKGZiMDcwOTQwZWZlMzMxZmYxYzNiMDcyZDBmYmZiMzhkZGQzOWU2YzU",
      "commit": {
        "author": {
          "name": "law",
          "email": "307990588@qq.com",
          "date": "2022-02-05T14:17:47Z"
        },
        "committer": {
          "name": "GitHub",
          "email": "noreply@github.com",
          "date": "2022-02-05T14:17:47Z"
        },
        "message": "Update blob article.md\n\nUpdated the latest methods for blob to arrayBuffer, blob to stream, and some tips for using them.\r\nhttps://developer.mozilla.org/en-US/docs/Web/API/Blob/arrayBuffer\r\nhttps://developer.mozilla.org/en-US/docs/Web/API/Blob/stream",
        "tree": {
          "sha": "ed206c5be374af16f9bfffd6ed98729cf19f5677",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/ed206c5be374af16f9bfffd6ed98729cf19f5677"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/fb070940efe331ff1c3b072d0fbfb38ddd39e6c5",
        "comment_count": 0,
        "verification": {
          "verified": true,
          "reason": "valid",
          "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJh/ocLCRBK7hj4Ov3rIwAAGIYIAHMlCkiqL3JSXElumQS8Kvay\n/HQC0hqU4O1COjK6qc8bpl1m4uS5DAB72AtgidTq7vykx2QjCtz1tiNYtRhk1JEw\nkfB80TNiult+2MXT8kyjXnLncWGxA0GjHgtHCsrbyMDXPcRDFhc5yDuaYAAPvzAD\n5NPhqE1Y3zLKnsRbNlrua27YxijG95frLVhtZO/2w0gmxdZIsc3Wl8D+2eZoWnm6\n0NfURIHPeD2JPJpwVaFXAWPm1KjVv98dxYojOIJHyUxf3jk9VR4Z1UCDRtOhjYzP\nToYOoSqX7wVNgMYS9a6DDJco3HhMBRxcQmgykVPgl+pgFVC3wHBwTxyLiueUYsA=\n=E7+G\n-----END PGP SIGNATURE-----\n",
          "payload": "tree ed206c5be374af16f9bfffd6ed98729cf19f5677\nparent f2e4db7e66350cc99b397c2239b1b54abce772ad\nauthor law <307990588@qq.com> 1644070667 +0800\ncommitter GitHub <noreply@github.com> 1644070667 +0800\n\nUpdate blob article.md\n\nUpdated the latest methods for blob to arrayBuffer, blob to stream, and some tips for using them.\r\nhttps://developer.mozilla.org/en-US/docs/Web/API/Blob/arrayBuffer\r\nhttps://developer.mozilla.org/en-US/docs/Web/API/Blob/stream"
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/fb070940efe331ff1c3b072d0fbfb38ddd39e6c5",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/fb070940efe331ff1c3b072d0fbfb38ddd39e6c5",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/fb070940efe331ff1c3b072d0fbfb38ddd39e6c5/comments",
      "author": {
        "login": "buynao",
        "id": 11701966,
        "node_id": "MDQ6VXNlcjExNzAxOTY2",
        "avatar_url": "https://avatars.githubusercontent.com/u/11701966?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/buynao",
        "html_url": "https://github.com/buynao",
        "followers_url": "https://api.github.com/users/buynao/followers",
        "following_url": "https://api.github.com/users/buynao/following{/other_user}",
        "gists_url": "https://api.github.com/users/buynao/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/buynao/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/buynao/subscriptions",
        "organizations_url": "https://api.github.com/users/buynao/orgs",
        "repos_url": "https://api.github.com/users/buynao/repos",
        "events_url": "https://api.github.com/users/buynao/events{/privacy}",
        "received_events_url": "https://api.github.com/users/buynao/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "web-flow",
        "id": 19864447,
        "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
        "avatar_url": "https://avatars.githubusercontent.com/u/19864447?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/web-flow",
        "html_url": "https://github.com/web-flow",
        "followers_url": "https://api.github.com/users/web-flow/followers",
        "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
        "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
        "organizations_url": "https://api.github.com/users/web-flow/orgs",
        "repos_url": "https://api.github.com/users/web-flow/repos",
        "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
        "received_events_url": "https://api.github.com/users/web-flow/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "f2e4db7e66350cc99b397c2239b1b54abce772ad",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/f2e4db7e66350cc99b397c2239b1b54abce772ad",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/f2e4db7e66350cc99b397c2239b1b54abce772ad"
        }
      ]
    },
    {
      "sha": "f2e4db7e66350cc99b397c2239b1b54abce772ad",
      "node_id": "C_kwDOBY7uftoAKGYyZTRkYjdlNjYzNTBjYzk5YjM5N2MyMjM5YjFiNTRhYmNlNzcyYWQ",
      "commit": {
        "author": {
          "name": "Ilya Kantor",
          "email": "iliakan@gmail.com",
          "date": "2022-02-04T11:38:56Z"
        },
        "committer": {
          "name": "Ilya Kantor",
          "email": "iliakan@gmail.com",
          "date": "2022-02-04T11:38:56Z"
        },
        "message": "minor fixes",
        "tree": {
          "sha": "31da0c2099265f59bf008f9c671c7014351a8441",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/trees/31da0c2099265f59bf008f9c671c7014351a8441"
        },
        "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/git/commits/f2e4db7e66350cc99b397c2239b1b54abce772ad",
        "comment_count": 0,
        "verification": {
          "verified": false,
          "reason": "unsigned",
          "signature": null,
          "payload": null
        }
      },
      "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/f2e4db7e66350cc99b397c2239b1b54abce772ad",
      "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/f2e4db7e66350cc99b397c2239b1b54abce772ad",
      "comments_url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/f2e4db7e66350cc99b397c2239b1b54abce772ad/comments",
      "author": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "committer": {
        "login": "iliakan",
        "id": 349336,
        "node_id": "MDQ6VXNlcjM0OTMzNg==",
        "avatar_url": "https://avatars.githubusercontent.com/u/349336?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/iliakan",
        "html_url": "https://github.com/iliakan",
        "followers_url": "https://api.github.com/users/iliakan/followers",
        "following_url": "https://api.github.com/users/iliakan/following{/other_user}",
        "gists_url": "https://api.github.com/users/iliakan/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/iliakan/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/iliakan/subscriptions",
        "organizations_url": "https://api.github.com/users/iliakan/orgs",
        "repos_url": "https://api.github.com/users/iliakan/repos",
        "events_url": "https://api.github.com/users/iliakan/events{/privacy}",
        "received_events_url": "https://api.github.com/users/iliakan/received_events",
        "type": "User",
        "site_admin": false
      },
      "parents": [
        {
          "sha": "1f92729254d4bb899b8b4c4439c7cacb3b77743e",
          "url": "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits/1f92729254d4bb899b8b4c4439c7cacb3b77743e",
          "html_url": "https://github.com/javascript-tutorial/en.javascript.info/commit/1f92729254d4bb899b8b4c4439c7cacb3b77743e"
        }
      ]
    }
  ]