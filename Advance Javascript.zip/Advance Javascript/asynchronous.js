/**
 Write a function printNumbers(from, to) that outputs a number every second, starting from from and ending with to.
 Make two variants of the solution.
   Using setInterval.
   Using nested setTimeout.
 */

//using setInterval
// function printNumbers(from, to) {
//   var current = from;
//   var timerId = setInterval(() => {
//     if (from == to) {
//       clearTimeout(timerId);
//     }
//     console.log(from);
//     from++;
//   }, 1000);
// }

//using setTimeout 
// function printNumbers(from, to) {
//   setTimeout(function print() {
//     console.log(from);
//     if (from <= to) {
//         setTimeout(print, 1000);
//     }
//     from++;
//   }, 1000);
// }

// printNumbers(1, 20);

// // console.log(a);

function display(name) {
  console.log("Hello " + name);
}

/**********************************************************
 * time: it is in milliseconds, 5000 = 5 seconds
 * NOTE: do not put parentheses on calling the function
 */
// setTimeout(display, 5000);

/***********************************************************
 * In a fat arrow function () and {} ke beech => aata hai
 */
// var timerId = setTimeout(() => {
//     console.log("khushboo");
// }, 3000);
// clearTimeout(timerId);

/**********************************************************************
 * setInterval: a function is called after specified time continuously
 * How to stop it
 */

// var timerId = setInterval(display, 1000, "Khushboo");
// clearInterval(timerId);

/*************************************************************************
 * 2 ways by which we can run function after regular intervals -
 *  1. setInterval
 *  2. nested setTimeout
 */

//  let timerId = setTimeout(function tick() {
//     console.log('tick');
//     timerId = setTimeout(tick, 2000); // (*)
//   }, 2000);
