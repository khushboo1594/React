/*
Q.1. true=='true';
Ans: MDC describes the == operator as follows:

    "If the two operands are not of the same type, JavaScript converts the operands then applies strict comparison. If either operand is a number or a boolean, the operands are converted to numbers if possible; else if either operand is a string, the other operand is converted to a string if possible."

        With this in mind, I would evaluate "true" == true as follows:

        Are they of the same type? No
        Is either operand a number or boolean? Yes
        Can we convert either to a number? Yes 
        true is 1 in number (Number(true) -> 1)
        "true" is NaN (Number('true') -> NaN)
        which should evaluate to flase.

What have I missed?
*/
