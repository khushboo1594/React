const obj = Object.assign({x:25,y:45});
console.log(obj);