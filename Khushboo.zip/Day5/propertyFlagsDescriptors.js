// Object.getOwnPropertyDescriptor(obj, propertyName); \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
let user = {
  name: "John",
};

let descriptor = Object.getOwnPropertyDescriptor(user, "name");

console.log(descriptor);
/* property descriptor:
  {
    "value": "John",
    "writable": true,
    "enumerable": true,
    "configurable": true
  }
  */

// Object.defineProperty(obj, propertyName, descriptor) \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

// # Example 1
let user = {};

Object.defineProperty(user, "name", {
  value: "John",
});

let descriptor = Object.getOwnPropertyDescriptor(user, "name");

console.log(descriptor);
/*
{
  "value": "John",
  "writable": false,
  "enumerable": false,
  "configurable": false
}
 */

// # Example 2
let user = {};

Object.defineProperty(user, "name", {
  value: "John",
  writable: true,
  configurable: true,
});

let descriptor = Object.getOwnPropertyDescriptor(user, "name");

console.log(descriptor);
/*
{
  "value": "John",
  "writable": false,
  "enumerable": false,
  "configurable": false
}
 */

// non-writeable \\\\\\\\\\\\\\\\\\\\\\\\\
let user = {
  name: "John",
};

Object.defineProperty(user, "name", {
  writable: false,
});

user.name = "Pete"; // Error: Cannot assign to read only property 'name'
/*  
    Now no one can change the name of our user, unless they apply their own defineProperty to override ours.
    Errors appear only in strict mode
    In the non-strict mode, no errors occur when writing to non-writable properties and such. But the operation still won’t succeed. Flag-violating actions are just silently ignored in non-strict.
*/


// non-configurable \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
let user = { };

Object.defineProperty(user, "name", {
  value: "John",
  // for new properties we need to explicitly list what's true
  enumerable: true,
  configurable: true
});

alert(user.name); // John
user.name = "Pete"; // Error
// difference kya hua configurable and writable me?