/****************************************
Creating Objects

1. Object literals
2. with new keyword - Object constructor, function constructor
3. Object.create() with descriptors
4. factory function with closures
5. ES6 Js Classes 
6. Object.assign()

****************************************/
let log = console.log;

// 1. Object literals //////////////////////////////////
let obj1 = {
    prop1: 'value1',
    prop2: 'value2',
    prop3: function () {
        console.log(this.prop1);
    }
}
log(1, obj1);
obj1.prop3();
log('------------------------------')
// When you have to make many objects literal is not the way to go for it. It's very time consuming.
// Shallow copy deep copy padho.

// 3. Object.create ////////////////////////////////////
/*
Object.create() is a method which creates a new object from an existing object as the prototype for the newly created object.

Syntax
    Object.create(proto)
    Object.create(proto, propertiesObject)

Exceptions
    The proto parameter has to be either

    * null or
    * an Object excluding primitive wrapper objects.
    If proto is blank / neither of these a TypeError is thrown.
*/

// null Example
const nullObj = Object.create(null);
console.log(nullObj); // a blank object
// a obj created with null behaves strangely (for reference read mdn)

// blank obj
const blankObj = Object.create({});
console.log(blankObj);  // {}
// this is also perfectly valid

// directly passing object
var obj = Object.create({ a: 1, b: 2 });
console.log(obj); 
// {
//     a: 1,
//     b: 2
// }

// Object.create(proto)
const person = {
    isHuman: true,
    printIntro: function () {
        console.log(`My name is ${this.name}. Am i human? ${this.isHuman}`);
    }
    // never make a function inside a obj an arrow function it will refer to window obj and behave strangely. 
}
const me = Object.create(person);
me.name = 'khushboo';
me.printIntro(); // My name is khushboo. Am i human? true

// Object.create(proto, propertiesObject)

// Notes:
var o;

// create an object with null as prototype
o = Object.create(null);

o = {};
// is equivalent to:
o = Object.create(Object.prototype);

// Example 1
const obj1 = Object.create({}, {
    name: {
        value: 'khushboo'
    },
    age: {
        value: 28
    },
})

console.log(obj1);

// Example 2
let proto = {
    prop3: function () {
        console.log(this.prop1);
    }
}

let obj2 = Object.create({}, {
    prop1: {
        writable: true, // writable, enumerable, configurable all these are not necessary
        enumerable: true,
        configurable: true,
        value: 'value1' // This is same as line number 16
    },
    prop2: {
        writable: true,
        enumerable: false,
        configurable: true,
        value: 'value2'
    }
});
obj2.prop3 = function () {
    console.log(this.prop1);
}
log(2, obj2);
obj2.prop3();
log('------------------------------')


// 2. function constructor ////////////////////////////////////
let Obj = function (v1, v2) {
    this.prop1 = v1;
    this.prop2 = v2;
    this.prop3 = function () {
        console.log(this.prop1);
    }
}
let obj3 = new Obj('value1', 'value2');
log(3, obj3);
obj3.prop3();
log('------------------------------')


// 4. factory function with closures//////////////////////////////
let ObjFF = function (v1, v2) {
    let _prop1 = v1;
    let _prop2 = v2;
    return {
        prop1: _prop1,
        prop2: _prop2,
        prop3: function () {
            console.log(_prop1);
        }
    }
}
let obj4 = ObjFF('value1', 'value2');
log(4, obj4);
obj4.prop3();
log('------------------------------')


// 5. ES6 Js Classes////////////////////////////////
/*
Now making objects through constructors is replaced with classes in ES6
*/
class ObjC {
    constructor(v1, v2) {
        this.prop1 = v1;
        this.prop2 = v2;
    }
    prop3() {
        console.log(this.prop1);
    }
}
let obj5 = new ObjC('value1', 'value2');
log(5, obj5);
obj5.prop3();

// 2. Object constructor//////////////////////////////
var obj1 = new Object();
obj1.name = 'Khushboo';
obj1.age = 28;
console.log(obj1);

// 6. Object.assign//////////////////////////
const obj = Object.assign({x:25,y:45});
console.log(obj);