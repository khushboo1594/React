/*
1. use of currying in event handling
2. console.log(Object.entries(obj)); // shows "[]"
3. instanceOf operator
4. Object destructuring
5. ES6
6. https://www.javatpoint.com/javascript-objects
*/