/**
 * https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Objects/Object_prototypes
 * Definition: A prototype is a mechanism by which objects inherit features from each other. Every object in JavaScript has a  built-in property, which is called its prototype.The prototype is itself an object, so the prototype will have its own prototype, making what's called a prototype chain. The chain ends when we reach a prototype that has null for its own prototype.
 
 * Keval 2 par lagta hai object aur array.

 * When you try to access a property of an object: if the property can't be found in the object itself, the prototype is searched for the property. If the property still can't be found, then the prototype's prototype is searched, and so on until either the property is found, or the end of the chain is reached, in which case undefined is returned.
 */

const myObject = {
  city: "Madrid",
  greet() {
    console.log(`Greetings from ${this.city}`);
  },
};

myObject.greet(); // Greetings from Madrid

// // Object.getPrototypeOf(myObject) is equal to myObject.__proto__

// let musician = [];

let names = ["khushboo", "pupu"];
// names.__proto__ is equal to Array.prototype

function name(params) {}

// console.log(musician);
// musician.__proto__.sings=true;
// console.log(musician[1].Prototype);
