'use strict';
function add(a,b) {
    sum = a+b;
    console.log(sum)
}
add(5,4);