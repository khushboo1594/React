/*
Currying transforms a function from f(a,b,c) -> f(a)(b)(c)
 
Currying is a techniques of transforming function with multiple arguments to sequence of functions with single argument. In other words, when a function, instead of taking all arguments at one time, takes the first one and return a new function that takes the second one and returns a new function which takes the third one, and so forth, until all arguments have been fulfilled.
It does not matter on how many parameters the function needs. If a function has n number of parameters, its curried version will be a chain of n functions. Only the last function will return the desired result. The others return the next function in chain. Be noticed that each function should take only one parameter, which called Unary function.
 
Here are standards for a curried function:
    It has 1 parameter
    It returns an unary function, which also has 1 parameter

Where currying would be preferred over regular function calls? 
    It is useful when following a functional programming approach - but not necessary as JS does accept more than one parameter in a function. That said, here is a good quote on the practical application of currying followed by the link to the original source: "Currying is a type of partial function application. We can use its returned functions to make a lighter version of an existing function. It’s helpful when we have many places that use a function with exactly the same way. Our implementation will be shorter and more readable."  https://huynvk.dev/blog/currying-in-javascript-and-its-practical-usage 

Uses of currying function
  a) It helps to avoid passing same variable again and again.
  b) It is extremely useful in event handling. 

2 tarike hote hai currying k - closure se aur bind se
*/

// Using bind method
/* 
bind method binds a object to a function, reference it using 'this'.
*/
// let multiply = function (a, b) {
//    console.log(this); 
// //   console.log(a * b);
// };

// let multiplyByTwo = multiply.bind(this, 2);
// // console.log(multiplyByTwo);
// multiplyByTwo(5);

// Using Closures
// let multiply = function (a) {
//   return function (b) {
//     console.log(a * b);
//   };
// };

// let multiplyByTwo = multiply(2);
// multiplyByTwo(5);

//--------------------------------------------------------------------------------------------------------------------------------

// Create a curried function
// #1
// const buildSandwich = (ingredient1) => {
//   return (ingredient2) => {
//     return (ingredient3) => {
//       console.log(ingredient1, ingredient2, ingredient3);
//     };
//   };
// };

// How to call it?
// #1
// let ingredient2 = buildSandwich("bread");
// let ingredient3 = ingredient2("potato");
// ingredient3("masala");
// #2
// buildSandwich("bread")("potato")('masala');

// Create a curried function
// #2
// const buildSandwich = (ingredient1) => (ingredient2) => (ingredient3) =>
//   console.log(ingredient1, ingredient2, ingredient3);

// How to call it?
// #1
// let ingredient2 = buildSandwich("bread");
// let ingredient3 = ingredient2("potato");
// ingredient3("masala");
// #2
// buildSandwich("bread")("potato")('masala');

//--------------------------------------------------------------------------------------------------------------------------------

// How to use curried functions partially?
// let multiply = (a) => (b) => console.log(a * b);
// let multiplyByTwo = multiply(2); // If I always want to multiply my number by 2 I can call mutliplyByTwo instead of mutliply.
// multiplyByTwo(5);

// currying question akshay saini 
const curriedAdd=(a)=>{
  console.log("inside curriedAdd");
  return(b)=>{
    console.log("inside return b");
    if(b){
      console.log("inside if", a,b);
      return curriedAdd(a+b); // i guess this is called infinite currying // for understanding this see technical suneja infinite currying video
    }  
    return a;
  }
}
console.log(curriedAdd(1)(2)(3)(4)()); 