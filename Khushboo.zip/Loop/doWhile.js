// let index = 0;
// do {
//     index++;
//     console.log("Hello! I will run 5 times in a Do - While Loop-", index);
// } while (index < 5);

// Output:
// Hello! I will run 5 times in a Do - While Loop- 1
// Hello! I will run 5 times in a Do - While Loop- 2
// Hello! I will run 5 times in a Do - While Loop- 3
// Hello! I will run 5 times in a Do - While Loop- 4
// Hello! I will run 5 times in a Do - While Loop- 5

// let index = 0;
// do {
//     console.log("Hello! I will run 5 times in a Do - While Loop-", index);
//     index++;
// } while (index < 5);

// Output:
// Hello! I will run 5 times in a Do - While Loop- 0
// Hello! I will run 5 times in a Do - While Loop- 1
// Hello! I will run 5 times in a Do - While Loop- 2
// Hello! I will run 5 times in a Do - While Loop- 3
// Hello! I will run 5 times in a Do - While Loop- 4

var result = '';
var i = 0;
do {
   i += 1;
   result += i + ' ';
}
while (i > 0 && i < 5);
// Despite i == 0 this will still loop as it starts off without the test

console.log(result); // 1 2 3 4 5