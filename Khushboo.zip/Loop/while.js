// So, in a way while is like for loop when we do not do the initialization and the increment/decrement part insidr the loop
let index = 0;
while (index < 5) {
    console.log("Hello! I will run 5 times in a While Loop-", index);
    index++;
}

// Output:
// Hello! I will run 5 times in a Do - While Loop- 0
// Hello! I will run 5 times in a Do - While Loop- 1
// Hello! I will run 5 times in a Do - While Loop- 2
// Hello! I will run 5 times in a Do - While Loop- 3
// Hello! I will run 5 times in a Do - While Loop- 4
