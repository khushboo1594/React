// BREAK \\\
// Break lagane par wo loop k bahar aa jata hai
// let i = 0;

// while (i < 6) {
//   if (i === 3) {
//     break;
//   }
//   i = i + 1;
// }

// console.log(i);
// expected output: 3
// \\\\\\\\\\\\\\\\\\\\\
// CONTINUE \\\
// Break lagane par wo loop k bahar aa jata hai
let i = 0;

while (i < 6) {
  if (i === 3) {
    continue;
  }
  i = i + 1;
}

console.log(i);
// expected output: 5
