//  It is used with 'break' and 'continue' statement

// Example 1
// let str = '';   

// loop1:
// for (let i = 0; i < 5; i++) {
//   if (i === 1) {
//     continue loop1;
//   }
//   str = str + i;
// }

// console.log(str);
// expected output: "0234"

// \\\\\\\\\\\\\\\\\\\\\\\

// Example 2
// let i, j;

// loop1:
// for (i = 0; i < 3; i++) {      //The first for statement is labeled "loop1"
//    loop2:
//    for (j = 0; j < 3; j++) {   //The second for statement is labeled "loop2"
//       if (i === 1 && j === 1) {
//          continue loop1;
//       }
//       console.log('i = ' + i + ', j = ' + j);
//    }
// }

// Output is:
//   "i = 0, j = 0"
//   "i = 0, j = 1"
//   "i = 0, j = 2"
//   "i = 1, j = 0"
//   "i = 2, j = 0"
//   "i = 2, j = 1"
//   "i = 2, j = 2"
// Notice how it skips both "i = 1, j = 1" and "i = 1, j = 2"

// \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

// Example 3
let i, j;

loop1:
for (i = 0; i < 3; i++) {      //The first for statement is labeled "loop1"
   loop2:
   for (j = 0; j < 3; j++) {   //The second for statement is labeled "loop2"
      if (i === 1 && j === 1) {
         break loop1;
      }
      console.log('i = ' + i + ', j = ' + j);
   }
}

// Output is:
//   "i = 0, j = 0"
//   "i = 0, j = 1"
//   "i = 0, j = 2"
//   "i = 1, j = 0"
// Notice the difference with the previous continue example

// \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

// Example 4
let i, j;

loop1:
for (i = 0; i < 3; i++) {      //The first for statement is labeled "loop1"
   loop2:
   for (j = 0; j < 3; j++) {   //The second for statement is labeled "loop2"
      if (i === 1 && j === 1) {
         break loop2;
      }
      console.log('i = ' + i + ', j = ' + j);
   }
}

// Output is:
//   "i = 0, j = 0"
//   "i = 0, j = 1"
//   "i = 0, j = 2"
//   "i = 1, j = 0"
//   "i = 2, j = 0"
//   "i = 2, j = 1"
//   "i = 2, j = 2"
// Notice how it is similar to example 2

// \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

// Labeled function declarations *************

// There ar labelled function declaration, but they are under non-strict mode. Under strict mode it will throw error.

L: function F() {}
// -------------------
'use strict';
L: function F() {}
// SyntaxError: functions cannot be labelled
// ---------------------------------------------
// Generator functions can neither be labeled in strict code, nor in non-strict code:

L: function* F() {}
// SyntaxError: generator functions cannot be labelled
