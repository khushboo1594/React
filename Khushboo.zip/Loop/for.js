// This is an example of infinite  loop if we omit all the 3 things
// for (; ;) {
//     console.log("Hello! I am in a infinite loop");
// }

// Other ways of making infinite  loop
// 1. You can make an infinite loop by omitting either the condition or increment / decrement or both

// Sabse pehle initialization hota hai, then condition check hoti hai then it does whatever we want it to do then it increments / decrements and then again checks the condition and comes inside and then it keeps on repeating until the condition becomes false.

// We can also initailize and do increment / decrement like this -
// let index = 0;
// for (; index < 5;) {
//     console.log("Hello! I will run 5 times-", index);
//     index++;;
// }

// Output:
// Hello! I will run 5 times- 0
// Hello! I will run 5 times- 1
// Hello! I will run 5 times- 2
// Hello! I will run 5 times- 3
// Hello! I will run 5 times- 4

for (let index = 0; index < 5; index++); {
    console.log("You will think that this loop will run 5 times. Nope, gotcha");
}
// Why, it does not run for 5 times is - cz we have a semicolon at the end of the for loop statement which is indicating the end of the statement. Log is just a statement written inside a block