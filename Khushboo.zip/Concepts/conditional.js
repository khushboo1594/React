// if(){
//     console.log('if');
// }

if(false){
    console.log('first if');
}
else if(true){
    console.log('second if');
}

else if(true){
    console.log('third if');
}

// OUTPUT:
// second if

////////////////////////////////////////////////////////////////

if(false){
    console.log('first if');
}
if(true){
    console.log('second if');
}

if(true){
    console.log('third if');
}

// OUTPUT:
// second if
// third if