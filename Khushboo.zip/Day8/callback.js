/**
 What are callback functions?
     call back function is a function which is passed as argument to another function which we can later invoke for doing some kind of operation.
     
Use
  1. used in asynchronous functions, where one function has to wait for another function.

Example
  the best example of asynchronous along with callback functions will be setTimeout 

Js is a synchonous, single threaded language.
 */

setTimeout(function () {
  console.log("i am a call back function");
}, 5000);

function x(callBackFunction) {
  console.log(x);
  callBackFunction();
}
x(function y() {
  console.log(y);
});
/*
 What does blocking the main thread means?
    Js has only one call stack. so if something is blocking the call stack i.e. it is doing some heavy operations, it will be called blocking the call stack. we should never block the call stack we should always make that operation asynchronous if we are doing something which is going to take some time. 
 */
// Old code
// console.log(a);

/**
 * approach 1
 * problem: have to call 2 functions
 */

// function add(num1, num2) {
//   return num1 + num2;
// }

// function result(result) {
//   console.log(result);
// }

// var ans = add(45, 45);
// result(ans);

/**
 * approach 2
 * problem: we don't have control over the function result
 */

// function add(num1, num2) {
//   let ans = num1 + num2;
//   result(ans);
// }

// function result(result) {
//   console.log(result);
// }

// var ans = add(45, 45);

/**
 * approach 3
 * callback function
 * when to use: with async functions
 */

// function add(num1, num2, myCallback) {
//   let ans = num1 + num2;
//   myCallback(ans);
// }

// function result(result) {
//   console.log(result);
// }

// var ans = add(45, 45, result);
