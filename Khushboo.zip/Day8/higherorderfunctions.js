/**
 #Definition1
    A function which takes a function as argument or returns a function is known as Higher order function.

 #Definition2
    A function which performs operation on another function is known as Higher order function.
    It can take more than one function as argument. It does not have to return and accept function as argument at the same time. Doing either or both qualifies it as a Higher order function.

#Definition3
    Higher order functions are functions that operate on other functions, either by taking them as arguments or by returning them. In simple words, A Higher-Order function is a function that receives a function as an argument or returns the function as output.
    For example, Array.prototype.map, Array.prototype.filter and Array.prototype.reduce are some of the Higher-Order functions built into the language.
    sort, reduce, filter, forEach are other examples of higher-order functions.

Use
    1. code resueablity that means less code
    2. They are used for achieving abstraction. 
    3. we are doing composition
    
Composition:
    it means to break down things into smaller components.

 

 First order functions/ Plain functions: normal functions which does not take a function as a argument or returns a function.

 Function which is passed to higher order function is known as callback function
 */

//  Example
// function x() {
//     console.log("I am a call back function");
// }

// function y(x) {
//     console.log("I am a higher order function");
//     x();
// }

// y(x);

// Problem without higher order functions
// const radius = [1, 2, 3, 4];
// function calculateArea(radius) {
//   const area = [];
//   for (let index = 0; index < radius.length; index++) {
//     area.push(Math.PI * radius[index] * radius[index]);
//   }
//   return area;
// }
// console.log(calculateArea(radius));

// function calculateCirumference(radius) {
//   const area = [];
//   for (let index = 0; index < radius.length; index++) {
//     area.push(2 * Math.PI * radius[index]);
//   }
//   return area;
// }
// console.log(calculateCirumference(radius));

// function calculateDiameter(radius) {
//   const area = [];
//   for (let index = 0; index < radius.length; index++) {
//     area.push(2 * radius[index]);
//   }
//   return area;
// }
// console.log(calculateDiameter(radius));
// Problem with this code is that we are repeating a lot of code.

// Solution with higher order function
// const radius = [1, 2, 3, 4];
// function area(radius) {
//   return Math.PI * radius * radius;
// }
// function cirumference(radius) {
//   return 2 * Math.PI * radius;
// }
// function diameter(radius) {
//   return 2 * radius;
// }
// function calculate(radius, logic) {
//   const area = [];
//   for (let index = 0; index < radius.length; index++) {
//     area.push(logic(radius[index]));
//   }
//   return area;
// }
// console.log(calculate(radius, area));
// console.log(calculate(radius, cirumference));
// console.log(calculate(radius, diameter));
// Here we not repeating the code. We are achieving abstraction.

// using map instead of calculate 
// const radius = [1, 2, 3, 4];
// function area(radius) {
//   return Math.PI * radius * radius;
// }
// function cirumference(radius) {
//   return 2 * Math.PI * radius;
// }
// function diameter(radius) {
//   return 2 * radius;
// }
// function calculate(radius, logic) {
//   const area = [];
//   for (let index = 0; index < radius.length; index++) {
//     area.push(logic(radius[index]));
//   }
//   return area;
// }
// console.log(radius.map(area));
// console.log(calculate(radius, area));

// Converting calculate to map function
const radius = [1, 2, 3, 4];
function area(radius) {
  return Math.PI * radius * radius;
}
function cirumference(radius) {
  return 2 * Math.PI * radius;
}
function diameter(radius) {
  return 2 * radius;
}
 Array.prototype.calculate=function( logic) {
  const area = [];
  for (let index = 0; index < radius.length; index++) {
    area.push(logic(this[index]));
  }
  return area;
}
console.log(radius.map(area));
console.log(radius.calculate(area));