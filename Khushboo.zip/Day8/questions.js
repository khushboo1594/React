/**
1. What are call back functions?
2. What are pure functions?
3. Prototype and Prototypal inheritance
4. polyfill
5. first class citizens
6. first order functions
7.associative arrays?
8. event loops akshay saini
9. about grouping operator
10. How to convert a number to binary - number.toString(2);
11. different ways of writing functions
12. different types of functions
13. for filtering out the values we can use map function also then what is the use of filter function.
14. about if else, switch
15. map reduce filter ka video akshay saini ka baki hai abhi - 25:40 - Example 10 - tricky reduce()
 */