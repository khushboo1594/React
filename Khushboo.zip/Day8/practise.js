const radius = [45, 23, 12];
cirumference = function (radius) {
    return 2 * Math.PI * radius;
}

area = function (radius) {
    return Math.PI * radius * radius;
}

calculate = function (radius, logic) {
    const array1 = [];
    for (let index = 0; index < radius.length; index++) {
        array1.push(logic(radius[index]));
    }
    return array1;
}
console.log(calculate(radius, area));
console.log(calculate(radius, cirumference));
