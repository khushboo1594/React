/*
 What are pure functions?
    pure functions are functions which operate only on the arguments provided to it and do not change anything outside.
 */
