/**
 * This definition: this refer to object and which object it will refer to depend on the excecution context it is in
 * Excecution Context: Simply put, an execution context is an abstract concept of an environment where the Javascript code is     evaluated and executed. Whenever any code is run in JavaScript, it runs inside an execution context. 
 * Types of Execution Context
   There are three types of execution context in JavaScript.
   1. Global Execution Context — This is the default or base execution context. The code that is not inside any function is in the global execution context. It performs two things: it creates a global object which is a window object (in the case of browsers) and sets the value of this to equal to the global object. There can only be one global execution context in a program.

   2. Functional Execution Context — Every time a function is invoked, a brand new execution context is created for that function. Each function has its own execution context, but it’s created when the function is invoked or called. There can be any number of function execution contexts. Whenever a new execution context is created, it goes through a series of steps in a defined order.

   3. Eval Function Execution Context — Code executed inside an eval function also gets its own execution context, but it not usually used by JavaScript developers.
 */

/**
 * A statement is evaluated from right to left
 */
// GLOBAL CONTEXT

// console.log(this); // window object (in browser)
// console.log(this === window); // true
// a = 37;
// console.log(window.a); // 37
// console.log(this.a); // 37 (browser)
// console.log(globalThis.a); // 37
// window.b = 45;
// console.log(b); // 45
// this.c = "practise";
// console.log(this.c); // practise
// console.log(window.c); // practise
// console.log(globalThis); // window object (in browser). Same result as this. Then why to even use it? -> because it gives you the global object regardless of the execution context you are in. (this works in node also and browser also)
// console.log(globalThis.c); // practise
// ----------------------------------------------------------------------------------------------------------------------------

// FUNCTION CONTEXT
// Function invocation
// function f1() {
//   return this;
// }

// console.log(f1() === window); // true (in browser)
// console.log(f1() === globalThis); // true (in node)
// ----------------------------------------------------------------------------------------------------------------------------
// function fn() {
//   return this.a;
// }
// console.log(fn()); // undefined
// ----------------------------------------------------------------------------------------------------------------------------
// Second Example
// function f2() {
//   "use strict"; // 'use strict'
//   return this;
// }

// console.log(f2()); // undefined

// how to refer to global object
// # Option 1 - call()
// console.log(f2.call(this)); // window object in browser
// // # Option 2
// console.log(window.f2()); // window object in browser
// // # Option 3
// console.log(f2.apply(this)); // window object in browser
// // ----------------------------------------------------------------------------------------------------------------------------
// function doSomething(a, b) {
//   // console.log("inside do something"); // How it is coming here? parameters to match nhi kar rahe hai
//   // adds a propone property to the Window object
//   this.propone = "test value";
// }

// function invocation
// doSomething();
// this.propone = "test value";
// console.log(window.propone); // test value
// ----------------------------------------------------------------------------------------------------------------------------
// Method Invocation
// let person = {
//   name: "John",
//   age: 31,
//   logInfo: function () {
//     // console.log(this); // { name: 'John', age: 31, logInfo: [Function: logInfo] }
//     // console.log(this.name + " is " + this.age + " years old "); // logs John is 31 years old
//   },
// };

// person.logInfo();
// ----------------------------------------------------------------------------------------------------------------------------
// let person = {
//   name: "John",
//   age: 31,
//   logInfo: function () {
//     // console.log(this); // { name: 'John', age: 31, logInfo: [Function: logInfo] }
//     // console.log(name + " is " + age + " years old "); // reference error
//   },
// };

// person.logInfo();
// ----------------------------------------------------------------------------------------------------------------------------
// function inside a method
// let add = {
//   num: 0,
//   calc: function () {
//     // logs the add object
//     console.log(this);

//     function innerfunc() {
//       this.num += 1;

//       // logs the window object
//       console.log(this);

//       return this.num;
//     }
//     return innerfunc();
//   },
// };
// debugger;
// logs NaN
// console.log(add.calc());
// console.log("hello are you there????");
// // logs NaN
// console.log(add.calc());
// ----------------------------------------------------------------------------------------------------------------------------
// Solution of above problem
// let add = {
//   num: 0,
//   calc: function () {
//     // logs the add object
//     // console.log(this);

//     // using thisreference variable to
//     // store the value of this
//     thisreference = this;

//     function innerfunc() {
//       // using the variable to access the
//       // context of the outer function
//       thisreference.num += 1;

//       // logs the add object
//       //   console.log(thisreference);
//       return thisreference.num;
//     }
//     return innerfunc();
//   },
// };

// logs 1
// console.log(add.calc());

// logs 2
// console.log(add.calc());
// ----------------------------------------------------------------------------------------------------------------------------
// Constructor invocation
// let people = function (name, age) {
//   // console.log(this); //  people {}
//   this.name = name;
//   this.age = age;
//   // console.log(this); // people { name: 'John', age: 21 }

//   this.displayInfo = function () {
//     console.log(this); // people { name: 'John', age: 21, displayInfo: [Function (anonymous)] }
//     console.log(this.name + " is " + this.age + " years old"); // John is 21 years old
//   };
// };

// let person1 = new people("John", 21);

// // logs John is 21 years old
// person1.displayInfo();
// ----------------------------------------------------------------------------------------------------------------------------
// CLASS CONTEXT
// class Example {
//   constructor() {
//     const proto = Object.getPrototypeOf(this);
//       console.log(Object.getOwnPropertyNames(proto)); // ['constructor', 'first', 'second']
//     console.log(this); // Example {}
//   }
//   first() {
//     console.log(this); // Example {}
//   }
//   second() {}
//   static third() {}
// }
// new Example();
// new Example().first();
// ----------------------------------------------------------------------------------------------------------------------------
// Indirect Context
// Method call and apply
// function getBrand(prefix) {
//     console.log(this); // { brand: 'Honda' }
//     console.log(prefix + this.brand);
//     console.log(this); // { brand: 'Audi' }
// }

// let honda = {
//   brand: "Honda",
// };
// let audi = {
//   brand: "Audi",
// };

// getBrand.call(honda, "It's a "); // It's a Honda
// getBrand.call(audi, "It's an "); // It's an Audi
// getBrand.apply(honda, ["It's a "]); // It's a Honda
// getBrand.apply(audi, ["It's an "]); // It's a Audi
// ----------------------------------------------------------------------------------------------------------------------------
// Arrow Functions
// let getThis = () => this;
// console.log(getThis() === window); // true
// ----------------------------------------------------------------------------------------------------------------------------
// function Car() {
//   console.log(this); // Car {}
//   this.speed = 120;
//   console.log(this); // Car {speed: 120}
// }
// // ye kya hai? car.prototype?????
// Car.prototype.getSpeed = () => {
//   console.log(this.speed); // undefined
//   return this.speed;
// };

// var car = new Car();
// car.getSpeed();
// ----------------------------------------------------------------------------------------------------------------------------
// Uper wale ka solution -> line 77
// ----------------------------------------------------------------------------------------------------------------------------
// var myVar = 100;

// function WhoIsThis() {
//   console.log(this);
//   var myVar = 200;
//   console.log(this);
//   console.log(myVar);
//   console.log(this.myVar);
// }
// // console.log("**********step 1************");
// // WhoIsThis(); // inferred as window.WhoIsThis()
// // Step 1 answers:
// // 200
// // 100 (browser) (node - undefined)
// console.log("**********step 2**********");
// // Step 2 answers:
// // 200
// // undefined (browser) (node - undefined)
// var obj = new WhoIsThis();
// console.log(obj.myVar); // undefined (browser+node)
// -------------------------------------------------------------------
var obj = {
  name: "vivek",
  getName: function () {
    console.log(this.name);
  },
};

obj.getName();

function WhoIsThis() {
  let name = "vivek";
  let getName = function () {
    console.log(this.name);
  };
}

var obj = new WhoIsThis();
console.log(obj.getName());
