/**
 * Call method is used for function borrowing
 */

// let person1 = {
//   firstName: "Khushboo",
//   lastName: "Patel",
//   fullName: function () {
//     console.log(this.firstName + " " + this.lastName);
//   },
// };

// let person2 = {
//   firstName: "Deepesh",
//   lastName: "Patel",
// };

// person1.fullName.call(person2);

/**
 * person2 fullName me jake this ki jagah le lega. But this is not how we use it generally.
 */

// let person1 = {
//   firstName: "Khushboo",
//   lastName: "Patel",
// };
// const fullName = function (city) {
//   console.log(this.firstName + " " + this.lastName + " from " + city);
// };
// let person2 = {
//   firstName: "Deepesh",
//   lastName: "Patel",
// };

// fullName.call(person1, "Rewa");

/**
 * this ka first argument is the value of this. uske baad hum jis function ko call kar rahe hai uske liye arguments bhej skte hai. A comma seperated list of arguments.
 
 * Difference between call and apply -> the only difference between call and apply is the second argument it takes is a array list of arguments for the function.
 */

// let person1 = {
//   firstName: "Khushboo",
//   lastName: "Patel",
// };
// const fullName = function (city, year) {
//   console.log(
//     this.firstName +
//       " " +
//       this.lastName +
//       " is from " +
//       city +
//       " Born in " +
//       year
//   );
// };
// let person2 = {
//   firstName: "Deepesh",
//   lastName: "Patel",
// };

// fullName.apply(person1, ["Rewa", 1993]);

/**
 * now coming to bind. bind() method is just like call the only difference is that bind method returns a method that we can call later whereas call() and apply() call the method right away.
 */

 let person1 = {
  firstName: "Khushboo",
  lastName: "Patel",
};
const fullName = function (city, year) {
  console.log(
    this.firstName +
      " " +
      this.lastName +
      " is from " +
      city +
      " Born in " +
      year
  );
};
let person2 = {
  firstName: "Deepesh",
  lastName: "Patel",
};

// const printFullName = fullName.bind(person1, "Rewa", 1993);
const printFullName = fullName.bind(this, "Rewa", 1993);
/* 
bind method binds a object to a function, reference it using 'this'.
*/
// console.log(printFullName); // function () { [native code] }
printFullName(person1); // Khushboo Patel is from Rewa Born in 1993
// ----------------------------------------------------------------------------------------------------------------------------
// function Product(name, price) {
//   this.name = name;
//   this.price = price;
// }

// function Food(name, price) {
// //   console.log(this); // Food {}
//   Product.call();
//   Product.call(this, name, price);
//   this.category = "food";
// }

// console.log(new Food("cheese", 5).name); // expected output: "cheese"
// console.log(new Product('cheese', 5)); // Product { name: 'cheese', price: 5 }
// ----------------------------------------------------------------------------------------------------------------------------
// Using call to chain constructors for an object
// function Product(name, price) {
//   this.name = name;
//   this.price = price;
// }

// function Food(name, price) {
//   Product.call(this, name, price);
//   this.category = "food";
// }

// function Toy(name, price) {
//   Product.call(this, name, price);
//   this.category = "toy";
// }

// const cheese = new Food("feta", 5);
// const fun = new Toy("robot", 40);
// console.log(cheese);
// console.log(fun);
// ----------------------------------------------------------------------------------------------------------------------------
//   Using call to invoke a function and specifying the context for 'this'
/**
 * In the example below, when we call greet, the value of this will be bound to object obj.
 */
// function greet() {
//   const reply = [
//     this.animal,
//     "typically sleep between",
//     this.sleepDuration,
//   ].join(" ");
//   //   console.log(reply);
// }

// const obj = {
//   animal: "cats",
//   sleepDuration: "12 and 16 hours",
// };

// greet.call(obj); // cats typically sleep between 12 and 16 hours
// ----------------------------------------------------------------------------------------------------------------------------
// Using call to invoke a function and without specifying the first argument
/**
 * In the example below, we invoke the display function without passing the first argument. If the first argument is not passed, the value of this is bound to the global object.
 */
// var sData = "Wisen";

// function display() {
//   // console.log("sData value is", this.sData);
// }

// display.call(); // sData value is Wisen (browser)
