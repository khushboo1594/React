let c1={
    x:45,
    y:446,
}

let c2={
    x:4555,
    y:4465454,
}

function displayC() {
    console.log(this.x, this.y);
}

const anotherDisplayC=displayC.bind(c1);
anotherDisplayC();