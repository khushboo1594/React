/**
 * Scope means where you can access a particular variable or function.
 * Scope is directly dependent on lexical environment
 * Whenever a execution context is created lexical environment is created
 * Lexical environment is local memory + reference to lexical environment of parent
 * Lexical means hierarchy. Where the function physically is.
 * Scope chain is nothing but the chain of lexical environment referring each other 
 * Lexical means hierarchy so lexical scoping means that they can access variables in their lexical scope.
 */
// function a() {
//   c();

//   console.log(b); // 10
//   /**
//    * Jab compiler line no. 2 par phchta hai he tries to find b in exceution context of function a
//    */

//   function c() {
//     console.log(b); // 10
//   }
/**
 * function c is lexically inside function a and function a is lexically inside global scope
 */
// }
// var b = 10;
// a();
// ----------------------------------------------------------------------------------------------------------------------------
// function a() {
//   var b = 10;

//   c();

//   console.log(b); // 10

//   function c() {
//     console.log(b); // 10
//   }
// }
// a();
// ----------------------------------------------------------------------------------------------------------------------------
function outer() {
  var z = 5;
  function a() {
    var b = 10;

    c();

    function c() {
      console.log(b); // 10
      console.log(z); // 5
    }
  }
  a();
}
// console.log(b); // 10
// console.log(b); // ReferenceError: b is not defined (I assumed it to be true because of hoisitng) (Since var b is function scoped it will not be accessible outside)
outer();
// console.log(b); // 10
// console.log(b); // ReferenceError: b is not defined (I assumed it to be true because of hoisitng) (Since var b is function scoped it will not be accessible outside)

/**
 * When compiler comes across line number 47 it looks for b in local scope of function c when it does not finds it there is looks for it in the lexical environement of its parent, if it does not find it there also it will try to find it in lexical environment of a's parent so on until it finds it.
 */
