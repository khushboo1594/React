/**
 * var is function and global scoped        let is block scoped                    const is block scoped
 * can be re-assigned                       can be re-assigned                     cannot be re-assigned
 * can be re-declared                       cannot be re-declared(error aati hai)  cannot be re-declared(error aati hai)
 */

/**
 * In modern javascript let & const are different ways of creating variables. Earlier in javascript, we use the var keyword for
  creating variables. let & const keyword is introduced in version ES6 with the vision of creating two different types of variables in javascript one is immutable and other is mutable.
  const: It is used to create an immutable variable. Immutable variables are variables whose value is never changed in the complete life cycle of the program.
  let: let is used to create a mutable variable. Mutable variables are normal variables like var that can be changed any number of time.
 */

/**
 * When undefined, when reference error
 */

// VAR
// var x= 2;
// console.log(x);//2

// console.log(x);//undefined
// var x= 2;

// function example() {
//     var x= 2;
// }
// example();
// console.log(x);//reference error

// console.log(x);//reference error

// LET
// let x= 2;
// console.log(x);//2

// console.log(x);//ReferenceError: Cannot access 'x' before initialization
// let x= 2;

function example() {
  let x = 2;
}
example();
console.log(x); //ReferenceError: x is not defined

// CONST
// const x= 2;
// console.log(x);//2

// console.log(x);//reference error: cannot access before initialization
// const x= 2;

function example() {
  const x = 2;
}
example();
console.log(x); //reference error: x is not defines -> meaning that either it is not defined or we are trying to access it out of its scope.

// ----------------------------------------------------------------------------------------------------------------------------
/**
 * statements are evaluated from left to right.???????????
 * console.log is evaluated from left to right (line number: 205)
 */

// VAR
// global scope - var example
// var x = 1;
// if (x === 1) {
//   var x = 2;

//   console.log(x);
//   // expected output: 2
// }

// console.log(x); // 2
// ----------------------------------------------------------------------------------------------------------------------------
// function scope - var
// function foo() {
//   var x = 1;
//   function bar() {
//     var y = 2;
//     console.log(x); // 1 (function `bar` closes over `x`)
//     console.log(y); // 2 (`y` is in scope)
//   }
//   bar();
//   console.log(x); // 1 (`x` is in scope)
//   console.log(y); // ReferenceError, `y` is scoped to `bar`
// }

// foo();
// ----------------------------------------------------------------------------------------------------------------------------
// 'use strict';
// var x = 1;
// globalThis.hasOwnProperty('x'); // true. pata nahi q iska answer false aa raha hai.
// delete globalThis.x; // TypeError in strict mode. Fails silently otherwise.
// delete x;  // SyntaxError in strict mode. Fails silently otherwise.
// ----------------------------------------------------------------------------------------------------------------------------
// statements are evaluated from left to right
// var x = y, y = 'A';
// console.log(x + y); // undefinedA
// ----------------------------------------------------------------------------------------------------------------------------
// LET
// let babyAge = 1;
// let isBirthday = true;

// if (isBirthday) {
// 	let babyAge = 2;
// }

// console.log(babyAge); // Hmmmm. This prints 1

// var babyAge = 1;
// var isBirthday = true;

// if (isBirthday) {
// 	var babyAge = 2;
// }

// console.log(babyAge); // Ah! This prints 2
// ----------------------------------------------------------------------------------------------------------------------------
// At the top level of programs and functions, let, unlike var, does not create a property on the global object. For example:
// var x = 'global';
// let y = 'global';
// console.log(this.x); // "global"
// console.log(this.y); // undefined
// ----------------------------------------------------------------------------------------------------------------------------
// Redeclarations
// Redeclaring the same variable within the same function or block scope raises a SyntaxError.
// if (x) {
//   let foo;
//   let foo; // SyntaxError : identifier foo has already been declared
// }
// ----------------------------------------------------------------------------------------------------------------------------
/**
 * Temporal dead zone (TDZ)
 * let variables cannot be read/written until they have been declared. If no initial value is specified on declaration, the variable is initialized with a value of undefined. Accessing the variable before the declaration results in a ReferenceError
 * Note: This differs from var variables, which will return a value of undefined if they are accessed before they are declared
 * The variable is said to be in a "temporal dead zone" (TDZ) from the start of the block until the declaration has completed.
 */
//  { // TDZ starts at beginning of scope
//   console.log(bar); // undefined
//   console.log(foo); // ReferenceError
//   var bar = 1;
//   let foo = 2; // End of TDZ (for foo)
// }
// ----------------------------------------------------------------------------------------------------------------------------
{
  // TDZ starts at beginning of scope
  // const func = () => console.log(letVar); // OK
  // // Within the TDZ letVar access throws `ReferenceError`
  // let letVar = 3; // End of TDZ (for letVar)
  // func(); // Called outside TDZ!
}
// ----------------------------------------------------------------------------------------------------------------------------
// The TDZ and typeof
// console.log(typeof i); // results in a 'ReferenceError'
// let i = 10;
// console.log(typeof undeclaredVariable); // prints out 'undefined'

/*************************************************/
// console.log(varNumber); // undefined
// console.log(letNumber); // Doesn't log, as it throws a ReferenceError letNumber is not defined

// var varNumber = 1;
// let letNumber = 1;
/*************************************************/
// TEMPORAL DEAD ZONE
{
  // This is the temporal dead zone for the age variable!
  // This is the temporal dead zone for the age variable!
  // This is the temporal dead zone for the age variable!
  // This is the temporal dead zone for the age variable!
  //   let age = 25; // Whew, we got there! No more TDZ
  //   console.log(age);
}
// --------------------------------------------------------
// let a = f(); // error: Uncaught ReferenceError: Cannot access 'b' before initialization
// const b = 2;
// function f() {
//   return b;
// } // b is in the TDZ
/*************************************************/
// Assigning value to the variables without declaring are considered as a global variables even if it is in different scope, because of hoisting e.g:
// function display() {
//     a = 10;
//     var b = 20;
// }
// console.log(a);
// console.log(b);
/*****************************************************************************************************************************/
// var a = 10;
// function outer() {
//     var b = 20;
//     function inner() {
//         console.log(a);
//         console.log(b);
//     }
//     inner();
// }

// outer();
// inner();
// ----------------------------------------------------------------------------------------------------------------------------
// var x = 0;
// function f() {
//   var x = y = 1; // Declares x locally; declares y globally
//   /**
//    * Jab bhi hum multiple assignments karte hai to pehla wala function scoped hota hai baki sab global scoped bante hai. Because compiler automatically var laga leta hai usme
//    */
// }
// f();

// console.log(x, y); // 0 1
// ----------------------------------------------------------------------------------------------------------------------------
// Solution for above
("use strict");

var x = 0;
function f() {
  var x = (y = 1); // Throws a ReferenceError in strict mode.
}
f();

// console.log(x, y);
// ----------------------------------------------------------------------------------------------------------------------------
var x = 0; // Declares x within file scope, then assigns it a value of 0.

// console.log(typeof z); // "undefined", since z doesn't exist yet

function a() {
  var y = 2; // Declares y within scope of function a, then assigns it a value of 2.

  // console.log(x, y); // 0 2

  function b() {
    x = 3; // Assigns 3 to existing file scoped x.
    y = 4; // Assigns 4 to existing outer y.
    z = 5; // Creates a new global variable z, and assigns it a value of 5.
    // (Throws a ReferenceError in strict mode.)
  }

  b(); // Creates z as a global variable.
  // console.log(x, y, z); // 3 4 5
}

a(); // Also calls b.
// console.log(x, z);     // 3 5
// console.log(typeof y); // "undefined", as y is local to function a
// ----------------------------------------------------------------------------------------------------------------------------
// let and const scope
function fn(para) {
  if (para) {
    let fName = "khushboo";
    const age = 56;
  }
  console.log("my " + age + " " + fName); // dono me hi reference error aa rahi hai
}

fn(true);
