/*
1. can custom event be made with - Event() constructor?
2. CustomEvent()
   document.createEvent()
   Event.initEvent()
   EventTarget.dispatchEvent()
   EventTarget.addEventListener()
*/