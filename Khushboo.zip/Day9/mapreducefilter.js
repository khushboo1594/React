/* these all are used for transforming or computating an array. Each returns a new array.
Map/filter/reduce in a tweet:

map([🌽, 🐮, 🐔], cook)
=> [🍿, 🍔, 🍳]

filter([🍿, 🍔, 🍳], isVegetarian)
=>  [🍿, 🍳]

reduce([🍿, 🍳], eat)
=> 💩
*/

/*
MAP //////////////////////////////////////////
  Used for tranforming an array.

  The map() method is used for creating a new array from an existing one, applying a function to each one of the elements of the first array.

Syntax
  var new_array = arr.map(function callback(element, index, array) {
      // Return value for new_array
  }[, thisArg])

  In the callback, only the array element is required. Usually some action is performed on the value and then a new value is returned.
*/

const array1 = [1, 2, 3, 4];
//Double of array1=[2,4,6,8] ////////////////////////
// const output = array1.map(double)//map takes a function as a argument. map k andar hame tranform karne ka logic pass karna hai which will be written in a function.
// function double(x) {
//     return 2*x;
// }
// console.log(output);

//Triple of array1=[3,6,9,12]////////////////////////////////
// const output = array1.map(triple)//map takes a function as a argument. map k andar hame tranform karne ka logic pass karna hai which will be written in a function.
// function triple(x) {
//     return 3*x;
// }
// console.log(output);

//Binary of array1=['1', '10', '11', '100']/////////////////
// Way1
// function binary(x) {
//     return x.toString(2);
// }
// const output = array1.map(binary)//map takes a function as a argument. map k andar hame tranform karne ka logic pass karna hai which will be written in a function.
// console.log(output);

//Binary of array1=['1', '10', '11', '100']/////////////////
// Way2 - callback function
// const output = array1.map(function binary(x) {
//     return x.toString(2);
// })//map takes a function as a argument. map k andar hame tranform karne ka logic pass karna hai which will be written in a function.
// console.log(output);

//Binary of array1=['1', '10', '11', '100']/////////////////
// Way3 - arrow function
// const output = array1.map(x =>
//     x.toString(2)
// )//map takes a function as a argument. map k andar hame tranform karne ka logic pass karna hai which will be written in a function.
// console.log(output);
// console.log(array1);

/*
FILTER
Used for filtering an array.
Arguments
  call back function
Call back function returns
  true - keeps the value
  false - does not keep the value
Return value of filer
  a new filtered array
*/

// Example1
// function isBigEnough(value) {
//   let ans = value >= 10;
//   console.log(ans);
//   return ans;
// }

// let filtered = [12, 5, 8, 130, 44].filter(isBigEnough);
// console.log(filtered);
// filtered is [12, 130, 44]


// for finding odd values in an array///////////////////
// with normal function
// function odd(x) {
//     return x%2!=0;
// }
// const output=array1.filter(odd);
// console.log(output);

// with arrow function
// const output=array1.filter(x=> x%2!=0);
// console.log(output);

// for finding even values in an array///////////////////
// function even(x) {
//     return x%2==0;
// }
// const output=array1.filter(even);
// console.log(output);

// for finding values greater than 4 in an array///////////////////
// function greaterThanFour(x) {
//     return x>=4;
// }
// const output=array1.filter(greaterThanFour);
// console.log(output);

/*
Difference between map and filter is with map we cannot have anything conditional. It will give true and false.
*/
/*
REDUCE
when you have to reduce the array to a single value.
it takes 2 argument:
    1. reducer function
    2. accumulator value
        reducer function takes 2 arguments:
            1. accumulater 
            2. current - it represnts the array values being iterated over
*/

// find sum of the array//////////////////////////////
// const output=array1.reduce((acc, curr)=>{
//  return acc+=curr;
// }, 0);
// console.log(output);

// find max in the array//////////////////////////
// const output = array1.reduce((acc, curr) => {
//     if (curr > acc) {
//         acc = curr;
//     }
//     return acc;
// }, 0);
// console.log(output);

const users = [
  { firstName: "Khushboo", lastName: "Patel", age: 28 },
  { firstName: "Pushpendra", lastName: "Patel", age: 30 },
  { firstName: "Ritu", lastName: "Shrivastava", age: 26 },
  { firstName: "Shweta", lastName: "Acharya", age: 30 },
  { firstName: "Ramwati", lastName: "Patel", age: 26 },
];

// const output = users.map(user =>
//    `${user.firstName} ${user.lastName}`
// );
// console.log(output);

// number of users per age group?/////////////////////////////////
// {28:1, 30:2, 26:2}
// const output = users.reduce((acc, curr) => {
//   if (acc[curr.age]) {
//     acc[curr.age] = ++acc[curr.age];
//   } else {
//     acc[curr.age] = 1;
//   }
//   return acc;
// }, {});

// console.log(output);

// first name of all the people whose age is 30 through chaining of filter and map/////////////////////////////
// const output=users.filter(x=>x.age>26).map(x=>x.firstName);
// console.log(output);

// first name of all the people whose age is 30 with reduce
// way1///////////////////////////
// const output = users.reduce((acc, curr) => {
//   if(curr.age < 30){
//       acc.push(curr.firstName);
//   }
//   return acc;
// }, []);
// console.log(output);

// way2///////////////////////////////
const output = users.reduce((acc, curr) => {
  if (curr.age < 30) {
    // acc = [...acc, curr.firstName];
    acc = acc+ [curr.firstName];
  }
  return acc;
}, []);
console.log(output);
