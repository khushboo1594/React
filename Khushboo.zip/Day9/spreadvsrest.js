//array///////////////////////////////////////////
// let arr1 = [1, 2, 3];
// let arr2 = [...arr1, 4, 5, 6];
// console.log(arr2); //[ 1, 2, 3, 4, 5, 6 ]

//object/////////////////////////////////////////////
// let obj1 = {fName:"khushboo", age:28}; 
// let obj2 = { place:'indore',...obj1};//{ place: 'indore', fName: 'khushboo', age: 28 }
// let obj2 = { ...obj1, place:'indore'};//{ fName: 'khushboo', age: 28, place: 'indore' }
// // both are valid
// console.log(obj2); 

//Rest operator/////////////////
function sum(...a) {
    let result=0;
    for(){
        
    }
    console.log(a);
}

sum(5,6,7,45,12);