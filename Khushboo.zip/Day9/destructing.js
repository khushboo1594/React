/* 
Destructuring assignment is a special syntax that allows us to “unpack” arrays or objects into a bunch of variables.
It’s called “destructuring assignment,” because it “destructurizes” by copying items into variables. But the array itself is not modified.
*/

// Array destructing
// const arr=['Khushboo', 'Patel'];
// let[firstName, lastName]=arr;
// console.log(firstName, lastName);

// Ignore elements using commas
// let [firstName, , title] = ["Julius", "Caesar", "Consul", "of the Roman Republic", "bjhfjgf", "ngdfj"];

// console.log(title); // Consul
// In the code above, the second element of the array is skipped, the third one is assigned to title, and the rest of the array items is also skipped (as there are no variables for them).

/*
QUESTIONS
> Object.entries();
*/

// Object destructing
let options = {
  title: "Menu",
  width: 100,
  height: 200,
};

let { title, width, height } = options;

console.log(title); // Menu
console.log(width); // 100
console.log(height); // 200
