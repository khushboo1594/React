let arr1=[45,454,212,4];
// arr1.forEach(element => {
//     console.log(element);
// });

// for (const key in arr1) {
//     console.log(key);
// }

// for (const iterator of arr1) {
//     console.log(iterator);
// }

// let obj1 = {fName:"khushboo", age:28}; 
// obj1.forEach(element => {
//     console.log(element);
// });