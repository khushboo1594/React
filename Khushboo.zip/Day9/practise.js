function isBigEnough(value) {
  let ans = value >= 10;
  console.log(ans);
  return ans;
}

let filtered = [12, 5, 8, 130, 44].filter(isBigEnough);
console.log(filtered);
// filtered is [12, 130, 44]
