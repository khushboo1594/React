/**
 *                                                            ****NOTES****
 * 1. Agar var defined hai but use value nahi mili hai to it will be undefined.
 * 2. Agar var defined hi nahi hai to it will give -> ReferenceError: (variable_name) is not defined.
 * 3. If we try to access a variable oustide it's scope it will give reference error.
 *    WHY????
 *    Because it is no where to be found in memory.
 * 4. Are arrow functions and function expression considered as functions? Meaning, are they hoisted? So, the ans is No.
 *    They are not hoisted and if we try to access them before declaration they will give -> TypeError: fExp is not a function.
 */

/**
 * Even before code starts executing memory is allocated to each and every variable and function.
 * What is hoisting?
 *
 * Read this https://www.digitalocean.com/community/tutorials/understanding-hoisting-in-javascript for hoisting
 */

// ----------------------------------------------------------------------------------------------------------------------------

// var x = 7;
// function print() {
//   console.log("My name is Khushboo Patel");
//   // var x = 7; // If variable x is declared here and we tried to console it oustide it's scope it will give reference error.
// }
// print(); // My name is Khushboo Patel
// console.log(x); // 7

// ----------------------------------------------------------------------------------------------------------------------------

// Example of hoisting
// print(); // My name is Khushboo Patel
// console.log(x); // undefined
// var x = 7;
// function print() {
//   console.log("My name is Khushboo Patel");
//   // var x = 7; // If variable x is declared here and we tried to console it oustide it's scope it will give reference error.
// }

// ----------------------------------------------------------------------------------------------------------------------------

// print(); // My name is Khushboo Patel
// console.log(x); // ReferenceError: x is not defined
// function print() {
//   console.log("My name is Khushboo Patel");
// }

// ----------------------------------------------------------------------------------------------------------------------------

// What will be the output if we tried to acess function before its declaration will it come undefined just like a hoisted variable?
// console.log(print);
// function print() {
//   console.log("My name is Khushboo Patel");
// }

// Output:
// ƒ print() {
//   console.log("My name is Khushboo Patel");
// }
// ----------------------------------------------------------------------------------------------------------------------------

// What happens if we try to access arrow functions before it's definition?
// console.log(print()); // ReferenceError: print is not defined
// print = () => {
//   console.log("My name is Khushboo Patel");
// };

/**
 * As we know that before the code even starts executing execution context is created and memory is created for code. Now the interesting thing is in Example: Line number-62, we are trying to access print function before it's definition. Usually what happens with a function is that they are hoisted but with arrow function that is not the case. They are not hoisted. That is why it is giving reference error as no memory has been allocated to it.
 */
// ----------------------------------------------------------------------------------------------------------------------------

// What happens if we try to access arrow functions before it's definition?

// print = () => {
//   console.log("My name is Khushboo Patel");
// };
// console.log(print()); // My name is Khushboo Patel
// console.log("something else!!!");

/**
 * What happens in the case of arrow functions if the declaration is before the invocation. Does it not considered as function then also?. It is considered as function. You can see it by putting debugger.
 */

// ----------------------------------------------------------------------------------------------------------------------------
// Function hoisting
// catName("Tiger");
// function catName(name) {
//   console.log("with definition");
//   console.log("My cat's name is " + name);
// }
// function catName(name) {
//   console.log("without definition");
// }
// ----------------------------------------------------------------------------------------------------------------------------
/**
 * lexicalEnvironment = {
  catName: < func >
}
 */
// ----------------------------------------------------------------------------------------------------------------------------
// catName("Tiger");

// var catName = function(name) {
//   console.log("without definition");
// }
// Error: catName is not a function. Because function declarations are hoisted. Function expressions hoist nahi hote.
// ----------------------------------------------------------------------------------------------------------------------------
// var hoisting
// 'use strict';
// // Example 1
// console.log(a); // Error: not defined

// // Example 2
// console.log(a);
// var a = 10; // undefined. Only declaration has been moved to the top not initialization

// // Example 3
// a = 10; // yaha par a ki value undefined hai
// console.log(a);
// var a; // 10. Yaha define pehle hi kar diya.

// // Example 4
// console.log(a);
// a = 10; // Error: not defined

// // Example 5
// a = 10;
// console.log(a); // 10. Initialization also causes declaration.
// ----------------------------------------------------------------------------------------------------------------------------
// let hoisting

// Example 1
// console.log(a);
// let a = 10; // Error: can't access 'a' before initilization

// // Example 2
// a = 10;
// // ----------------------------------------------------------------------------------------------------------------------------console.log(a);
// let a; // Error: can't access 'a' before initilization

// // Example 3
// let a;
// console.log(a); // outputs undefined
// a = 5;

// Example 4
// function foo() {
//   console.log(a);
// }
// let a = 20;
// foo(); // This is perfectly valid. Answer: 20

// Example 5
// function foo() {
//   console.log(a);
// }
// foo();
// let a = 20; // Error: can't access 'a' before initilization
// ----------------------------------------------------------------------------------------------------------------------------
// TEMPORAL DEAD ZONE
{
  // bestFood’s TDZ starts here (at the beginning of this block’s local scope)
  // bestFood’s TDZ continues here
  // bestFood’s TDZ continues here
  // bestFood’s TDZ continues here
  //   console.log(bestFood); // returns ReferenceError because bestFood’s TDZ continues here
  // bestFood’s TDZ continues here
  // bestFood’s TDZ continues here
  // let bestFood = "Vegetable Fried Rice"; // bestFood’s TDZ ends here
  // bestFood’s TDZ does not exist here
  // bestFood’s TDZ does not exist here
  // bestFood’s TDZ does not exist here
}
{
  // TDZ starts here (at the beginning of this block’s local scope)
  // bestFood’s TDZ continues here
  // bestFood’s TDZ continues here
  // bestFood’s TDZ continues here
  // bestFood’s TDZ continues here
  // bestFood’s TDZ continues here
  // bestFood’s TDZ continues here
  // let bestFood = "Vegetable Fried Rice"; // bestFood’s TDZ ends here
  //   console.log(bestFood); // returns "Vegetable Fried Rice" because bestFood’s TDZ does not exist here
  // bestFood’s TDZ does not exist here
  // bestFood’s TDZ does not exist here
}
{
  // TDZ starts here (at the beginning of this block’s local scope)
  // bestFood’s TDZ continues here
  // bestFood’s TDZ continues here
  // bestFood’s TDZ continues here
  // bestFood’s TDZ continues here
  // bestFood’s TDZ continues here
  // bestFood’s TDZ continues here
  // let bestFood; // bestFood’s TDZ ends here
  //   console.log(bestFood); // returns undefined because bestFood’s TDZ does not exist here
  // bestFood = "Vegetable Fried Rice"; // bestFood’s TDZ does not exist here
  //   console.log(bestFood); // returns "Vegetable Fried Rice" because bestFood’s TDZ does not exist here
}

// \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

// https://youtu.be/gSDncyuGw0s?list=PLlasXeu85E9cQ32gLCvAvr9vNaUccPVNP&t=110 \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
// Function hoisting
// var x = 10;
// a();
// b();

// function a() {
//   var x = 20;
//   console.log(x);
// }
// function b() {
//   var x = 100;
//   console.log(x);
// }

// What if I used "use strict" mode in the above example \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
// 'use strict'
// var x = 10;
// a();
// b();

// function a() {
//   var x = 20;
//   console.log(x);
// }
// function b() {
//   var x = 100;
//   console.log(x);
// }