/**
 ** The values behave differently than the mathematical infinity:
    Any positive value, including POSITIVE_INFINITY, multiplied by NEGATIVE_INFINITY is NEGATIVE_INFINITY.
    Any negative value, including NEGATIVE_INFINITY, multiplied by NEGATIVE_INFINITY is POSITIVE_INFINITY.
    Zero multiplied by NEGATIVE_INFINITY is NaN.
    NaN multiplied by NEGATIVE_INFINITY is NaN.
    NEGATIVE_INFINITY, divided by any negative value except NEGATIVE_INFINITY, is POSITIVE_INFINITY.
    NEGATIVE_INFINITY, divided by any positive value except POSITIVE_INFINITY, is NEGATIVE_INFINITY.
    NEGATIVE_INFINITY, divided by either NEGATIVE_INFINITY or POSITIVE_INFINITY, is NaN.
    Any number divided by NEGATIVE_INFINITY is zero.
 */

// console.log(-4/0); // -Infinity
// console.log(4/0); // Infinity

// console.log(typeof -Infinity); // number
// console.log(typeof Infinity); // number

// console.log(-Infinity > 0); // false
// console.log(-Infinity < 0); // true
// console.log(-Infinity == 0); // false
// console.log(-Infinity > -0); // false
// console.log(-Infinity < -0); // true

// console.log(Infinity > 0); // true

// console.log(-Infinity * 2); // -Infinity
// console.log(-Infinity * Infinity); // -Infinity
// console.log(-Infinity * -Infinity); // Infinity
// console.log(-Infinity * -5); // Infinity

console.log(Infinity * 2); // -Infinity
console.log(Infinity * Infinity); // -Infinity
console.log(Infinity * -Infinity); // Infinity
console.log(Infinity * -5); // Infinity

// console.log(-Infinity * 0); // NaN
// console.log(-Infinity * -0); // NaN
