// String.prototype.toString() \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
/*The toString() method returns a string representing the specified object.*/

const stringObj = new String("foo");

console.log(stringObj);
/* expected output: String { "foo" }
0: "f"
1: "o"
2: "o"*/

console.log(stringObj.toString());
// expected output: "foo"

/*Syntax
    toString();
Return value
    A string representing the calling object. 
Description
    The String object overrides the toString() method of the Object object; it does not inherit Object.prototype.toString(). For String objects, the toString() method returns a string representation of the object and is the same as the String.prototype.valueOf() method. Using toString() on a Number object returns the binary equivalent. Using parseInt().toString() on a String object returns the binary equivalent.*/

// The following example displays the binary value of a String object: \\\\\\\\\\\\\\\\\\\\
var x = new String("13");
console.log(parseInt(x).toString(2)); // logs '1101'

// The following example displays the binary value of a Number object: \\\\\\\\\\\\\\\\\\\
var x = new Number(13);
console.log(x.toString(2)); // logs '1101'

// when you use toString on a number
/*
    The toString() returns a number as a string.
    Every JavaScript object has a toString() method.

    The toString() method is used internally by JavaScript when an object needs to be displayed as a text (like in HTML), or when an object needs to be used as a string.

    Syntax
        number.toString(radix)
    Parameters
        Parameter	Description
            radix	Optional.
                    The base to use.
                    Must be an integer between 2 and 36.
                    Base 2 is binary
                    Base 8 is octal
                    Base 16 is hexadecimal.
    Return Value
        Type	    Description
        A string    The number as a string.
*/

let num = 15;
let text = num.toString();
console.log(text);
