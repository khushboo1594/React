/*
********String.prototype.valueOf()*************
The valueOf() method returns the primitive value of a String object.
*/

const stringObj = new String('foo');

console.log(stringObj);
/* expected output: String { "foo" }
0: "f"
1: "o"
2: "o"*/

console.log(stringObj.valueOf());
// expected output: "foo"

// difference kya hua fir toString aur valueOf me?