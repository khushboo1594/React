// var x = 100;
// {
//   var x = 10;
//   let a = 2;
//   const b = 20;
//   console.log("x: inside block", x);
//   console.log("a:", a);
//   console.log("b:", b);
// }
// console.log("x: outside block", x);
/*  The x at line number 3 ""shadows"" the x at line number 1 because we all know that the x at line number 3 is global scoped and so is the x at line number 1. They both are pointing to the same memory location.  */

// Now let's run the same code but with 'let' \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
// let a = 100;
// {
//   var x = 10;
//   let a = 20;
//   const b = 30;
//   console.log("a: inside block", a);
//   console.log("a:", a);
//   console.log("b:", b);
// }
// console.log("a: outside block", a);
// See the console by putting debugger you will understand. 

// Now let's run the same code but with 'const' \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
const b = 100;
{
  var x = 10;
  let a = 20;
  const b = 30;
  console.log("b: inside block", b);
  console.log("a:", a);
  console.log("b:", b);
}
console.log("b: outside block", b);