let count = 0;
const getData = () => {
  // calls an API and get data
  console.log("fetching data...", count++);
};

const debounce = (fn, delay) => {
  let timer;
  return () => {
    let context = this;
    args = arguments;
    // arguments fn k arguments ko represent kar raha ahi
    clearTimeout(timer);
    timer = setTimeout(() => {
        fn.apply(context, args);
        // you were wondering why did we store this in context. so the reason is - hum chahte hai k fn debounce k this ko refer kare so we are storing it in an indentifier called context
    //   fn();
    }, delay);
  };
};
const betterFunction = debounce(getData, 300);

// debouncing with flag \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
// let count = 0;
// const getData = () => {
//   // calls an API and get data
//   console.log("fetching data...", count++);
// };

// const debounce = (fn, delay) => {
//   let flag = true;
//   return function () {
//     let context = this;
//     args = arguments;
//     if (flag) {
//       fn.apply(context, args);
//       flag = false;
//       setTimeout(() => {
//         flag = true;
//       }, delay);
//     }
//   };
// };
// const betterFunction = debounce(getData, 3000);
