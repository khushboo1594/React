localStorage.setItem("name", "khushboo");
localStorage.setItem("age", "28");
// console.log(localStorage.getItem('name'));
localStorage.removeItem("age");
localStorage.clear();

// store obj in local storage \\\\\\\\\\\\\\\\\\\\\\\
const info = {
  firstName: "khushboo",
  age:28,
};
localStorage.setItem('info', JSON.stringify(info));

// storing mulitple key value pair \\\\\\\\\\\\\\\\\\\\\\\\\\
// localStorage.setItem("name", "khushboo", "age", 28);
// we cannot store multiple key value pair in local storage in one go
