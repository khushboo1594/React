// DIFFERENT DATA TYPES IN JS
// primitive: number, string, null, undefined, boolean, object, bigint, symbol. Other: Objects
// console.log(typeof "hello"); // string
// console.log(typeof 12); // number
// console.log(typeof 454.1245); //number
// console.log(typeof true); // boolean
// console.log(typeof undefined); // undefined
// console.log(typeof null); // null // Iska type object aa raha hai?????
// console.log(typeof 454132542185432018703248432109842212121212212121n); //bigint // bigint k liye end me n append karna padta hai
// console.log(typeof 4n); //bigint. Value choti hai badi hai does not matter, bus n lagana hai
// console.log(typeof NaN); // number
// console.log(NaN === NaN); // false. type same hai still false deta hai javasript
// console.log(typeof string); // undefined
// console.log(typeof boolean); // undefined
// console.log(typeof undefined); // undefined
// console.log(typeof null); // object
// console.log(typeof bigint); // undefined
// console.log(typeof number); // undefined
// console.log(typeof this); // object

console.log(typeof Boolean); // function. 
console.log(typeof String); // function. 
console.log(typeof Number); // function. 
console.log(typeof Undefined); // undefined. 
console.log(typeof Null); // undefined. 
console.log(typeof BigInt); // function. 

// console.log(typeof typeof typeof typeof Boolean); // string. In sab ka string aata hai qki typeof job b return karta hai wo string type ka hota hai to islie kitne bhi typeof typeof laga lo string aata hai 
// console.log(typeof typeof typeof typeof 85452n); // string
// console.log(typeof typeof typeof typeof boolean); // string
// console.log(typeof typeof k); // string





// NUMBER
// console.log(1/0); // Infinity
// console.log(-1/0); // -Infinity
// console.log(Infinity); // Infinity
// console.log("hello"/0); // NaN. Agar pure expression me kahi bhi string hua to NaN ans aaega
// console.log(NaN/0); // NaN. Agar pure expression me kahi bhi NaN hua to NaN ans aaega.
// console.log( NaN + 1 ); // NaN
// console.log( 3 * NaN ); // NaN
// console.log( "not a number" / 2 - 1 ); // NaN
// // Exception
// console.log(NaN**0); // 1
// console.log();
// console.log(Number.MAX_VALUE); // 1.7976931348623157e+308
// console.log(Number.MIN_VALUE); // 5e-324

var float = 4545.454;
// Returns true if a number is safe integer. Safe integer meaning -> within the range number is safe number.
// // console.log(Number.isSafeInteger(float)); // false.
// console.log(Number.MAX_SAFE_INTEGER); // 9007199254740991
// console.log(Number.MIN_SAFE_INTEGER); // -9007199254740991

// console.log(+0 === -0); // true. -0 +0 is same
// but
// console.log(42 / -0); // -Infinity
// console.log(42 / 0); // Infinity. Agar division me use hoga to difference dikhega fir.




// BIGINT
// bigint literal
var BIGINT = 45454n;
// // console.log(BIGINT); // 45454n
// // // bignit by BigInt() function
// // var BIGINT1 = BigInt("45454");
// // console.log(BIGINT1); // 45454n
// // var BIGINT2 = BigInt(45454);
// console.log(BIGINT2); // 45454n

// console.log(4n + 5n); // 9n
// console.log(4n - 5n); // -n
// console.log(4n / 5n); // 0n. Ye round off karke answer deta hai
// console.log(4 / 5); // 0.8
// console.log(4n * 5n); // 20n
// console.log(4n * 5); // Error : cannot mix bigint with other types




// STRING
var str1 = 'hello';
var str2 = "khushboo";
var str3 = `patel`;
// console.log(str1); // hello
// console.log(str2); // khushboo
// console.log(str3); // patel
var str4 = `hello ${str2} ${str3}`;
// console.log(str4); // hello khushboo patel
// var str5 = `hello ${str2}${str3}`; // console -> hello khushboopatel
// var str5 = `hello ${str2str3}`; // console -> error
var str6 = `hello ${1+2}`;
// console.log(str6); // hello 3





// BOOLEAN



