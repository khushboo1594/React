"use strict";

//  /******************************* arrayName.every(function) function *******************************/
// const numbers = [45, 2, 454, 89];
// // console.log(numbers.every(check));
// function check(number) {
//   return number > 45;
// }

// /*******************************entries() function
//  * It returns a array iterator object with key/value pair
//  ******************************/
//  const ages = [45, 2, 48, 89];
//  const entriesAges = ages.entries();
//  for(var x of entriesAges){
//      //console.log(x);
//  }

// /******************************* keys() function
//  * It returns a array iterator object, containing the keys of the array*
//  ******************************/
// const number = [45, 2, 454, 89];
// const keysNumbers = number.keys();
// for(var x of keysNumbers){
//     // console.log(x);
// }

// /******************************* indexOf()
//  * It returns the index of first ocurrence of the specified element
//  * If not found -> -1
//  * second parameter -> from where to start the search
//  *  negative number -> searches from the last (right to left)
//  *      basic searching -> left to right
// ******************************/
// //const names = ["piya", "azhar", "janice", "hema"];
// //var index = names.indexOf("azhar", -2);
// //console.log(index);

// /******************************* lastIndexOf()
//  * It returns the index of last ocurrence of the specified element
//  * If not found -> -1
//  * second parameter -> from where to start the search
//  *  negative number -> searches from the last (right to left)
//  *      basic searching -> left to right
// ******************************/
// const names = ["piya", "azhar", "janice", "azhar"];
// var index = names.lastIndexOf("azhar");
// console.log(index);

/**
 * CONCAT
 * Same array ko bhi aapas me concat kar skte hai
 * It returns a new array
 * It does not change the original array, whereas push does
 */

// let arr = [1, 2];

// create an array from: arr and [3,4]
// console.log( arr.concat([3, 4]) ); // 1,2,3,4

// create an array from: arr and [3,4] and [5,6]
// console.log( arr.concat([3, 4], [5, 6]) ); // 1,2,3,4,5,6

// create an array from: arr and [3,4], then add values 5 and 6
// console.log( arr.concat([3, 4], 5, 6) ); // 1,2,3,4,5,6
// let arrayLike = {
//   0: "something",
//   length: 1,
// };

// console.log( arr.concat(arrayLike) );

/**
 * Something extra with arrays
 */
// let fruits = []; // make an array
// fruits[99999] = 5; // It won't give any error if you assign a property with the index far greater than its length
// fruits.age = 25; // Array me object jaise key b bana skte hai. It will look like this -> [ <99999 empty items>, 5, age: 25 ]
// console.log(fruits); // [ <99999 empty items>, 5, age: 25 ]

// let arr = [1, 2];
// console.log(String(arr)); // 1,2,3

/**
 * Push/Pop, Shift/Unshift
 * Push, Unshift me multiple elements daal sakte hai ek saath
 * If we can add multiple elemens in push also then what is the difference between push and concat?
 *  * Push always add method to the end of the array.
 *    Concat se hum array k starting me bhi add kar skte hai aur end me bhi
 *  * Push changes the original array
 *    whereas concat does not. It returns a new Array
 *  * Push/ Pop is faster than Shift/ Unshift.
 *    Push/ Pop ko element/s ko end me add ya delete karna hota hai + length change karni hoti hai
 *    Shift/ Unshift ko sabka index change karna padta hai + sabko aage shift karna hota hai + elements ko daalna hota hai nae jagah + length update karni hoti hai.
 */
//  let arr = [1, 2];
//  var last = arr.pop();
//  console.log(last); // 2
// console.log me arr.pop() likhne par kuch nahi aa raha
// arr.pop().pop() - error -> arr.pop(...).pop is not a function

// let arr1 = [1, 2];
// arr1.push(3,4,['fjdh', 78]);
// console.log(arr1); // [ 1, 2, 3, 4, [ 'fjdh', 78 ] ]
// console.log me arr1.push(3,4,['fjdh', 78]) likhne par it is giving unexpected results
// It is also giving unexpected results in this case -> var arr3 = arr1.push(3,4,['fjdh', 78]);console.log(arr3);

// let arr = [1, 2, 6, 7];
// var last = arr.shift();
// console.log(last); // 1
// console.log me arr.shift() likhne par it is giving unexpected results

let arr1 = [1, 2];
arr1.unshift(3, 4, ["fjdh", 78]);
// console.log(arr1); // [ 3, 4, [ 'fjdh', 78 ], 1, 2 ]
// console.log me arr1.unshift(3,4,['fjdh', 78]) likhne par it is giving unexpected results
// It is also giving unexpected results in this case -> var arr3 = arr1.push(3,4,['fjdh', 78]);console.log(arr3);

/**
 * toString
 * First of all toString sabhi obejcts k liye hoti hai. Since array bhi ek object hi hai to uske liye bhi hoti hai
 */

const fruits = ["Banana", "Orange", "Apple", "Mango"];
// console.log(fruits.toString()); // Banana,Orange,Apple,Mango
// console.log(fruits); // [ 'Banana', 'Orange', 'Apple', 'Mango' ]

let arr = [1, 2, 3];
var obj = {
  key: 0,
  value: "k"
}
console.log(arr.concat(obj)); // [1,2,3,{ key: 0, value: 'k' }]
console.log((arr.concat(obj)).toString()); // 1,2,3,[object Object]

// console.log(arr); // [1,2,3]
// console.log(String(arr)); // 1,2,3
// console.log( [] + 1 ); // 1 // Here it is treating [] as empty string. [] -> "". 
// console.log( [1] + 1 ); // 11
// console.log( [1,2] + 1 ); // 1,21 
// console.log( arr + fruits ); // 1,2,3Banana,Orange,Apple,Mango // When you will be adding arrays with + operator, array will be treated as string
