/**
 * String conversion
 * We do this type of conversion when we are outputting something
 */
var x = true; // booelan value bina quotes k likhte hai. Agr quotes me likhenge to string ban jaegi
// console.log(typeof x); // boolean
// var str  = String(x); // Converting x to string explicitly
// console.log(typeof str); // string
// console.log(str); // true

// Implicit conversion to string
// console.log("2" + 2); // 22. Here numeric 2 has been implicitly converted to string. This happens only in the case of + operator

// Point to note
// console.log("2" * 2); // 0. Here the answer will be zero as in this case "2" is converted to number. Same is the case with divide, multiply

/**
 * Number conversion 
 */
// let str = "123";
// let num = Number(str); // becomes a number 123
// console.log(num); // 123

let str = "Hello";
let num = Number(str); 
// console.log(num); // NaN

// console.log(Number(undefined)); // NaN
// console.log(Number(null)); // 0
// console.log(Number(true)); // 1
// console.log(Number(false)); // 0
// console.log(Number("     123      ")); // 123. Agar string me keval number hai to number convert ho jaega number me 
// console.log(Number("     123      z")); // NaN. Qki isme 1 alphabet b hai
// console.log(Number(             )); // 0
// console.log(Number()); // 0
// console.log(Number("")); // 0
// console.log(Number("                    ")); // 0
// console.log(Number());
console.log(Number(12n)); // 12

// BIGINT
// console.log(BigInt(12n)); // 12. Bigint ko bhi number me convert kar skte hai
// console.log(BigInt(12.565)); // Error: It cannot be converted to bigint as it is not a integer

/**
 * Explicit Boolean conversion
 */
// console.log(Boolean(null)); // false
// console.log(Boolean("")); // false
// console.log(Boolean(undefined)); // false
// console.log(Boolean(0)); // false
// console.log(Boolean('0')); // true. Since here 0 is a string not a number
// console.log(Boolean(NaN)); // false

// console.log(Boolean("hello")); // true
// console.log(Boolean(1)); // true