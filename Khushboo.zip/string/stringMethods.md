# split
https://www.w3schools.com/jsref/jsref_split.asp