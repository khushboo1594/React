/**
 * Also called: fat arrow functions
 * Definition: it is a simplified way of writing a function
 * Introduced: 2015, ES6
 */

// let a = 2;
// let b = 3;
// const sum = () => a + b; // || const sum = () => { return a + b;}. since ye 1 line ka statement tha we can omit return and brackets. Agar argument ek hi hai to we can omit the parenthesis also. Agar ek se jyada hai then lagana padega. 
// console.log(sum());
// ----------------------------------------------------------------------------------------------------------------------------
// const a = (a,b)=>{a+b;}
// a(2,3);
// ----------------------------------------------------------------------------------------------------------------------------
// var a = function (params) {

// }
// console.log(typeof a);//function
// ----------------------------------------------------------------------------------------------------------------------------

// const camera = {
//   price: 60000,
//   brand: "Canon",
//   myDesc: function () {
//     return `I have a ${this.brand} camera of price ${this.price}`;
//   },
// };

// console.log(camera.myDesc()); // I have a Canon camera of price 60000
/**
 * in a method this refers to object
 */

// ----------------------------------------------------------------------------------------------------------------------------

// Using arrow functions with this keyword
// const camera = {
//   price: 60000,
//   brand: "Canon",
//   myDesc:  () =>{
//     return this;
//   },
// };

// console.log(camera.myDesc()); // window object. // in a Arrow function that is written inside a object this refers to window object

// ----------------------------------------------------------------------------------------------------------------------------
// const fun = ()=> {
//     console.log(this);
// }
// fun();
// ----------------------------
(a) => {
    return a + 100;
  }

  (5);
//   If I cannot call an anonymous function like this. Then how to use it?