/**
 * 1. Anonymous
 * 2. First class functions/citizens
 * 3. arrow functions
 * 4. Function statement vs function declaration vs function expression
 * 5. Named function expression
 * 6. Difference between parameters and arguments
 */

// Function statement is same as function declaration
// Syntax ->
function fStatement(params) {
  console.log("Function statement");
}
// fStatement();

// Function expression - function acts like a value
var fExp = function (params) {
  console.log("Function expression");
};
// fExp();
// line number 18 me hum var ki jagah let and const bhi use kar skte the. It would have behaved the same as normal let and const variable.

/**
 * The difference between function statement and expression is of hoisting.
 */

// What will happen in the case of hoisting in function statement and function expression
// Function statement is hoisted. Even on hoisting the js engine has full access to function definition
// fStatement(); // Function statement
function fStatement(params) {
  console.log("Function statement");
}

//  Function exp is hoisted but.
fExp(); // TypeError: fExp is not a function. It is giving this error because it considers fExp as a variable. Assigns value undefined to it till the point it encounters its declaration.
var fExp = function (params) {
  console.log("Function expression");
};

// Anonymous function-> function without name. Use: when we want to use it as values. Example: function expression.
// function () {

// }
// It is giving error as we cannot use it without using it as value for something

// Named function expression -> same as function expression. It is just that we give name to the function here.
// var fExp = function nFun(params) {
//   console.log(nFun);
//   /**
//    * Output:
//    * ƒ nFun(params) {
//         console.log(nFun);
//     }
//    */
// };
// fExp();
// nFun(); // ReferenceError: nFun is not defined

// Parameter vs argument
/**
 * Parameters: variables mentioned in the fun declaration
 * Arguments: values we pass while calling a function
 */

/**
 * First class functions/citizens: The ability to use functions as value being able to pass them as argument to another function, return value from a function is called as First class functions
 */
// Function as argument to another function
// function fClassFun(params) {
//     console.log(params);
// }

// // We can pass anonymous function as argument
// // fClassFun(function () {
// //     console.log("I am a argument to a function");
// // });

// // We can pass function statement as argument
// fClassFun(fStatement);

// // We can pass function expression also as an argument
// fClassFun(fExp);

// return a function from a function
// function fClassFun(params) {
//   return params;
// }
// console.log(
//   fClassFun(function () {
//     console.log("I am a argument to a function");
//   })
// ); 
/**
 * Output: 
 * function () {
        console.log("I am a argument to a function");
    }
 */

// return a anonymous function 
// function fClassFun() {
//   return function (params) {
//       console.log("Hello!! I am a function returned from a function");
//   };
// }
// console.log(fClassFun());

// // We can pass function expression also as an argument
// fClassFun(fExp);
