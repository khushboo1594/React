/**
 * A closure is formed when a function is bundled together with the lexical environment of it .
 * Uses:
 *  1. currying
 *  2. functions run only once
 *  3. memoize
 *  4. settimeouts
 *  5. iterators
 *  6. async
 */

// 2. functions run only once////////////////////////
// var something = (function() {
//     var executed = false;
//     return function() {
//         if (!executed) {
//             executed = true;
//             // do something
//         }
//     };
// })();

// something(); // "do something" happens
// something(); // nothing happens
 
// function x() {
//   var a = 7;
// //   function y() {
// //     console.log(a);
// //   }
// //   return y;
//     return function y() {
//       console.log(a);
//     }
//   // It's same
// }
// var z = x();
// z(); // 7
// ----------------------------------------------------------------------------------------------------------------------------
// function x() {
//   var a = 7;
//   function y() {
//     console.log(a);
//   }
//   a = 100;
//   return y;
// }
// var z = x();
// z(); // 100
// ----------------------------------------------------------------------------------------------------------------------------
// function z() {
//   var b = 900;
//   return function x() {
//     var a = 7;
//     return function y() {
//       console.log(a, b); 
//     }
//   }
// }
// var k = z();
// console.log(k);
// k();
// return k andar return k liye currying use hota hai

// A real world implementaiton of closure
var updateClickCount = (function(){
    var counter = 0;

    return function(){
        ++counter;
        // Do something with counter
        console.log("updateClickCount : ", counter);
    }
})();   
updateClickCount();