/*
set time out function k liye js wait nhi karta it moves aage and after finishing that task it comes to set time out.
*/

function xyz(){
    setTimeout(()=>{
        console.log("i will be called after 3 seconds");
    }, 3000);
    console.log('i am in xyz function');
}
xyz();
// here settimeout is making a closure with function xyz. settimeout is taking the callback function and attaching a timer with it and keeping it somewhere. when the timer expires it takes it into call stack and run it.


