// Normal Function
// function f1() {
//   return this;
// }
// console.log(f1()); // window object

// // Arrow Function
// var arrow = () => {
//   return this;
// };
// console.log(arrow()); // window object
/**
 * So what we undrstood is that 'this' refers to global/window object whether it's a normal function or an arrow function.
 */

// ----------------------------------------------------------------------------------------------------------------------------

// use strict k case me this kisko refer karta hai?

// Normal Function
// function f1() {
//   "use strict"; // 'use strict'
//   return this;
// }

// console.log(f1()); // undefined

// // Arrow Function
// var arrow = () => {
//   "use strict"; // 'use strict'
//   return this;
// };

// console.log(arrow()); // window object

/**
 * So the conclusion is ke use strict k case me normal function me this is undefined whereas arrow function me this still refers to global/ window object
 */

// ----------------------------------------------------------------------------------------------------------------------------
// Method Invocation and this in case of Normal Function
// let person = {
//   name: "John",
//   age: 31,
//   logInfo: function () {
//     // console.log(this); // { name: 'John', age: 31, logInfo: [Function: logInfo] }
//     // console.log(this.name + " is " + this.age + " years old "); // logs John is 31 years old
//   },
// };

// person.logInfo();

// Method Invocation and this in case of arrow Function
// let person = {
//   name: "John",
//   age: 31,
//   logInfo:  ()=> {
//     console.log(this); // window object
//   },
// };

// person.logInfo();

/**
 * Conslusion is that inside a method of a object this refers to the object itself whereas in a arrow method this refers to the global/ window object.
 */

// ----------------------------------------------------------------------------------------------------------------------------

// normal function inside a method
// let add = {
//   num: 0,
//   calc: function () {
//     // logs the add object
//     console.log(this);

//     function innerfunc() {
//       this.num += 1;

//       // logs the window object
//       console.log(this);

//       return this.num;
//     }
//     return innerfunc();
//   },
// };
// // logs NaN
// console.log(add.calc());

// arrow function inside a method
// let add = {
//   num: 0,
//   calc: function () {
//     // logs the add object
//     console.log(this);

//     const innerfunc = () => {
//       this.num += 1;

//       // logs the add object
//       console.log(this);

//       return this.num;
//     };
//     return innerfunc();
//   },
// };
// // logs NaN
// console.log(add.calc()); // 1

/**
 * Difference ye hai ke arrow function inside a method refers to the object whereas normal function used to refer to global object. Normal function me solution tha to assign refernce of this into a variable.
 */

// ----------------------------------------------------------------------------------------------------------------------------

// Constructor invocation in case of normal function
// let people = function (name, age) {
//   //   console.log(this); //  people {}
//   this.name = name;
//   this.age = age;
//   //   console.log(this); // people { name: 'John', age: 21 }

//   this.displayInfo = function () {
//     // console.log(this); // people { name: 'John', age: 21, displayInfo: [Function (anonymous)] }
//     // console.log(this.name + " is " + this.age + " years old"); // John is 21 years old
//   };
// };

// let person1 = new people("John", 21);

// // logs John is 21 years old
// person1.displayInfo();

// Constructor invocation in case of arrow function
// let people = (name, age) => {
//   console.log(this); //
//   name = name;
//   age = age;
//   console.log(this); // people { name: 'John', age: 21 }
// };

// let person1 = new people("John", 21);

let people = function (name, age) {
  console.log(this); //  people {}
  this.name = name;
  this.age = age;
  console.log(this); // people { name: 'John', age: 21 }

  const displayInfo = () => {
    console.log(this); // people { name: 'John', age: 21, displayInfo: [Function (anonymous)] }
    console.log(this.name + " is " + this.age + " years old"); // John is 21 years old
  };
};

let person1 = new people("John", 21);

// logs John is 21 years old
person1.displayInfo(); // thisArrow.js:161 Uncaught TypeError: person1.displayInfo is not a function???????

/**
 * Arrow function me constructor nahi bana sakte. Uncaught TypeError: people is not a constructor. Ye error aaegi.
 */

// // ----------------------------------------------------------------------------------------------------------------------------
// // CLASS CONTEXT
// class Example {
//   constructor() {
//     const proto = Object.getPrototypeOf(this);
//     //   console.log(Object.getOwnPropertyNames(proto)); // ['constructor', 'first', 'second']
//     // console.log(this); // Example {}
//   }
//   first() {
//     // console.log(this); // Example {}
//   }
//   second() {}
//   static third() {}
// }

// new Example();
// // ----------------------------------------------------------------------------------------------------------------------------
// // Indirect Context
// // Method call and apply
// function getBrand(prefix) {
//   //   console.log(this); // { brand: 'Honda' }
//   //   console.log(prefix + this.brand);
//   //   console.log(this); // { brand: 'Audi' }
// }

// let honda = {
//   brand: "Honda",
// };
// let audi = {
//   brand: "Audi",
// };

// getBrand.call(honda, "It's a "); // It's a Honda
// getBrand.call(audi, "It's an "); // It's an Audi
// getBrand.apply(honda, ["It's a "]); // It's a Honda
// getBrand.apply(audi, ["It's an "]); // It's a Audi
// // ----------------------------------------------------------------------------------------------------------------------------
// // Arrow Functions
// let getThis = () => this;
// // console.log(getThis() === window); // true
// // ----------------------------------------------------------------------------------------------------------------------------
// function Car() {
//   //   console.log(this); // Car {}
//   this.speed = 120;
//   //   console.log(this); // Car {speed: 120}
// }
// // ye kya hai? car.prototype?????
// Car.prototype.getSpeed = () => {
//   //   console.log(this.speed); // undefined
//   return this.speed;
// };

// var car = new Car();
// car.getSpeed();
// // ----------------------------------------------------------------------------------------------------------------------------
// // Uper wale ka solution -> line 77
// // ----------------------------------------------------------------------------------------------------------------------------
// var myVar = 100;

// function WhoIsThis() {
//   //   console.log(this);
//   var myVar = 200;
//   //   console.log(this);
//   //   console.log(myVar); // 200
//   //   console.log(this.myVar); // 100
// }
// // console.log("step 1");
// WhoIsThis(); // inferred as window.WhoIsThis()
// // Step 1 answers:
// // 200
// // 100 (browser) (node - undefined)
// // console.log("step 2");
// // Step 2 answers:
// // 200
// // undefined (browser) (node - undefined)
// var obj = new WhoIsThis();
// console.log(obj.myVar); // undefined (browser+node)
