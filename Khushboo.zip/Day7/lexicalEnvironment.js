// A lexical environment is a data structure that holds identifier-variable mapping. (here identifier refers to the name of variables/functions, and the variable is the reference to actual object [including function object or primitive value].

// Lexical in general means in hierarchy or in a sequence.Whenever a new execution context(EC) is created a new lexical environment  is created and it is referenced in local EC in memory space.

// Lexical Environment: Local Memory + Lexical Environment of its Parent

// So in short, a lexical environment is a place where variables and functions live or physically present during the program execution.
