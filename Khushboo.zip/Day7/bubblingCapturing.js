/**
these are the 2 ways of event propogation in the DOM tree:
   1. bubbling
   2. capturing
      
 * https://www.youtube.com/watch?v=aVSf0b1jVKk (akshay saini)-> event bubbling, 
 
 * EVENT BUBBLING:
    agar 3 divs hai - grandparent, parent, child, 3no me onclick laga hai. jab hum child k onclick par click karenge it will    bubble up to parent -> grandparent till the root of the page i.e. document.  

* EVENT CAPTURING/TRICKLING:
    ye bubbling ka ulta hota hai. agar 3 divs hai - grandparent, parent, child, 3no me onclick laga hai. jab hum child k onclick par click karenge to sabse pehle grandparent ka event handler call hoga then parent and then child.
 */

document.querySelector("#grandparent").addEventListener(
  "click",
  () => {
    console.log("grandParent");
  },
  true
  //   capturing
);

document.querySelector("#parent").addEventListener(
  "click",
  () => {
    console.log("grandParent");
  },
  false
  //   bubbling
);

document.querySelector("#child").addEventListener(
  "click",
  () => {
    console.log("grandParent");
  },
  false
  //   bubbling  
);

// pehle capturing hoti hai then bubbling
