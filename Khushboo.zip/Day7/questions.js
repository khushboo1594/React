// stopImmediatePropogation
// prevent default event
// what is execution context? what is call stack??
// 
