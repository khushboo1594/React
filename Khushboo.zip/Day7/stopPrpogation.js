document.querySelector("#grandparent").addEventListener(
    "click",
    (e) => {
      console.log("grandParent");
      e.stopPropagation();
      e.stop
    },
    true
  );
  
  document.querySelector("#parent").addEventListener(
    "click",
    (e) => {
      console.log("grandParent");
    //   e.stopPropagation();
    },
    true
  );
  
  document.querySelector("#child").addEventListener(
    "click",
    (e) => {
      console.log("grandParent");
    //   e.stopPropagation();
    },
    true 
  );