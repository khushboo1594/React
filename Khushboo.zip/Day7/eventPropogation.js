/*
Event propogation determines in which order the elements receive the event. 
*/