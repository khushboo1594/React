/**
 * DOM: document object model
    DOM is a API which helps us in manipulating HTML documents, like add remove, modify parts of HTML document.
    When the page loads browser makes a DOM tree. document is the root of the tree.
    Every object becomes a object in the DOM and every object will have some property and method.
    The document object represents your web page. if you want to access any element you start by accessing the document object.
    BOM: browser object model
 

 */