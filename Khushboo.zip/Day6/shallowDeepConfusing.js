// shallow copy v/s deep copy(clones)

/* Primitive data types:
        1. number
        2. null
        3. undefined
        4. string
        5. symbol(introduced in ES6)
        6. bigint
*/

/* Non - primitive data types / objects / structural
        1. objects (map, set, weakMap, array, objects, date)
        2. functions
*/

// shallow copy with spread operator
const xArray = [45, 25, 78];
// const zArray = xArray;
const yArray = [...xArray, 10]; // OR
// const yArray = [...xArray];
console.log(xArray);
console.log(yArray);
// console.log(zArray===xArray); // because there references are same
console.log(yArray===xArray); // in shallow copying the array or objects they do not share the same reference.

// // Object.assign
// const oAArray = Object.assign([], zArray);
// // console.log(oAArray);
// // console.log(zArray===oAArray); // isme bhi shallow copy hi ho rahi hai

// // But if there are nested arrays or object??
// xArray.push([121, 454]);
// nArray = [...xArray];
// nArray[3].push(3);
// console.log(xArray); // here we saw that xArray has also been changed, that means when there are nested objects or arrays shallow copy does not work.

// Array.from() and Array.slice() also create shallow copies

// Can we prevent the above problem in objects, through Object.freeze()
const user = {
  userName: "Khushboo",
  age: 28,
  active: true,
  friends: ["Ritu", "Pupu"],
};

// Object.freeze(user);
// user.friends.push("pooja");
// console.log(user);
// user.userName = "deepesh";
// console.log(user);
// freezing also does not go deep down and does only shallow freezing

// instead of shallow copying deep copy is needed to avoid it

