// IIFE(Immediately Invoked Function Expression) is a function that runs as soon as it is defined
/* It is a design pattern which is also known as a Self-Executing Anonymous Function and contains two major parts:
    * The first is the anonymous function with lexical scope enclosed within the Grouping Operator (). This prevents accessing variables within the IIFE idiom as well as polluting the global scope.
    * The second part creates the immediately invoked function expression () through which the JavaScript engine will directly interpret the function.
    * hum anonymous, named, arrow function likh skte hai inside IIFE but not function expression. 
    * grouping operator lagane se IIFE k andar jo bhi variables hum likhenge that will become private(doubtful)
    * iski dependency nahi hoti kisi par call karne k liye 
    */

// ((name)=>{console.log(`IIFE ${name}`)})('khushboo');
(function(name){console.log(`IIFE ${name}`)})('khushboo');
