/****************************************
- spread syntax
- using the Object assign method
- using JSON parse and stringify
****************************************/

const user = {
  userName: "Khushboo",
  age: 28,
  active: true,
  friends: ["Ritu", "Pupu"],
};

// spread syntax \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

// const copiedUser = { ...user };
// console.log('==============copying objects through spread================');
// console.log(copiedUser);
// copiedUser.userName='deepesh';
// console.log(copiedUser.friends === user.friends); 
// // since spread operator me primitives me deep copying hoti hai aur objects me shallow that's why it is true
// copiedUser.friends.push("Akansha");
// console.log(copiedUser);
// console.log(user);
// console.log(copiedUser === user);
// console.log('==============copying objects through spread================');
// shallow copying friends array ki hue hai user ki deep copy hue hai that's why it is false.

// Object.assign() \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

// const copiedUser = Object.assign({}, user);
// console.log('==============copying objects through Object.assign()================');
// console.log(copiedUser);
// copiedUser.userName='deepesh';
// console.log(copiedUser.friends === user.friends); 
// // since spread operator me primitives me deep copying hoti hai aur objects me shallow that's why it is true
// copiedUser.friends.push("Akansha");
// console.log(copiedUser);
// console.log(user);
// console.log(copiedUser === user);
// console.log('==============copying objects through Object.assign()================');
// the result is same as of spread operator

// JSON.parse() and JSON.stringify() \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
// JSON.stringify() -> converts the passed argument to JSON string
// JSON.parse() -> converts the passed argument to object

const copiedUser = JSON.parse(JSON.stringify(user));
console.log('==============copying objects through JSON.parse() and JSON.stringify()================');
console.log(copiedUser);
copiedUser.userName='deepesh';
console.log(copiedUser.friends === user.friends); 
// since spread operator me primitives me deep copying hoti hai aur objects me shallow that's why it is true
copiedUser.friends.push("Akansha");
console.log(copiedUser);
console.log(user);
console.log(copiedUser === user);
console.log('==============copying objects through JSON.parse() and JSON.stringify()================');
// JSON.parse() and JSON.stringify() se deep copy banti hai 