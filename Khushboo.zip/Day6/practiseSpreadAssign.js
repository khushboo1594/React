/**
 * second argument onwards in spread operator -> are added to the resulting object.
 */

const user1 = {
  userName: "Khushboo",
  age: 28,
  active: true,
  friends: ["Ritu", "Pupu"],
};

const user2 = {
  userName: "deepesh",
  age: 29,
  active: true,
  friends: ["arun", "me"],
};

// spread syntax \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

const copiedUser = { ...user1, user2};
console.log("==============copying multipe objects through spread================");
console.log(copiedUser);
// copiedUser.userName = "deepesh";
// console.log(copiedUser.friends === user.friends);
// since spread operator me primitives me deep copying hoti hai aur objects me shallow that's why it is true
// copiedUser.friends.push("Akansha");
// console.log(copiedUser);
// console.log(user);
// console.log(copiedUser === user);
console.log("==============copying multipe objects through spread================");
// shallow copying friends array ki hue hai user ki deep copy hue hai that's why it is false.
