/*
1. jab spread operator aur Object.assign same kaam karta hai to fir difference kya hai?
2. read more about spread operator, JSON.stringify(), JSON.parse()
3. how to make a shallow copy of a varible?
4. In JavaScript, standard built-in object-copy operations (spread syntax, Array.prototype.concat(), Array.prototype.slice(), Array.from(), Object.assign(), and Object.create()) do not create deep copies (instead, they create shallow copies).
5. ask prince he said k prototype likhne ki zarurat nahi hai. to kaha nahi hai?
*/