// normal copying////////////////////////////////////

// let user1 = {
//   fName: "khushboo",
//   age: 28,
// };
// let user2 = user1;
// user2.fName = "Deepesh";
// console.log('=========normal copying=======');
// console.log(user2);
// console.log(user1);
// console.log(user2 === user1); // output: true
// // object k case me strict comparision operator === true tab return karta hai jab content bhi same ho aur reference bhi
// console.log('=========normal copying=======');

// normal copy me shallow copy hoti hai. this means content are changed of the original also.

// copying through spread operator//////////////////////////////////////
// spread operator aur Object.assign same hai ek dum 

// let user1 = {
//   fName: "khushboo",
//   age: 28,
// };
// let user2 = { ...user1 };
// user2.fName = "Deepesh";
// console.log('=========copying through spread operator=======');
// console.log(user2);
// console.log(user1);
// console.log(user2 === user1); // output: false
// console.log('=========copying through spread operator=======');

// spread operator deep copy banata hai

// but what if the object is nested -> that means it has object or array or function inside it////////////////////////////////////

// another object nested inside another object

// let user1 = {
//   fName: "khushboo",
//   age: 28,
//   other: {
//     lName: "patel",
//   },
// };

// array nested inside  object

// user1 = {
//   fName: "khushboo",
//   age: 28,
//   other: [45, 56]
// };

// // normal copying in nested objects

// let user2=user1;
// user2.other.lName='verma';
// user2.fName='prince';
// console.log('=========normal copying in nested objects=======');
// console.log(user2);
// console.log(user1);
// console.log(user2 === user1); // output: true
// console.log('=========normal copying in nested objects=======');

// let user2=user1;
// user2.other.push('verma');
// user2.fName='prince';
// console.log('=========normal copying in nested array=======');
// console.log(user2);
// console.log(user1);
// console.log(user2 === user1); // output: true
// console.log('=========normal copying in nested array=======');

// ok, so nested objects aur array me normal copying me shallow copying hi hoti hai.

// copying through spread operator in nested objects

// let user2={...user1};
// user2.other.lName='verma';
// user2.fName='prince';
// console.log('=========copying through spread operator in nested objects=======');
// console.log(user2);
// console.log(user1);
// console.log(user2 === user1); // output: false
// console.log('=========copying through spread operator in nested objects=======');

// let user2={...user1};
// user2.other.push('verma');
// user2.fName='prince';
// console.log('=========copying through spread operator in nested array=======');
// console.log(user2);
// console.log(user1);
// console.log(user2 === user1); // output: true
// console.log('=========copying through spread operator in nested array=======');

// to hota ye hai isme k agar nested object ya array hai to primitives ki to deep copy banegi but object ki shallow copy banegi

// copying through assign operator//////////////////////////////////////

// let user1 = {
//   fName: "khushboo",
//   age: 28,
// };
// let user2 = Object.assign({}, user1);
// user2.fName = "Deepesh";
// console.log("=========copying through Object.assign=======");
// console.log(user2);
// console.log(user1);
// console.log(user2 === user1); // output: false
// console.log("=========copying through Object.assign=======");

// Object.assign bhi deep copy banata hai

// but what if the object is nested -> object or array or function inside it////////////////////////////////////

// another object nested inside another object

let user1 = {
  fName: "khushboo",
  age: 28,
  other: {
    lName: "patel",
  },
};

// array nested inside  object

// user1 = {
//   fName: "khushboo",
//   age: 28,
//   other: [45, 56]
// };

// copying through Object.assign in nested objects

let user2 = Object.assign({}, user1);
user2.other.lName='verma';
user2.fName='prince';
console.log('=========copying through Object.assign in nested objects=======');
console.log(user2);
console.log(user1);
console.log(user2 === user1); // output: false
console.log('=========copying through Object.assign in nested objects=======');

// let user2={...user1};
// user2.other.push('verma');
// user2.fName='prince';
// console.log('=========copying through spread operator in nested array=======');
// console.log(user2);
// console.log(user1);
// console.log(user2 === user1); // output: true
// console.log('=========copying through spread operator in nested array=======');

// to hota ye hai isme k agar nested object ya array hai to primitives ki to deep copy banegi but object ki shallow copy banegi