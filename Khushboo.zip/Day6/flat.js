// By default flat method goes only 1 level deep. default means -> arr1.flat(); Agar usse jyada deep jana hai to fir hame number pass karne padega.
const arr1 = [1,2,3,[4,5,[6,7,8]]];
const arr1Flat = arr1.flat(3);
console.log(arr1Flat);
console.log(arr1);
