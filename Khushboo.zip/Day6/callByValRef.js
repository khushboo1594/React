// call by value///////////////////////////////////
///////// primitves are copied by call by value. call by value me keval value copy hoti hai, the identifiers are completely independent of each other. 
// let x=12;
// let y=x;
// y=15;
// console.log(`value of x:${x}`);
// console.log(`value of y:${y}`);

// proof:
// let number=10;
// function increase(number){
// increase++;
// }
// increase(number);
// console.log(number);
// yaha hua ye jo number humne pass kiya hai uski value copy hue number parameter me increase function k by call by value, jo k local hai for increase function. jab humne use log karwaya it went out of it's scope and printed the global value available that is 10.



// call by reference///////////////////////////////////
///////// objects are copied by call by reference. jab hum object store karte hai tab uska address store hota hai identifier me na k uski value. that's why when we copy it's the address that is copied. here both object1 and object2 are pointing to the same location. 
// let object1={
//     name:"khushboo",
//     age:28
// } 
// let object2=object1;
// console.log(object1);
// console.log(object2);
// object2.name='pupu';
// object1.age=22;
// console.log(object1);
// console.log(object2);

// proof:
let number={value:10};
function increase(number){
number.value++;
}
increase(number);
console.log(number);
// yaha hua ye jo number humne pass kiya hai uski value copy hue number parameter me increase function k by call by reference, ab since call by reference k through value pass hue hai to humne local object me jo change kiya wo gobal object me bhi hua. jab humne use log karwaya the value was 11 as it was call by reference.
