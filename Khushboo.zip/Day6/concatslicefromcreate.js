// // CONCAT
// /*
// With concat method we can create a shallow copy of the array if no argument is passed.

// WHY???
//     Net par likha hai ki shallow copy banata hai.
//     But ye to deep copy banata hai. Aur logically thik b hai qki concat does not change the original array. It returns a new array.

// Different syntax of concat method -
//     concat(): create a deep copy
//     concat(value0): merges it in the array and returns a new a
//     concat(value0, value1)
//     concat(value0, value1, ... , valueN)

// */

// // const array1=[1,2,3];
// // const array2=array1.concat();
// // console.log(array2===array1);
// // /*
// // Iska answer false aaega because they don't share the same reference. As it is returning a new array so how would they even have same reference.
// // */
// // console.log(array2); // [1,2,3]
// // array1.push(4);
// // array2.push(5);
// // console.log(array2); // [1,2,3,5]
// // console.log(array1); // [1,2,3,4]

// /*
// Assign karne par it will make a shallow copy. Logically it's valid also since array is a object in js.
// */
// // const array1=[1,2,3];
// // const array2=array1;
// // console.log(array2===array1);
// /*
// Iska answer true aaega because they share the same reference. As it is returning a reference to the array so they are pointing to the same thing.

// NOTE:
// When we are comparing objects with strict comparsion operator it compares the reference as well as the content.
// In case of primitives it compares the value and the data type.
// */
// // console.log(array2);
// // array2.push(4);
// // console.log(array2);
// // console.log(array1);

// // The following code concatenates two arrays://////////////////////////////////
// // const letters = ['a', 'b', 'c'];
// // const numbers = [1, 2, 3];

// // const alphaNumeric = letters.concat(numbers);
// // console.log(alphaNumeric);
// // // results in ['a', 'b', 'c', 1, 2, 3]

// // // The following code concatenates three arrays:///////////////////////////////////
// // const num1 = [1, 2, 3];
// // const num2 = [4, 5, 6];
// // const num3 = [7, 8, 9];

// // const numbers = num1.concat(num2, num3);

// // console.log(numbers);
// // // results in [1, 2, 3, 4, 5, 6, 7, 8, 9]

// // // The following code concatenates three values to an array://///////////////////////////////
// // const letters = ['a', 'b', 'c'];

// // const alphaNumeric = letters.concat(1, [2, 3]);

// // console.log(alphaNumeric);
// // results in ['a', 'b', 'c', 1, 2, 3]

// // The following code concatenates nested arrays and demonstrates retention of references://///////////////////////
// // const num1 = [[1]];
// // const num2 = [2, [3]];

// // const numbers = num1.concat(num2);

// // console.log(numbers);
// // // results in [[1], 2, [3]]

// // // modify the first element of num1
// // num1[0].push(4);
// // num1.push(5);
// // numbers[0].push(6);
// // console.log(num1);
// // // results in [ [ 1, 4, 6 ], 5 ]

// // console.log(numbers);
// // results in [ [ 1, 4, 6 ], 2, [ 3 ] ]
// /*
// Nested array ki shallow copy hoti hai aur primitives ki deep copy. It makes sense as nested array are objects aur objects ki shallow copy hoti hai.
// */

// SLICE
/*
It makes a deep copy of the sliced array. 
SYNTAX:
    slice(): ye deep copy banata hai
    slice(start)
    slice(start, end)

PARAMETERS:
    START
        Optional
        Zero-based index at which to start extraction.

        A negative index can be used, indicating an offset from the end of the sequence. slice(-2) extracts the last two elements in the sequence.

        If start is undefined, slice starts from the index 0.

        If start is greater than the index range of the sequence, an empty array is returned.

    END 
        Optional
        Zero-based index before which to end extraction. slice extracts up to but not including end. For example, slice(1,4) extracts the second element through the fourth element (elements indexed 1, 2, and 3).

        A negative index can be used, indicating an offset from the end of the sequence. slice(2,-1) extracts the third element through the second-to-last element in the sequence.

        If end is omitted, slice extracts through the end of the sequence (arr.length).

        If end is greater than the length of the sequence, slice extracts through to the end of the sequence (arr.length).

    Return value
        A new array containing the extracted elements.
*/
const array1 = [1, 2, 3, 6, 7, 8];
const array2 = array1.slice();
console.log(array2); //[1,2,3,6,7,8]
console.log(array1 === array2); // false
const array3 = array1.slice(1, 4);
console.log(array3); //[2,3,6]

const array4 = array1.slice(-3);
console.log(array4); //[6,7,8]
const array5 = array1.slice(1);
console.log(array5); //[2, 3, 6, 7, 8]
const array6 = array1.slice(7);
console.log(array6); //[]
const array7 = array1.slice(1, 8);
console.log(array7); //[2, 3, 6, 7, 8]
