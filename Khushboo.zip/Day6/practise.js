function forecast(arr) {
    console.log(arr)  ;  
    let newArr= arr.splice(1,3);
    console.log(arr)  ;  
    return newArr;
}

console.log(forecast(['cold', 'rainy', 'warm', 'sunny', 'cool', 'thunderstorms']));