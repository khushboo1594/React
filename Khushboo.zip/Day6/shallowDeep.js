let user1={
    fName:"khushboo",
    age:28
}
let user2=user1;
// user2.fName='Deepesh';
// console.log(user2);
// console.log(user1);
console.log(user2===user1);
// this is shallow copy. when objects are copied there references are copied and this is what shallow copying is. the problem with shallow copying is if you make any change in the copy original also gets changed to prevent this we have deep copying.


// deep copying variables me hoti hai

// deep copying can be implemented with the help of JSON.parse() and JSON.stringify()
// let user2=JSON.parse(JSON.stringify(user1));
// user2.fName='Deepesh';
// console.log(user2);
// console.log(user1);
// Here the new object is created using the JSON.parse() and JSON.stringify() methods of JavaScript. JSON.stringify() takes a JavaScript object as argument and then transforms it into a JSON string. This JSON string is passed to the JSON.parse() method which then transforms it into a JavaScript object. This method is useful when the object is small and has serializable properties. But if the object is very large and contains certain non-serializable properties then there is a risk of data loss. Specially if an object contains methods then JSON.stringify() will fail as methods are non-serializable. There are better ways to deep clone of which one is Lodash which allows cloning methods as well.

// serializable meaning?????