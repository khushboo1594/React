// what are javascript events?
// javascript events are what action you want when certain events like click of a button, submission of a form happens?
/*
1. inline events
2. event object
3. addEventListener
4. standard vs arrow
*/

